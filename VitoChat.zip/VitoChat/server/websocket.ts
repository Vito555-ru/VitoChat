import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import type { WebSocketEvent, User } from '@shared/schema';
import { storage } from './storage';

interface ClientConnection {
  ws: WebSocket;
  userId?: string;
  isAuthenticated: boolean;
  lastPing?: Date;
}

export class WebSocketManager {
  private wss?: WebSocketServer;
  private connections = new Map<string, ClientConnection>();
  private userConnections = new Map<string, Set<string>>();
  private pingInterval?: NodeJS.Timeout;

  init(server: Server) {
    this.wss = new WebSocketServer({ 
      server, 
      path: '/ws',
      perMessageDeflate: false,
    });

    this.wss.on('connection', (ws: WebSocket, req) => {
      const connectionId = this.generateConnectionId();
      
      console.log(`WebSocket connection established: ${connectionId}`);
      
      const connection: ClientConnection = {
        ws,
        isAuthenticated: false,
        lastPing: new Date(),
      };

      this.connections.set(connectionId, connection);

      // Send connection established event
      this.sendToConnection(connectionId, {
        type: 'connection_established',
        message: 'Connected to VITO real-time server'
      });

      ws.on('message', async (message: Buffer) => {
        try {
          const data = JSON.parse(message.toString());
          await this.handleMessage(connectionId, data);
        } catch (error) {
          console.error('Error handling WebSocket message:', error);
          this.sendToConnection(connectionId, {
            type: 'error',
            message: 'Invalid message format'
          });
        }
      });

      ws.on('close', () => {
        console.log(`WebSocket connection closed: ${connectionId}`);
        this.handleDisconnection(connectionId);
      });

      ws.on('error', (error) => {
        console.error(`WebSocket error for ${connectionId}:`, error);
        this.handleDisconnection(connectionId);
      });
    });

    // Start ping/pong heartbeat
    this.startHeartbeat();

    console.log('✅ WebSocket server initialized on /ws');
  }

  private generateConnectionId(): string {
    return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
  }

  private async handleMessage(connectionId: string, data: any) {
    const connection = this.connections.get(connectionId);
    if (!connection) return;

    switch (data.type) {
      case 'authenticate':
        await this.handleAuthentication(connectionId, data.userId);
        break;

      case 'message_sent':
        if (connection.isAuthenticated) {
          await this.handleMessageSent(connectionId, data.messageData);
        }
        break;

      case 'message_delivered':
        if (connection.isAuthenticated) {
          await this.handleMessageDelivered(connectionId, data.messageId);
        }
        break;

      case 'typing_start':
        if (connection.isAuthenticated) {
          await this.handleTypingStart(connectionId, data.chatId);
        }
        break;

      case 'typing_stop':
        if (connection.isAuthenticated) {
          await this.handleTypingStop(connectionId, data.chatId);
        }
        break;

      case 'message_read':
        if (connection.isAuthenticated) {
          await this.handleMessageRead(connectionId, data.messageId);
        }
        break;

      case 'call_initiate':
        if (connection.isAuthenticated) {
          await this.handleCallInitiate(connectionId, data.receiverId, data.callType);
        }
        break;

      case 'call_answer':
        if (connection.isAuthenticated) {
          await this.handleCallAnswer(connectionId, data.callId);
        }
        break;

      case 'call_decline':
        if (connection.isAuthenticated) {
          await this.handleCallDecline(connectionId, data.callId);
        }
        break;

      case 'call_end':
        if (connection.isAuthenticated) {
          await this.handleCallEnd(connectionId, data.callId);
        }
        break;

      case 'ping':
        connection.lastPing = new Date();
        this.sendToConnection(connectionId, { type: 'pong' });
        break;

      default:
        console.log('Unknown WebSocket message type:', data.type);
    }
  }

  private async handleAuthentication(connectionId: string, userId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection) return;

    try {
      // Verify user exists
      const user = await storage.getUserById(userId);
      if (!user) {
        this.sendToConnection(connectionId, {
          type: 'authentication_failed',
          message: 'User not found'
        });
        return;
      }

      // Update connection
      connection.userId = userId;
      connection.isAuthenticated = true;

      // Add to user connections
      if (!this.userConnections.has(userId)) {
        this.userConnections.set(userId, new Set());
      }
      this.userConnections.get(userId)!.add(connectionId);

      // Update user online status
      await storage.updateUserOnlineStatus(userId, true);

      // Notify successful authentication
      this.sendToConnection(connectionId, {
        type: 'authenticated',
        user
      });

      // Notify contacts that user is online
      this.notifyContactsUserOnline(userId);

      console.log(`User ${userId} authenticated on connection ${connectionId}`);
    } catch (error) {
      console.error('Authentication error:', error);
      this.sendToConnection(connectionId, {
        type: 'authentication_failed',
        message: 'Authentication failed'
      });
    }
  }

  private async handleMessageSent(connectionId: string, messageData: any) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      // Create message in database
      const message = await storage.createMessage({
        ...messageData,
        senderId: connection.userId
      });

      // Get the message with sender details
      const messageWithSender = await storage.getMessageById(message.id);
      if (!messageWithSender) return;

      // Get chat details to find the receiver
      const chat = await storage.getChatById(messageData.chatId);
      if (!chat) return;

      const receiverId = chat.user1Id === connection.userId ? chat.user2Id : chat.user1Id;

      // Send INSTANT delivery to sender (confirmation)
      this.sendToConnection(connectionId, {
        type: 'message_sent_confirmation',
        message: messageWithSender
      });

      // Send INSTANT delivery to receiver
      this.sendToSpecificUser(receiverId, {
        type: 'message_sent',
        message: messageWithSender
      });

      // Send delivery status to sender if receiver is online
      if (this.isUserOnline(receiverId)) {
        this.sendToSpecificUser(connection.userId, {
          type: 'message_delivered',
          messageId: message.id,
          receiverId: receiverId
        });
      }

      // Update chat timestamp for real-time sorting
      await storage.updateChatTimestamp(messageData.chatId);

      console.log(`📨 INSTANT message delivery: ${connection.userId} → ${receiverId}`);
    } catch (error) {
      console.error('Error handling message sent:', error);
      // Send error back to sender
      this.sendToConnection(connectionId, {
        type: 'message_error',
        error: 'Failed to send message'
      });
    }
  }

  private async handleTypingStart(connectionId: string, chatId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      const chat = await storage.getChatById(chatId);
      if (!chat) return;

      const receiverId = chat.user1Id === connection.userId ? chat.user2Id : chat.user1Id;

      this.sendToSpecificUser(receiverId, {
        type: 'typing_start',
        chatId,
        userId: connection.userId
      });

      console.log(`✍️ ${connection.userId} started typing in chat ${chatId}`);
    } catch (error) {
      console.error('Error handling typing start:', error);
    }
  }

  private async handleTypingStop(connectionId: string, chatId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      const chat = await storage.getChatById(chatId);
      if (!chat) return;

      const receiverId = chat.user1Id === connection.userId ? chat.user2Id : chat.user1Id;

      this.sendToSpecificUser(receiverId, {
        type: 'typing_stop',
        chatId,
        userId: connection.userId
      });

      console.log(`✋ ${connection.userId} stopped typing in chat ${chatId}`);
    } catch (error) {
      console.error('Error handling typing stop:', error);
    }
  }

  private async handleMessageDelivered(connectionId: string, messageId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      // Update message delivery status in database
      await storage.markMessageDelivered(messageId, connection.userId);
      
      // Get message details to notify sender
      const message = await storage.getMessageById(messageId);
      if (!message) return;

      // Notify sender that message was delivered
      this.sendToSpecificUser(message.senderId, {
        type: 'message_delivered',
        messageId,
        userId: connection.userId
      });

      console.log(`✅ Message ${messageId} delivered to ${connection.userId}`);
    } catch (error) {
      console.error('Error handling message delivered:', error);
    }
  }

  private async handleMessageRead(connectionId: string, messageId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      // Mark message as read in database
      await storage.markMessageRead(messageId, connection.userId);
      
      // Get message details to notify sender
      const message = await storage.getMessageById(messageId);
      if (!message) return;

      // Notify sender that message was read
      this.sendToSpecificUser(message.senderId, {
        type: 'message_read',
        messageId,
        userId: connection.userId
      });

      console.log(`👀 Message ${messageId} read by ${connection.userId}`);
    } catch (error) {
      console.error('Error handling message read:', error);
    }
  }

  private async handleCallInitiate(connectionId: string, receiverId: string, callType: 'voice' | 'video') {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      // Create call record
      const call = await storage.createCall({
        callerId: connection.userId,
        receiverId,
        type: callType,
        status: 'ringing'
      });

      // Get call with user details
      const callWithUsers = await storage.getCallById(call.id);
      if (!callWithUsers) return;

      // Notify receiver
      this.sendToSpecificUser(receiverId, {
        type: 'call_incoming',
        call: callWithUsers
      });
    } catch (error) {
      console.error('Error handling call initiate:', error);
    }
  }

  private async handleCallAnswer(connectionId: string, callId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      await storage.updateCall(callId, { status: 'answered' });

      // Get call details
      const call = await storage.getCallById(callId);
      if (!call) return;

      // Notify caller
      this.sendToSpecificUser(call.caller.id, {
        type: 'call_answered',
        callId
      });
    } catch (error) {
      console.error('Error handling call answer:', error);
    }
  }

  private async handleCallDecline(connectionId: string, callId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      await storage.updateCall(callId, { status: 'declined' });

      // Get call details
      const call = await storage.getCallById(callId);
      if (!call) return;

      // Notify caller
      this.sendToSpecificUser(call.caller.id, {
        type: 'call_declined',
        callId
      });
    } catch (error) {
      console.error('Error handling call decline:', error);
    }
  }

  private async handleCallEnd(connectionId: string, callId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection || !connection.userId) return;

    try {
      await storage.updateCall(callId, { 
        status: 'ended',
        endedAt: new Date()
      });

      // Get call details
      const call = await storage.getCallById(callId);
      if (!call) return;

      // Notify both parties
      const otherUserId = call.caller.id === connection.userId ? call.receiver.id : call.caller.id;
      
      this.sendToSpecificUser(otherUserId, {
        type: 'call_ended',
        callId
      });
    } catch (error) {
      console.error('Error handling call end:', error);
    }
  }

  private async handleDisconnection(connectionId: string) {
    const connection = this.connections.get(connectionId);
    if (!connection) return;

    if (connection.userId) {
      // Remove from user connections
      const userConnections = this.userConnections.get(connection.userId);
      if (userConnections) {
        userConnections.delete(connectionId);
        
        // If no more connections for this user, mark as offline
        if (userConnections.size === 0) {
          this.userConnections.delete(connection.userId);
          await storage.updateUserOnlineStatus(connection.userId, false);
          this.notifyContactsUserOffline(connection.userId);
        }
      }
    }

    this.connections.delete(connectionId);
  }

  private async notifyContactsUserOnline(userId: string) {
    try {
      const contacts = await storage.getUserContacts(userId);
      for (const contact of contacts) {
        this.sendToSpecificUser(contact.contactId, {
          type: 'user_online',
          userId
        });
      }
    } catch (error) {
      console.error('Error notifying contacts user online:', error);
    }
  }

  private async notifyContactsUserOffline(userId: string) {
    try {
      const contacts = await storage.getUserContacts(userId);
      for (const contact of contacts) {
        this.sendToSpecificUser(contact.contactId, {
          type: 'user_offline',
          userId
        });
      }
    } catch (error) {
      console.error('Error notifying contacts user offline:', error);
    }
  }

  public sendToSpecificUser(userId: string, event: WebSocketEvent) {
    const userConnections = this.userConnections.get(userId);
    if (!userConnections) return;

    for (const connectionId of Array.from(userConnections)) {
      this.sendToConnection(connectionId, event);
    }
  }

  public isUserOnline(userId: string): boolean {
    const userConnections = this.userConnections.get(userId);
    return userConnections ? userConnections.size > 0 : false;
  }

  // Force logout all sessions for a user (for account deletion or security)
  public forceLogoutUser(userId: string, reason: string = 'Account status changed') {
    const userConnections = this.userConnections.get(userId);
    if (!userConnections) return;

    console.log(`Force logging out user ${userId}: ${reason}`);

    // Send force logout event to all user sessions
    for (const connectionId of Array.from(userConnections)) {
      this.sendToConnection(connectionId, {
        type: 'force_logout',
        reason
      });

      // Close the connection after a short delay
      setTimeout(() => {
        const connection = this.connections.get(connectionId);
        if (connection) {
          connection.ws.close(1000, reason);
        }
      }, 1000);
    }

    // Clean up user connections
    this.userConnections.delete(userId);
  }

  // Notify all contacts about user logout
  public async notifyUserLogout(userId: string) {
    try {
      // Update user offline status first
      await storage.updateUserOnlineStatus(userId, false);
      
      // Notify all contacts that user logged out
      const contacts = await storage.getUserContacts(userId);
      for (const contact of contacts) {
        this.sendToSpecificUser(contact.contactId, {
          type: 'user_logged_out',
          userId
        });
      }
    } catch (error) {
      console.error('Error notifying user logout:', error);
    }
  }

  // Notify all contacts about account deletion
  public async notifyAccountDeletion(userId: string) {
    try {
      // Get contacts before deletion
      const contacts = await storage.getUserContacts(userId);
      
      // Notify all contacts about account deletion
      for (const contact of contacts) {
        this.sendToSpecificUser(contact.contactId, {
          type: 'user_account_deleted',
          userId
        });
      }
      
      // Force close all user connections
      this.forceLogoutUser(userId, 'Account permanently deleted');
    } catch (error) {
      console.error('Error notifying account deletion:', error);
    }
  }

  private sendToConnection(connectionId: string, event: WebSocketEvent) {
    const connection = this.connections.get(connectionId);
    if (!connection || connection.ws.readyState !== WebSocket.OPEN) return;

    try {
      connection.ws.send(JSON.stringify(event));
    } catch (error) {
      console.error(`Error sending to connection ${connectionId}:`, error);
      this.handleDisconnection(connectionId);
    }
  }

  private startHeartbeat() {
    this.pingInterval = setInterval(() => {
      const now = new Date();
      const timeout = 60000; // 1 minute timeout

      for (const [connectionId, connection] of Array.from(this.connections.entries())) {
        if (connection.lastPing && (now.getTime() - connection.lastPing.getTime()) > timeout) {
          console.log(`Connection ${connectionId} timed out`);
          connection.ws.terminate();
          this.handleDisconnection(connectionId);
        }
      }
    }, 30000); // Check every 30 seconds
  }

  public getConnectedUserCount(): number {
    return this.userConnections.size;
  }

  public getConnectionCount(): number {
    return this.connections.size;
  }

  public isUserOnline(userId: string): boolean {
    return this.userConnections.has(userId);
  }

  public getOnlineUsers(): string[] {
    return Array.from(this.userConnections.keys());
  }

  public shutdown() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
    }

    for (const [connectionId, connection] of Array.from(this.connections.entries())) {
      connection.ws.close();
    }

    this.connections.clear();
    this.userConnections.clear();

    if (this.wss) {
      this.wss.close();
    }
  }
}

export const wsManager = new WebSocketManager();