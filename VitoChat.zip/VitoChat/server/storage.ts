import { 
  users, 
  chats, 
  messages, 
  statuses, 
  statusViews,
  calls,
  contacts,
  deviceTokens,
  messageReadReceipts,
  otpVerifications,
  type User, 
  type Chat, 
  type Message, 
  type Status, 
  type StatusView,
  type Call,
  type Contact,
  type DeviceToken,
  type MessageReadReceipt,
  type OtpVerification,
  type ChatWithUsers,
  type MessageWithSender,
  type CallWithUsers,
  type ContactWithUser,
  type StatusWithUser,
  type InsertUser, 
  type InsertChat, 
  type InsertMessage, 
  type InsertStatus, 
  type InsertStatusView,
  type InsertCall,
  type InsertContact,
  type InsertDeviceToken,
  type InsertOtpVerification,
  type WebSocketEvent
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, asc, count, sql, lt } from "drizzle-orm";

export interface IStorage {
  // User operations
  createUser(userData: InsertUser): Promise<User>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByPhone(phoneNumber: string, countryCode: string): Promise<User | undefined>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User>;
  updateUserOnlineStatus(id: string, isOnline: boolean): Promise<void>;
  deleteUserAccount(userId: string): Promise<void>; // Comprehensive account deletion

  // Chat operations
  createChat(user1Id: string, user2Id: string): Promise<Chat>;
  getUserChats(userId: string): Promise<ChatWithUsers[]>;
  getChatById(chatId: string): Promise<Chat | undefined>;
  getChatByUsers(user1Id: string, user2Id: string): Promise<Chat | undefined>;
  updateChatTimestamp(chatId: string): Promise<void>;

  // Message operations
  createMessage(messageData: InsertMessage): Promise<MessageWithSender>;
  getChatMessages(chatId: string, limit?: number, offset?: number): Promise<MessageWithSender[]>;
  getMessageById(messageId: string): Promise<MessageWithSender | undefined>;
  updateMessage(messageId: string, updates: Partial<InsertMessage>): Promise<Message>;
  deleteMessage(messageId: string): Promise<void>;
  markMessageAsRead(messageId: string, userId: string): Promise<void>;
  markChatMessagesAsRead(chatId: string, userId: string): Promise<void>;

  // Call operations
  createCall(callData: InsertCall): Promise<Call>;
  getCallById(callId: string): Promise<CallWithUsers | undefined>;
  updateCall(callId: string, updates: Partial<InsertCall>): Promise<Call>;
  getUserCalls(userId: string, limit?: number): Promise<CallWithUsers[]>;
  getActiveCall(userId: string): Promise<CallWithUsers | undefined>;

  // Contact operations
  addContact(userId: string, contactId: string, displayName?: string): Promise<Contact>;
  getUserContacts(userId: string): Promise<ContactWithUser[]>;
  searchUsers(query: string, currentUserId: string): Promise<User[]>;
  removeContact(userId: string, contactId: string): Promise<void>;
  blockContact(userId: string, contactId: string): Promise<void>;
  unblockContact(userId: string, contactId: string): Promise<void>;

  // Device token operations
  addDeviceToken(userId: string, token: string, platform: string): Promise<DeviceToken>;
  removeDeviceToken(token: string): Promise<void>;
  getUserDeviceTokens(userId: string): Promise<DeviceToken[]>;

  // Status operations
  createStatus(statusData: InsertStatus): Promise<Status>;
  getUserStatuses(userId: string): Promise<StatusWithUser[]>;
  getContactStatuses(userId: string): Promise<StatusWithUser[]>;
  viewStatus(statusId: string, viewerId: string): Promise<void>;
  deleteExpiredStatuses(): Promise<void>;

  // OTP verification
  createOtpVerification(data: InsertOtpVerification): Promise<OtpVerification>;
  verifyOtp(phoneNumber: string, countryCode: string, otp: string): Promise<OtpVerification | null>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async getUserById(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByPhone(phoneNumber: string, countryCode: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(and(eq(users.phoneNumber, phoneNumber), eq(users.countryCode, countryCode)));
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserOnlineStatus(id: string, isOnline: boolean): Promise<void> {
    await db
      .update(users)
      .set({ 
        isOnline, 
        lastSeen: isOnline ? null : new Date() 
      })
      .where(eq(users.id, id));
  }

  // PERMANENT ACCOUNT DELETION - removes ALL related data and frees phone number
  async deleteUserAccount(userId: string): Promise<void> {
    try {
      // Delete all messages sent by user
      await db.delete(messages).where(eq(messages.senderId, userId));
      
      // Delete all calls involving user
      await db.delete(calls).where(
        or(
          eq(calls.callerId, userId),
          eq(calls.receiverId, userId)
        )
      );
      
      // Delete all chats involving user
      await db.delete(chats).where(
        or(
          eq(chats.user1Id, userId),
          eq(chats.user2Id, userId)
        )
      );
      
      // Delete all contacts involving user
      await db.delete(contacts).where(
        or(
          eq(contacts.userId, userId),
          eq(contacts.contactId, userId)
        )
      );
      
      // Delete all status updates by user
      await db.delete(statuses).where(eq(statuses.userId, userId));
      
      // Delete all OTP records for user
      await db.delete(otpVerifications).where(
        and(
          eq(otpVerifications.phoneNumber, sql`(SELECT phone_number FROM users WHERE id = ${userId})`),
          eq(otpVerifications.countryCode, sql`(SELECT country_code FROM users WHERE id = ${userId})`)
        )
      );
      
      // Finally, delete the user account - this frees the phone number
      await db.delete(users).where(eq(users.id, userId));
      
      console.log(`✅ ACCOUNT PERMANENTLY DELETED: ${userId} - Phone number freed for re-registration`);
    } catch (error) {
      console.error('Error deleting user account:', error);
      throw error;
    }
  }

  // Chat operations
  async createChat(user1Id: string, user2Id: string): Promise<Chat> {
    const [chat] = await db
      .insert(chats)
      .values({ user1Id, user2Id })
      .returning();
    return chat;
  }

  async getUserChats(userId: string): Promise<ChatWithUsers[]> {
    const userChats = await db
      .select({
        chat: chats,
        otherUser: users,
        lastMessage: messages,
      })
      .from(chats)
      .leftJoin(users, 
        or(
          and(eq(chats.user1Id, userId), eq(users.id, chats.user2Id)),
          and(eq(chats.user2Id, userId), eq(users.id, chats.user1Id))
        )
      )
      .leftJoin(messages, 
        and(
          eq(messages.chatId, chats.id),
          eq(messages.id, sql`(
            SELECT id FROM messages 
            WHERE chat_id = ${chats.id} 
            ORDER BY created_at DESC 
            LIMIT 1
          )`)
        )
      )
      .where(or(eq(chats.user1Id, userId), eq(chats.user2Id, userId)))
      .orderBy(desc(messages.createdAt));

    const chatsWithUnreadCount = await Promise.all(
      userChats.map(async (row) => {
        const unreadCount = await this.getUnreadMessageCount(row.chat.id, userId);
        
        let lastMessageWithSender: MessageWithSender | undefined = undefined;
        if (row.lastMessage) {
          const sender = row.lastMessage.senderId === userId ? 
            (await this.getUserById(userId))! : row.otherUser!;
          lastMessageWithSender = {
            ...row.lastMessage,
            sender
          };
        }
        
        return {
          ...row.chat,
          otherUser: row.otherUser!,
          lastMessage: lastMessageWithSender,
          unreadCount,
          isOnline: row.otherUser?.isOnline || false,
        };
      })
    );

    return chatsWithUnreadCount;
  }

  async getChatById(chatId: string): Promise<Chat | undefined> {
    const [chat] = await db.select().from(chats).where(eq(chats.id, chatId));
    return chat;
  }

  async getChatByUsers(user1Id: string, user2Id: string): Promise<Chat | undefined> {
    const [chat] = await db
      .select()
      .from(chats)
      .where(
        or(
          and(eq(chats.user1Id, user1Id), eq(chats.user2Id, user2Id)),
          and(eq(chats.user1Id, user2Id), eq(chats.user2Id, user1Id))
        )
      );
    return chat;
  }

  // Update chat timestamp for real-time sorting
  async updateChatTimestamp(chatId: string): Promise<void> {
    await db
      .update(chats)
      .set({ updatedAt: new Date() })
      .where(eq(chats.id, chatId));
  }

  private async getUnreadMessageCount(chatId: string, userId: string): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(messages)
      .leftJoin(messageReadReceipts, 
        and(
          eq(messageReadReceipts.messageId, messages.id),
          eq(messageReadReceipts.userId, userId)
        )
      )
      .where(
        and(
          eq(messages.chatId, chatId),
          sql`${messageReadReceipts.id} IS NULL`,
          sql`${messages.senderId} != ${userId}`
        )
      );
    return result?.count || 0;
  }

  // Message operations
  async createMessage(messageData: InsertMessage): Promise<MessageWithSender> {
    const [message] = await db.insert(messages).values(messageData).returning();
    const sender = await this.getUserById(message.senderId);
    return { ...message, sender: sender! };
  }

  async getChatMessages(chatId: string, limit = 50, offset = 0): Promise<MessageWithSender[]> {
    const messagesList = await db
      .select({
        message: messages,
        sender: users,
      })
      .from(messages)
      .leftJoin(users, eq(messages.senderId, users.id))
      .where(eq(messages.chatId, chatId))
      .orderBy(desc(messages.createdAt))
      .limit(limit)
      .offset(offset);

    return messagesList.map(row => ({
      ...row.message,
      sender: row.sender!,
    })).reverse(); // Reverse to get chronological order
  }

  async getMessageById(messageId: string): Promise<MessageWithSender | undefined> {
    const [result] = await db
      .select({
        message: messages,
        sender: users,
      })
      .from(messages)
      .leftJoin(users, eq(messages.senderId, users.id))
      .where(eq(messages.id, messageId));

    if (!result) return undefined;
    
    return {
      ...result.message,
      sender: result.sender!,
    };
  }

  async updateMessage(messageId: string, updates: Partial<InsertMessage>): Promise<Message> {
    const [message] = await db
      .update(messages)
      .set(updates)
      .where(eq(messages.id, messageId))
      .returning();
    return message;
  }

  async deleteMessage(messageId: string): Promise<void> {
    await db.update(messages)
      .set({ isDeleted: true })
      .where(eq(messages.id, messageId));
  }

  async markMessageRead(messageId: string, userId: string): Promise<void> {
    // Insert read receipt if it doesn't exist
    await db
      .insert(messageReadReceipts)
      .values({ messageId, userId, status: 'read', readAt: new Date() })
      .onConflictDoUpdate({
        target: [messageReadReceipts.messageId, messageReadReceipts.userId],
        set: { status: 'read', readAt: new Date() }
      });

    console.log(`👀 Message ${messageId} marked as read by user ${userId}`);
  }

  async markMessageDelivered(messageId: string, userId: string): Promise<void> {
    // Insert delivery receipt if it doesn't exist, or update existing one
    await db
      .insert(messageReadReceipts)
      .values({ 
        messageId, 
        userId, 
        status: 'delivered',
        readAt: null 
      })
      .onConflictDoUpdate({
        target: [messageReadReceipts.messageId, messageReadReceipts.userId],
        set: { 
          status: 'delivered'
        }
      });

    console.log(`✅ Message ${messageId} marked as delivered to user ${userId}`);
  }

  async markChatMessagesAsRead(chatId: string, userId: string): Promise<void> {
    // Get all unread messages in the chat
    const unreadMessages = await db
      .select({ id: messages.id })
      .from(messages)
      .leftJoin(messageReadReceipts, 
        and(
          eq(messageReadReceipts.messageId, messages.id),
          eq(messageReadReceipts.userId, userId)
        )
      )
      .where(
        and(
          eq(messages.chatId, chatId),
          sql`${messageReadReceipts.id} IS NULL`,
          sql`${messages.senderId} != ${userId}`
        )
      );

    // Mark all as read
    for (const message of unreadMessages) {
      await this.markMessageRead(message.id, userId);
    }
  }

  // Call operations
  async createCall(callData: InsertCall): Promise<Call> {
    const [call] = await db.insert(calls).values(callData).returning();
    return call;
  }

  async getCallById(callId: string): Promise<CallWithUsers | undefined> {
    const [result] = await db
      .select({
        call: calls,
        caller: users,
        receiver: users,
      })
      .from(calls)
      .leftJoin(users, eq(calls.callerId, users.id))
      .leftJoin(users, eq(calls.receiverId, users.id))
      .where(eq(calls.id, callId));

    if (!result) return undefined;

    return {
      ...result.call,
      caller: result.caller!,
      receiver: result.receiver!,
    };
  }

  async updateCall(callId: string, updates: Partial<InsertCall>): Promise<Call> {
    // Always update the updatedAt timestamp for proper sorting
    const [call] = await db
      .update(calls)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(calls.id, callId))
      .returning();
    return call;
  }

  async getUserCalls(userId: string, limit = 50): Promise<CallWithUsers[]> {
    const userCalls = await db
      .select({
        call: calls,
        caller: users,
        receiver: users,
      })
      .from(calls)
      .leftJoin(users, eq(calls.callerId, users.id))
      .leftJoin(users, eq(calls.receiverId, users.id))
      .where(or(eq(calls.callerId, userId), eq(calls.receiverId, userId)))
      .orderBy(desc(calls.createdAt))
      .limit(limit);

    return userCalls.map(row => ({
      ...row.call,
      caller: row.caller!,
      receiver: row.receiver!,
    }));
  }

  async getActiveCall(userId: string): Promise<CallWithUsers | undefined> {
    const [result] = await db
      .select({
        call: calls,
        caller: users,
        receiver: users,
      })
      .from(calls)
      .leftJoin(users, eq(calls.callerId, users.id))
      .leftJoin(users, eq(calls.receiverId, users.id))
      .where(
        and(
          or(eq(calls.callerId, userId), eq(calls.receiverId, userId)),
          or(eq(calls.status, 'ringing'), eq(calls.status, 'answered'))
        )
      )
      .orderBy(desc(calls.createdAt));

    if (!result) return undefined;

    return {
      ...result.call,
      caller: result.caller!,
      receiver: result.receiver!,
    };
  }

  // Contact operations
  async addContact(userId: string, contactId: string, displayName?: string): Promise<Contact> {
    const [contact] = await db
      .insert(contacts)
      .values({ userId, contactId, displayName })
      .returning();
    return contact;
  }

  async getUserContacts(userId: string): Promise<ContactWithUser[]> {
    const userContacts = await db
      .select({
        contact: contacts,
        user: users,
      })
      .from(contacts)
      .leftJoin(users, eq(contacts.contactId, users.id))
      .where(and(eq(contacts.userId, userId), eq(contacts.isBlocked, false)))
      .orderBy(asc(users.firstName));

    return userContacts.map(row => ({
      ...row.contact,
      contact: row.user!,
    }));
  }

  async removeContact(userId: string, contactId: string): Promise<void> {
    await db
      .delete(contacts)
      .where(and(eq(contacts.userId, userId), eq(contacts.contactId, contactId)));
  }

  async blockContact(userId: string, contactId: string): Promise<void> {
    await db
      .update(contacts)
      .set({ isBlocked: true })
      .where(and(eq(contacts.userId, userId), eq(contacts.contactId, contactId)));
  }

  async unblockContact(userId: string, contactId: string): Promise<void> {
    await db
      .update(contacts)
      .set({ isBlocked: false })
      .where(and(eq(contacts.userId, userId), eq(contacts.contactId, contactId)));
  }

  async getUserByPhoneNumber(phoneNumber: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phoneNumber, phoneNumber));
    return user || undefined;
  }

  async createOTP(phoneNumber: string, countryCode: string, otp: string): Promise<void> {
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    await db.insert(otpVerifications).values({
      phoneNumber,
      countryCode,
      otp,
      expiresAt
    });
  }

  async deleteUser(userId: string): Promise<void> {
    // Delete all user-related data
    await db.delete(messageReadReceipts).where(eq(messageReadReceipts.userId, userId));
    await db.delete(messages).where(eq(messages.senderId, userId));
    await db.delete(calls).where(or(eq(calls.callerId, userId), eq(calls.receiverId, userId)));
    await db.delete(chats).where(or(eq(chats.user1Id, userId), eq(chats.user2Id, userId)));
    await db.delete(statuses).where(eq(statuses.userId, userId));
    await db.delete(users).where(eq(users.id, userId));
  }

  // Device token operations
  async addDeviceToken(userId: string, token: string, platform: string): Promise<DeviceToken> {
    // Deactivate existing tokens for this device
    await db
      .update(deviceTokens)
      .set({ isActive: false })
      .where(eq(deviceTokens.token, token));

    const [deviceToken] = await db
      .insert(deviceTokens)
      .values({ userId, token, platform })
      .returning();
    return deviceToken;
  }

  async removeDeviceToken(token: string): Promise<void> {
    await db
      .update(deviceTokens)
      .set({ isActive: false })
      .where(eq(deviceTokens.token, token));
  }

  async getUserDeviceTokens(userId: string): Promise<DeviceToken[]> {
    return await db
      .select()
      .from(deviceTokens)
      .where(and(eq(deviceTokens.userId, userId), eq(deviceTokens.isActive, true)));
  }

  // Status operations
  async createStatus(statusData: InsertStatus): Promise<Status> {
    const [status] = await db.insert(statuses).values(statusData).returning();
    return status;
  }

  async getUserStatuses(userId: string): Promise<StatusWithUser[]> {
    const userStatuses = await db
      .select({
        status: statuses,
        user: users,
      })
      .from(statuses)
      .leftJoin(users, eq(statuses.userId, users.id))
      .where(and(eq(statuses.userId, userId), sql`${statuses.expiresAt} > NOW()`))
      .orderBy(desc(statuses.createdAt));

    return Promise.all(
      userStatuses.map(async (row) => {
        const views = await db
          .select()
          .from(statusViews)
          .where(eq(statusViews.statusId, row.status.id));
        
        return {
          ...row.status,
          user: row.user!,
          views,
          viewCount: views.length,
          isViewed: false, // This should be calculated based on the requesting user
        };
      })
    );
  }

  async getContactStatuses(userId: string): Promise<StatusWithUser[]> {
    // Get statuses from user's contacts
    const contactStatuses = await db
      .select({
        status: statuses,
        user: users,
      })
      .from(statuses)
      .leftJoin(users, eq(statuses.userId, users.id))
      .leftJoin(contacts, eq(contacts.contactId, statuses.userId))
      .where(
        and(
          eq(contacts.userId, userId),
          eq(contacts.isBlocked, false),
          sql`${statuses.expiresAt} > NOW()`
        )
      )
      .orderBy(desc(statuses.createdAt));

    return Promise.all(
      contactStatuses.map(async (row) => {
        const views = await db
          .select()
          .from(statusViews)
          .where(eq(statusViews.statusId, row.status.id));
        
        const isViewed = views.some(view => view.viewerId === userId);
        
        return {
          ...row.status,
          user: row.user!,
          views,
          viewCount: views.length,
          isViewed,
        };
      })
    );
  }

  async viewStatus(statusId: string, viewerId: string): Promise<void> {
    await db
      .insert(statusViews)
      .values({ statusId, viewerId })
      .onConflictDoNothing();
  }

  async deleteExpiredStatuses(): Promise<void> {
    await db
      .delete(statuses)
      .where(sql`${statuses.expiresAt} < NOW()`);
  }

  // OTP verification methods
  async createOtpVerification(data: InsertOtpVerification): Promise<OtpVerification> {
    // Clean up expired OTPs first
    await db.delete(otpVerifications).where(lt(otpVerifications.expiresAt, new Date()));
    
    // Delete any existing OTP for this phone number
    await db.delete(otpVerifications).where(
      and(
        eq(otpVerifications.phoneNumber, data.phoneNumber),
        eq(otpVerifications.countryCode, data.countryCode)
      )
    );

    const [otpRecord] = await db.insert(otpVerifications).values(data).returning();
    return otpRecord;
  }

  async verifyOtp(phoneNumber: string, countryCode: string, otp: string): Promise<OtpVerification | null> {
    console.log('VerifyOtp - Looking for:', { phoneNumber, countryCode, otp });
    
    // First, let's see what OTP records we have
    const allOtps = await db
      .select()
      .from(otpVerifications)
      .where(
        and(
          eq(otpVerifications.phoneNumber, phoneNumber),
          eq(otpVerifications.countryCode, countryCode),
          eq(otpVerifications.isUsed, false)
        )
      );
    
    console.log('Available OTP records:', allOtps);
    
    const [otpRecord] = await db
      .select()
      .from(otpVerifications)
      .where(
        and(
          eq(otpVerifications.phoneNumber, phoneNumber),
          eq(otpVerifications.countryCode, countryCode),
          eq(otpVerifications.otp, otp),
          eq(otpVerifications.isUsed, false)
        )
      );

    console.log('Matching OTP record:', otpRecord);

    if (!otpRecord) {
      return null;
    }

    if (otpRecord.expiresAt < new Date()) {
      console.log('OTP expired, cleaning up');
      // Clean up expired OTP
      await db.delete(otpVerifications).where(eq(otpVerifications.id, otpRecord.id));
      return null;
    }

    // Mark as used
    await db
      .update(otpVerifications)
      .set({ isUsed: true })
      .where(eq(otpVerifications.id, otpRecord.id));

    console.log('OTP verification successful');
    return otpRecord;
  }

  // Search users by name, phone, or email
  async searchUsers(query: string, currentUserId: string): Promise<User[]> {
    const searchPattern = `%${query.toLowerCase()}%`;
    
    const searchResults = await db
      .select()
      .from(users)
      .where(
        and(
          // Exclude current user from search results
          sql`${users.id} != ${currentUserId}`,
          or(
            sql`LOWER(${users.firstName}) LIKE ${searchPattern}`,
            sql`LOWER(${users.lastName}) LIKE ${searchPattern}`,
            sql`LOWER(${users.email}) LIKE ${searchPattern}`,
            sql`${users.phoneNumber} LIKE ${searchPattern}`
          )
        )
      )
      .limit(50);

    return searchResults;
  }
}

export const storage = new DatabaseStorage();