import type { Express } from "express";
import type { Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { smartSearchService } from "./smartSearch";
import { wsManager } from "./websocket";
import { loginSchema, registerSchema, insertMessageSchema, insertStatusSchema } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";

// Extend Request type for userId
declare global {
  namespace Express {
    interface Request {
      userId?: string;
    }
  }
}

// Extend Express Session to include auth data
declare module 'express-session' {
  interface SessionData {
    userId?: string;
    isAuthenticated?: boolean;
    [key: string]: any; // Allow temporary OTP storage
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware with proper store
  const MemoryStoreSession = MemoryStore(session);
  
  app.use(session({
    name: 'vito.sid', // Explicit session name
    secret: process.env.SESSION_SECRET || 'vito-messaging-app-secret',
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    resave: true, // Force session save
    saveUninitialized: true, // Save uninitialized sessions
    cookie: { 
      secure: false, // Set to true in production with HTTPS
      httpOnly: false, // Allow JavaScript access for debugging
      sameSite: 'lax',
      path: '/',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    }
  }));



  // Middleware to check authentication using Authorization header
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    console.log('RequireAuth - Authorization header:', req.headers.authorization);
    
    const authHeader = req.headers.authorization;
    let authToken = null;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      authToken = authHeader.substring(7); // Remove 'Bearer ' prefix
    }
    
    console.log('RequireAuth - Auth token:', authToken);
    
    if (!authToken) {
      return res.status(401).json({ error: "Authentication required" });
    }
    
    // Store the user ID for use in the route
    req.userId = authToken;
    next();
  };

  // Auth routes - WhatsApp-style phone number authentication
  app.post("/api/auth/send-otp", async (req, res) => {
    try {
      const { phoneNumber, countryCode } = req.body;
      
      if (!phoneNumber || !countryCode) {
        return res.status(400).json({ error: 'Phone number and country code required' });
      }

      // SMART PHONE NUMBER HANDLING - Allow existing users to log back in
      const existingUser = await storage.getUserByPhone(phoneNumber, countryCode);
      if (existingUser && existingUser.hasCompletedProfile) {
        console.log(`📱 Existing account found for ${countryCode}${phoneNumber} - allowing OTP verification for login`);
        // Allow OTP to be sent for existing users to log back in
        // This will enable them to verify and access their existing account
      }

      // If there's an incomplete registration, clean it up first
      if (existingUser && !existingUser.hasCompletedProfile) {
        console.log(`🧹 Cleaning up incomplete registration for ${countryCode}${phoneNumber}`);
        await storage.deleteUserAccount(existingUser.id);
      }

      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      
      // For demo, log the OTP to console (remove in production)
      console.log(`📱 OTP for ${countryCode}${phoneNumber}: ${otp}`);
      
      // Store OTP in database instead of session
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes
      await storage.createOtpVerification({
        phoneNumber,
        countryCode,
        otp,
        expiresAt,
      });

      res.json({ 
        success: true, 
        message: 'OTP sent successfully',
        // Include OTP in development for testing
        ...(process.env.NODE_ENV === 'development' && { devOtp: otp }),
      });
    } catch (error) {
      console.error('Send OTP error:', error);
      res.status(500).json({ error: 'Failed to send OTP' });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const { otp, phoneNumber, countryCode } = req.body;
      
      console.log('OTP verification request:', { otp, phoneNumber, countryCode });
      
      if (!otp || !phoneNumber || !countryCode) {
        return res.status(400).json({ error: 'OTP, phone number, and country code are required' });
      }
      
      if (otp.length !== 6) {
        return res.status(400).json({ error: 'OTP must be 6 digits' });
      }

      // Verify OTP using database
      const otpRecord = await storage.verifyOtp(phoneNumber, countryCode, otp);
      
      console.log('OTP verification result:', otpRecord ? 'SUCCESS' : 'FAILED');
      
      if (!otpRecord) {
        return res.status(400).json({ error: 'Invalid or expired verification code' });
      }

      // Check if user exists or create new one
      let user = await storage.getUserByPhone(phoneNumber, countryCode);
      
      if (!user) {
        // Create new user for first-time registration
        console.log(`🆕 Creating new account for ${countryCode}${phoneNumber}`);
        user = await storage.createUser({
          phoneNumber,
          countryCode,
          isPhoneVerified: true,
          hasCompletedProfile: false,
        });
      } else {
        // Existing user logging back in
        console.log(`🔄 Existing user ${countryCode}${phoneNumber} logging back in`);
        user = await storage.updateUser(user.id, {
          isPhoneVerified: true,
          lastSeen: new Date(),
          isOnline: true
        });
      }

      // Generate a simple auth token and return it in response
      const authToken = user.id; // Simple token for now
      
      console.log('Auth token generated for user:', user.id);
      
      res.json({ 
        success: true, 
        user,
        token: authToken, // Send token for consistency
        message: 'Phone verified successfully' 
      });
    } catch (error) {
      console.error('Verify OTP error:', error);
      res.status(500).json({ error: 'OTP verification failed' });
    }
  });

  app.post("/api/auth/complete-profile", requireAuth, async (req, res) => {
    try {
      const { firstName, lastName, profileImageUrl } = req.body;
      
      if (!firstName || firstName.trim().length === 0) {
        return res.status(400).json({ error: 'First name is required' });
      }

      const updateData: any = {
        firstName: firstName.trim(),
        lastName: lastName?.trim() || '',
        hasCompletedProfile: true,
      };

      if (profileImageUrl) {
        updateData.profileImageUrl = profileImageUrl;
      }

      const user = await storage.updateUser(req.userId!, updateData);

      res.json({ 
        success: true,
        user,
        message: 'Profile completed successfully' 
      });
    } catch (error) {
      console.error('Complete profile error:', error);
      res.status(500).json({ error: 'Failed to complete profile' });
    }
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    try {
      const userId = req.userId!;
      
      console.log(`🚪 User ${userId} logging out - preserving account data on server`);
      
      // Update user status to offline (but keep all account data)
      await storage.updateUserOnlineStatus(userId, false);
      
      // Notify all contacts about logout in real-time
      await wsManager.notifyUserLogout(userId);
      
      // Force logout all WebSocket connections for this user
      wsManager.forceLogoutUser(userId, 'User logged out');
      
      // Clear any session data and cookies
      res.clearCookie('auth_token');
      res.clearCookie('vito.sid');
      
      console.log(`✅ User ${userId} logged out - account data preserved, sessions terminated`);
      
      res.json({ 
        success: true, 
        message: 'Logged out successfully. Account data preserved. Redirecting to login screen.',
        preserveAccountData: true // Flag to indicate data was preserved
      });
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({ error: 'Logout failed' });
    }
  });

  app.get("/api/logout", async (req: any, res) => {
    try {
      if (req.session?.userId) {
        await storage.updateUserOnlineStatus(req.session.userId, false);
      }
      req.session.destroy((err: any) => {
        if (err) {
          return res.redirect('/?error=logout_failed');
        }
        res.redirect('/');
      });
    } catch (error: any) {
      res.redirect('/?error=logout_failed');
    }
  });

  // Removed duplicate endpoint - already exists below

  app.post("/api/auth/accept-terms", requireAuth, async (req: any, res) => {
    try {
      await storage.updateUser(req.session.userId!, { hasAcceptedTerms: true });
      const user = await storage.getUserById(req.session.userId!);
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to update terms acceptance" });
    }
  });

  // Profile update endpoint
  app.put("/api/auth/profile", requireAuth, async (req: any, res) => {
    try {
      const { firstName, lastName, bio, email, profileImageUrl } = req.body;
      
      const updateData: any = {};
      if (firstName !== undefined) updateData.firstName = firstName.trim();
      if (lastName !== undefined) updateData.lastName = lastName.trim();
      if (bio !== undefined) updateData.bio = bio.trim();
      if (email !== undefined) updateData.email = email.trim();
      if (profileImageUrl !== undefined) updateData.profileImageUrl = profileImageUrl; // Support profile photo updates

      const user = await storage.updateUser(req.userId!, updateData);
      
      res.json({ 
        success: true,
        user,
        message: 'Profile updated successfully' 
      });
    } catch (error) {
      console.error('Update profile error:', error);
      res.status(500).json({ error: 'Failed to update profile' });
    }
  });

  // Call API routes
  app.post('/api/calls/initiate', requireAuth, async (req, res) => {
    try {
      const { receiverId, type } = req.body;
      
      if (!receiverId || !type) {
        return res.status(400).json({ error: 'Missing required fields' });
      }

      const call = await storage.createCall({
        callerId: req.userId!,
        receiverId,
        type,
        status: 'ringing'
      });

      // Get call with user details
      const callWithUsers = await storage.getCallById(call.id);
      
      // Notify receiver via WebSocket
      wsManager.sendToSpecificUser(receiverId, {
        type: 'call_incoming',
        call: callWithUsers!
      });

      res.json(callWithUsers);
    } catch (error) {
      console.error('Error initiating call:', error);
      res.status(500).json({ error: 'Failed to initiate call' });
    }
  });

  app.post('/api/calls/:callId/answer', requireAuth, async (req, res) => {
    try {
      const { callId } = req.params;
      
      const updatedCall = await storage.updateCall(callId, {
        status: 'active',
        startedAt: new Date()
      });

      if (!updatedCall) {
        return res.status(404).json({ error: 'Call not found' });
      }

      // Notify caller
      wsManager.sendToSpecificUser(updatedCall.callerId, {
        type: 'call_answered',
        callId
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Error answering call:', error);
      res.status(500).json({ error: 'Failed to answer call' });
    }
  });

  app.post('/api/calls/:callId/decline', requireAuth, async (req, res) => {
    try {
      const { callId } = req.params;
      
      const updatedCall = await storage.updateCall(callId, {
        status: 'declined',
        endedAt: new Date()
      });

      if (!updatedCall) {
        return res.status(404).json({ error: 'Call not found' });
      }

      // Notify caller
      wsManager.sendToSpecificUser(updatedCall.callerId, {
        type: 'call_declined',
        callId
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Error declining call:', error);
      res.status(500).json({ error: 'Failed to decline call' });
    }
  });

  app.post('/api/calls/:callId/end', requireAuth, async (req, res) => {
    try {
      const { callId } = req.params;
      
      const call = await storage.getCallById(callId);
      if (!call) {
        return res.status(404).json({ error: 'Call not found' });
      }

      const updatedCall = await storage.updateCall(callId, {
        status: 'ended',
        endedAt: new Date()
      });

      // Notify other participant
      const otherUserId = call.callerId === req.userId! ? call.receiverId : call.callerId;
      wsManager.sendToSpecificUser(otherUserId, {
        type: 'call_ended',
        callId
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Error ending call:', error);
      res.status(500).json({ error: 'Failed to end call' });
    }
  });

  // Enhanced Profile and Privacy API routes
  app.put('/api/users/profile', requireAuth, async (req, res) => {
    try {
      const updates = req.body;
      const updatedUser = await storage.updateUser(req.userId!, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ error: 'User not found' });
      }

      res.json(updatedUser);
    } catch (error) {
      console.error('Error updating profile:', error);
      res.status(500).json({ error: 'Failed to update profile' });
    }
  });

  app.post('/api/users/change-number', requireAuth, async (req, res) => {
    try {
      const { newPhoneNumber } = req.body;
      
      // Check if new number is already in use
      const existingUser = await storage.getUserByPhoneNumber(newPhoneNumber);
      if (existingUser) {
        return res.status(400).json({ error: 'Phone number already in use' });
      }

      // Generate OTP for verification
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      await storage.createOTP(newPhoneNumber, '+1', otp);

      // TODO: Send OTP via SMS service
      console.log(`OTP for number change: ${otp}`);

      res.json({ 
        success: true, 
        message: 'OTP sent to new number',
        // Development only - remove in production
        developmentOTP: otp
      });
    } catch (error) {
      console.error('Error changing number:', error);
      res.status(500).json({ error: 'Failed to change number' });
    }
  });

  app.delete('/api/users/account', requireAuth, async (req, res) => {
    try {
      await storage.deleteUser(req.userId!);

      // Notify all contacts that user deleted account
      wsManager.broadcast({
        type: 'user_account_deleted',
        userId: req.userId!
      });

      // Clear session
      req.session.destroy((err: any) => {
        if (err) console.error('Session destroy error:', err);
      });

      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting account:', error);
      res.status(500).json({ error: 'Failed to delete account' });
    }
  });

  // Get current authenticated user endpoint
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUserById(req.userId!);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ error: 'Failed to get user data' });
    }
  });

  // Account deletion endpoint - PERMANENT DELETION
  app.delete("/api/auth/delete-account", requireAuth, async (req, res) => {
    try {
      const userId = req.userId!;
      
      // Get user data before deletion
      const user = await storage.getUserById(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      console.log(`🗑️  ACCOUNT DELETION INITIATED: ${userId} (${user.countryCode}${user.phoneNumber})`);
      
      // Notify all contacts about account deletion in real-time BEFORE deletion
      await wsManager.notifyAccountDeletion(userId);
      
      // COMPREHENSIVE DATA CLEANUP - removes ALL related data and frees phone number
      await storage.deleteUserAccount(userId);
      
      // Clear all session cookies
      res.clearCookie('auth_token');
      res.clearCookie('vito.sid');

      console.log(`✅ ACCOUNT PERMANENTLY DELETED: ${userId} (${user.countryCode}${user.phoneNumber}) - Phone number freed for re-registration`);
      
      res.json({ 
        success: true,
        message: 'Account permanently deleted. Phone number is now available for re-registration.',
        redirect: true // Signal to frontend to redirect to welcome screen
      });
    } catch (error) {
      console.error('Delete account error:', error);
      res.status(500).json({ error: 'Failed to delete account' });
    }
  });

  // Chat routes
  app.get("/api/chats", requireAuth, async (req: any, res) => {
    try {
      const chats = await storage.getUserChats(req.userId);
      res.json(chats);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch chats" });
    }
  });

  app.post("/api/chats", requireAuth, async (req: any, res) => {
    try {
      const { otherUserId } = req.body;
      
      if (!otherUserId) {
        return res.status(400).json({ message: "otherUserId is required" });
      }

      // Check if chat already exists
      let chat = await storage.getChatByUsers(req.userId, otherUserId);
      
      if (!chat) {
        chat = await storage.createChat(req.userId, otherUserId);
      }

      res.json(chat);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to create chat" });
    }
  });

  // Message routes
  app.get("/api/chats/:chatId/messages", requireAuth, async (req: any, res) => {
    try {
      const { chatId } = req.params;
      const messages = await storage.getChatMessages(chatId);
      
      // Mark messages as read
      await storage.markChatMessagesAsRead(chatId, req.userId);
      
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/chats/:chatId/messages", requireAuth, async (req: any, res) => {
    try {
      const { chatId } = req.params;
      const messageData = insertMessageSchema.parse({
        ...req.body,
        chatId,
        senderId: req.userId,
      });

      const message = await storage.createMessage(messageData);
      
      // Get the message with sender details for WebSocket broadcast
      const messageWithSender = await storage.getMessageById(message.id);
      
      res.json(messageWithSender);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to send message" });
    }
  });

  // Search routes
  app.get("/api/users/search", requireAuth, async (req: any, res) => {
    try {
      const { q } = req.query;
      
      if (!q || typeof q !== "string") {
        return res.json([]);
      }

      const users = await storage.searchUsers(q, req.userId);
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Get user contacts
  app.get("/api/contacts", requireAuth, async (req: any, res) => {
    try {
      const contacts = await storage.getUserContacts(req.userId);
      res.json(contacts);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch contacts" });
    }
  });

  // Status routes
  app.get("/api/statuses", requireAuth, async (req: any, res) => {
    try {
      const statuses = await storage.getUserStatuses(req.userId);
      res.json(statuses);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch statuses" });
    }
  });

  app.get("/api/statuses/contacts", requireAuth, async (req: any, res) => {
    try {
      const statuses = await storage.getContactStatuses(req.userId);
      res.json(statuses);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch contact statuses" });
    }
  });

  app.post("/api/statuses", requireAuth, async (req: any, res) => {
    try {
      const data = insertStatusSchema.parse({
        ...req.body,
        userId: req.userId,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours from now
      });
      
      const status = await storage.createStatus(data);
      res.json(status);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to create status" });
    }
  });

  app.post("/api/statuses/:statusId/view", requireAuth, async (req: any, res) => {
    try {
      const { statusId } = req.params;
      await storage.viewStatus(statusId, req.userId);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: "Failed to mark status as viewed" });
    }
  });

  // Call routes
  app.get("/api/calls", requireAuth, async (req: any, res) => {
    try {
      const calls = await storage.getUserCalls(req.userId);
      res.json(calls);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch calls" });
    }
  });

  app.post("/api/calls", requireAuth, async (req: any, res) => {
    try {
      const { receiverId, callType } = req.body;
      
      if (!receiverId || !callType) {
        return res.status(400).json({ message: "receiverId and callType are required" });
      }

      const call = await storage.createCall({
        callerId: req.userId,
        receiverId,
        type: callType,
        status: 'ringing'
      });

      res.json(call);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to create call" });
    }
  });



  // File upload endpoint for media messages
  app.post("/api/upload", requireAuth, async (req: any, res) => {
    try {
      // Handle file upload for media messages
      // This would typically integrate with cloud storage
      res.json({ 
        success: true, 
        url: "https://example.com/uploaded-file.jpg",
        fileId: "file_" + Date.now()
      });
    } catch (error: any) {
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // Smart Search API endpoints
  app.post("/api/search/smart", requireAuth, async (req: any, res) => {
    try {
      const { query, searchType = "messages" } = req.body;
      
      if (!query || typeof query !== "string") {
        return res.status(400).json({ message: "Search query is required" });
      }

      // Mock data for demonstration - would query actual database in production
      const mockMessageHistory = [
        {
          chatName: "Alex Johnson",
          message: "Hey, the meeting is at Starbucks on 5th street at 3 PM tomorrow",
          timestamp: "2 days ago",
          sender: "Alex Johnson"
        },
        {
          chatName: "Sarah Wilson", 
          message: "Your flight confirmation: AA1234 departing 8:30 AM",
          timestamp: "1 week ago",
          sender: "Sarah Wilson"
        }
      ];

      const searchContext = {
        query,
        messageHistory: mockMessageHistory,
        mediaFiles: []
      };

      const results = await smartSearchService.searchMessages(searchContext);
      res.json({ results, query, searchType });
    } catch (error: any) {
      console.error("Smart search error:", error);
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Object Storage routes for media support in messages
  app.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    try {
      const { ObjectStorageService } = await import('./objectStorage');
      const objectStorageService = new ObjectStorageService();
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "Media file not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error) {
      console.error("Error serving media file:", error);
      return res.status(500).json({ error: "Media service error" });
    }
  });

  app.post("/api/media/upload", requireAuth, async (req, res) => {
    try {
      const { ObjectStorageService } = await import('./objectStorage');
      const objectStorageService = new ObjectStorageService();
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ 
        uploadURL,
        message: "Upload URL generated for media file"
      });
    } catch (error) {
      console.error("Error generating media upload URL:", error);
      res.status(500).json({ error: "Failed to generate upload URL" });
    }
  });

  app.get("/objects/:objectPath(*)", requireAuth, async (req, res) => {
    try {
      const { ObjectStorageService, ObjectNotFoundError } = await import('./objectStorage');
      const objectStorageService = new ObjectStorageService();
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      objectStorageService.downloadObject(objectFile, res);
    } catch (error: any) {
      console.error("Error accessing media object:", error);
      if (error?.constructor?.name === 'ObjectNotFoundError') {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  // Create HTTP server and initialize WebSocket manager
  const httpServer = createServer(app);
  wsManager.init(httpServer);

  return httpServer;
}
