import Anthropic from '@anthropic-ai/sdk';

const DEFAULT_MODEL_STR = "claude-sonnet-4-20250514";

// Initialize Anthropic client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface SearchContext {
  query: string;
  messageHistory: Array<{
    chatName: string;
    message: string;
    timestamp: string;
    sender: string;
  }>;
  mediaFiles: Array<{
    fileName: string;
    type: string;
    chatName: string;
    timestamp: string;
  }>;
}

interface SearchResult {
  type: 'message' | 'media' | 'summary';
  chatName: string;
  content: string;
  relevanceScore: number;
  context: string;
  timestamp: string;
  aiSummary?: string;
}

export class SmartSearchService {
  async searchMessages(context: SearchContext): Promise<SearchResult[]> {
    if (!process.env.ANTHROPIC_API_KEY) {
      // Return mock data when API key is not available
      return this.getMockSearchResults(context.query);
    }

    try {
      const prompt = `
You are an AI assistant helping users search through their messaging history with semantic understanding.

User Query: "${context.query}"

Message History:
${context.messageHistory.map(msg => 
  `${msg.chatName} (${msg.timestamp}): ${msg.message}`
).join('\n')}

Please analyze the query and find the most relevant messages. Consider:
1. Semantic meaning, not just keyword matching
2. Context and intent behind the query
3. Temporal references (when, yesterday, last week, etc.)
4. Relationship between different messages
5. Implied requests (e.g., "meeting location" could match messages about addresses)

Return a JSON array of search results with this structure:
{
  "results": [
    {
      "type": "message",
      "chatName": "Contact Name",
      "content": "The relevant message content",
      "relevanceScore": 0.95,
      "context": "Brief explanation of why this matches",
      "timestamp": "2 days ago",
      "aiSummary": "Brief AI interpretation of the message"
    }
  ]
}

Focus on the top 5 most relevant results.
`;

      const response = await anthropic.messages.create({
        model: DEFAULT_MODEL_STR,
        max_tokens: 2000,
        messages: [{ role: 'user', content: prompt }]
      });

      const result = JSON.parse(response.content[0].text);
      return result.results || [];
    } catch (error) {
      console.error('Smart search error:', error);
      return this.getMockSearchResults(context.query);
    }
  }

  async generateChatSummary(chatName: string, messages: Array<any>): Promise<string> {
    if (!process.env.ANTHROPIC_API_KEY) {
      return `Summary of recent conversations with ${chatName} covering work discussions, meeting planning, and casual updates.`;
    }

    try {
      const prompt = `
Analyze this conversation and provide a concise summary:

Chat: ${chatName}
Messages:
${messages.map(msg => `${msg.timestamp}: ${msg.content}`).join('\n')}

Provide:
1. Main topics discussed
2. Key decisions or outcomes
3. Important dates or events mentioned
4. Overall tone and context

Keep the summary under 100 words.
`;

      const response = await anthropic.messages.create({
        model: DEFAULT_MODEL_STR,
        max_tokens: 500,
        messages: [{ role: 'user', content: prompt }]
      });

      return response.content[0].text;
    } catch (error) {
      console.error('Chat summary error:', error);
      return `Summary of recent conversations with ${chatName}.`;
    }
  }

  async categorizeMedia(mediaFiles: Array<any>): Promise<Array<any>> {
    if (!process.env.ANTHROPIC_API_KEY) {
      return mediaFiles.map(file => ({
        ...file,
        category: this.inferCategory(file.fileName),
        aiTags: ['general']
      }));
    }

    try {
      const prompt = `
Categorize these media files and generate relevant tags:

Files:
${mediaFiles.map(file => `${file.fileName} (${file.type}) from ${file.chatName}`).join('\n')}

For each file, determine:
1. Category (Work, Travel, Food, Personal, etc.)
2. Relevant tags based on filename and context
3. Brief description if possible

Return JSON format:
{
  "categorized": [
    {
      "fileName": "...",
      "category": "Travel",
      "aiTags": ["vacation", "beach", "photos"],
      "description": "Beach vacation photos"
    }
  ]
}
`;

      const response = await anthropic.messages.create({
        model: DEFAULT_MODEL_STR,
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }]
      });

      const result = JSON.parse(response.content[0].text);
      return result.categorized || mediaFiles;
    } catch (error) {
      console.error('Media categorization error:', error);
      return mediaFiles.map(file => ({
        ...file,
        category: this.inferCategory(file.fileName),
        aiTags: ['general']
      }));
    }
  }

  private getMockSearchResults(query: string): SearchResult[] {
    // Enhanced mock data based on query understanding
    const mockResults: SearchResult[] = [
      {
        type: 'message',
        chatName: 'Alex Johnson',
        content: 'Hey, the meeting is at Starbucks on 5th street at 3 PM tomorrow',
        relevanceScore: 0.95,
        context: 'Meeting location request',
        timestamp: '2 days ago',
        aiSummary: 'Meeting location and time details'
      },
      {
        type: 'message',
        chatName: 'Sarah Wilson',
        content: 'Your flight confirmation: AA1234 departing 8:30 AM',
        relevanceScore: 0.88,
        context: 'Travel documents',
        timestamp: '1 week ago',
        aiSummary: 'Flight ticket information'
      }
    ];

    // Filter based on query relevance
    if (query.toLowerCase().includes('meeting')) {
      return mockResults.filter(r => r.context.includes('Meeting'));
    }
    if (query.toLowerCase().includes('flight') || query.toLowerCase().includes('ticket')) {
      return mockResults.filter(r => r.context.includes('Travel'));
    }

    return mockResults;
  }

  private inferCategory(fileName: string): string {
    const name = fileName.toLowerCase();
    if (name.includes('photo') || name.includes('img') || name.includes('pic')) return 'Photos';
    if (name.includes('doc') || name.includes('pdf') || name.includes('txt')) return 'Documents';
    if (name.includes('video') || name.includes('mp4') || name.includes('mov')) return 'Videos';
    if (name.includes('audio') || name.includes('mp3') || name.includes('wav')) return 'Audio';
    return 'General';
  }
}

export const smartSearchService = new SmartSearchService();