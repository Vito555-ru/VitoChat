import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Phone, Shield, MessageCircle, Camera, Mic, Contact, ChevronRight, Check, User } from "lucide-react";
import vitoLogoUrl from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754902665155.png";
import { CircularImageCropper } from './CircularImageCropper';

type OnboardingStep = 'welcome' | 'terms' | 'phone' | 'otp' | 'permissions' | 'profile' | 'complete';

interface OnboardingFlowProps {
  currentStep: OnboardingStep;
  onNext: (nextStep: OnboardingStep) => void;
  onAuthSuccess: (user: any) => void;
}

interface PhoneData {
  countryCode: string;
  phoneNumber: string;
  otp: string;
  firstName: string;
  lastName: string;
  profileImage: string;
}

const countryCodes = [
  { code: "+92", name: "Pakistan", flag: "🇵🇰" },
  { code: "+1", name: "United States", flag: "🇺🇸" },
  { code: "+44", name: "United Kingdom", flag: "🇬🇧" },
  { code: "+91", name: "India", flag: "🇮🇳" },
  { code: "+86", name: "China", flag: "🇨🇳" },
  { code: "+49", name: "Germany", flag: "🇩🇪" },
  { code: "+33", name: "France", flag: "🇫🇷" },
  { code: "+81", name: "Japan", flag: "🇯🇵" },
  { code: "+82", name: "South Korea", flag: "🇰🇷" },
  { code: "+971", name: "UAE", flag: "🇦🇪" },
  { code: "+966", name: "Saudi Arabia", flag: "🇸🇦" },
  { code: "+90", name: "Turkey", flag: "🇹🇷" },
  { code: "+7", name: "Russia", flag: "🇷🇺" },
  { code: "+55", name: "Brazil", flag: "🇧🇷" },
  { code: "+52", name: "Mexico", flag: "🇲🇽" },
  { code: "+61", name: "Australia", flag: "🇦🇺" },
  { code: "+64", name: "New Zealand", flag: "🇳🇿" },
  { code: "+27", name: "South Africa", flag: "🇿🇦" },
  { code: "+234", name: "Nigeria", flag: "🇳🇬" },
  { code: "+20", name: "Egypt", flag: "🇪🇬" },
];

export default function OnboardingFlow({ currentStep, onNext, onAuthSuccess }: OnboardingFlowProps) {
  const [phoneData, setPhoneData] = useState<PhoneData>({
    countryCode: '+92',
    phoneNumber: '',
    otp: '',
    firstName: '',
    lastName: '',
    profileImage: ''
  });
  const [devOtp, setDevOtp] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [permissions, setPermissions] = useState({
    contacts: false,
    camera: false,
    microphone: false,
    notifications: false
  });
  const [showImageCropper, setShowImageCropper] = useState(false);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const { toast } = useToast();

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImageFile(file);
      setShowImageCropper(true);
    }
  };

  const handleImageCrop = (croppedImageUrl: string) => {
    setPhoneData(prev => ({ ...prev, profileImage: croppedImageUrl }));
    setShowImageCropper(false);
    setSelectedImageFile(null);
  };

  const handleSendOTP = async () => {
    if (!phoneData.phoneNumber.trim()) {
      toast({
        title: "Error",
        description: "Please enter your phone number",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phoneData.phoneNumber,
          countryCode: phoneData.countryCode
        })
      });

      if (response.ok) {
        const result = await response.json();
        if (result.devOtp) {
          setDevOtp(result.devOtp);
        }
        toast({
          title: "OTP Sent",
          description: result.devOtp ? `Development OTP: ${result.devOtp}` : "Check your messages for the verification code",
        });
        onNext('otp');
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.message || "Failed to send OTP",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Network error. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!phoneData.otp.trim()) {
      toast({
        title: "Error",
        description: "Please enter the verification code",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phoneData.phoneNumber,
          countryCode: phoneData.countryCode,
          otp: phoneData.otp
        })
      });

      if (response.ok) {
        const result = await response.json();
        // Store auth token from OTP verification
        if (result.token) {
          localStorage.setItem('auth_token', result.token);
        }
        onNext('permissions');
      } else {
        const error = await response.json();
        toast({
          title: "Verification Failed",
          description: error.message || "Invalid verification code",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Network error. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompleteProfile = async () => {
    if (!phoneData.firstName.trim() || !phoneData.lastName.trim()) {
      toast({
        title: "Error",
        description: "Please enter your first and last name",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      // Get auth token from verification step
      const authToken = localStorage.getItem('auth_token');
      if (!authToken) {
        toast({
          title: "Authentication Error",
          description: "Please verify your phone number again",
          variant: "destructive"
        });
        onNext('phone');
        return;
      }

      const response = await fetch('/api/auth/complete-profile', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          firstName: phoneData.firstName,
          lastName: phoneData.lastName,
          profileImageUrl: phoneData.profileImage, // Fix: backend expects profileImageUrl
        })
      });

      if (response.ok) {
        const result = await response.json();
        localStorage.setItem('hasCompletedOnboarding', 'true');
        onAuthSuccess(result.user);
      } else {
        const error = await response.json();
        toast({
          title: "Registration Failed",
          description: error.message || "Failed to create account",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Network error. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderWelcomeScreen = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-0 bg-white/95 backdrop-blur">
        <CardHeader className="text-center pb-8">
          <div className="w-20 h-20 mx-auto mb-6">
            <img src={vitoLogoUrl} alt="VITO Logo" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-3xl font-bold text-gray-800 mb-2">Welcome to VITO</CardTitle>
          <CardDescription className="text-gray-600 text-lg leading-relaxed">
            Secure messaging for the modern world. Connect with friends and family with end-to-end encryption.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-lg">
              <MessageCircle className="w-6 h-6 text-blue-600" />
              <div>
                <h3 className="font-semibold text-gray-800">Instant Messaging</h3>
                <p className="text-sm text-gray-600">Real-time conversations</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg">
              <Shield className="w-6 h-6 text-green-600" />
              <div>
                <h3 className="font-semibold text-gray-800">End-to-End Encryption</h3>
                <p className="text-sm text-gray-600">Your privacy is protected</p>
              </div>
            </div>
          </div>
          <Button onClick={() => onNext('terms')} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg">
            Get Started
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderTermsScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800">Terms & Privacy</CardTitle>
          <CardDescription className="text-gray-600">
            Please read and accept our terms to continue
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg max-h-64 overflow-y-auto">
            <h3 className="font-semibold mb-2">Terms of Service</h3>
            <p className="text-sm text-gray-600 mb-4">
              By using VITO, you agree to our terms of service. VITO is provided by Blackhole Networks.
            </p>
            <h3 className="font-semibold mb-2">Privacy Policy</h3>
            <p className="text-sm text-gray-600">
              We respect your privacy. Your messages are encrypted end-to-end and we do not access your personal conversations.
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox id="terms" required />
            <Label htmlFor="terms" className="text-sm text-gray-700">
              I agree to the Terms of Service and Privacy Policy
            </Label>
          </div>
          <Button onClick={() => onNext('phone')} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Accept & Continue
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderPhoneScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img src={vitoLogoUrl} alt="VITO Logo" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Enter Your Phone Number</CardTitle>
          <CardDescription className="text-gray-600">
            We'll send you a verification code to confirm your number
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="country">Country</Label>
              <Select value={phoneData.countryCode} onValueChange={(value) => setPhoneData(prev => ({ ...prev, countryCode: value }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  {countryCodes.map((country) => (
                    <SelectItem key={country.code} value={country.code}>
                      {country.flag} {country.name} ({country.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="flex">
                <div className="flex items-center px-3 border border-r-0 rounded-l-md bg-gray-50">
                  <span className="text-gray-600">{phoneData.countryCode}</span>
                </div>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter your phone number"
                  value={phoneData.phoneNumber}
                  onChange={(e) => setPhoneData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                  className="rounded-l-none"
                />
              </div>
            </div>
          </div>
          <Button onClick={handleSendOTP} disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            {isLoading ? "Sending..." : "Send Verification Code"}
            <Phone className="w-4 h-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderOTPScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800">Verify Your Number</CardTitle>
          <CardDescription className="text-gray-600">
            Enter the 6-digit code sent to {phoneData.countryCode} {phoneData.phoneNumber}
          </CardDescription>
          {devOtp && (
            <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Development OTP:</strong> {devOtp}
              </p>
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="otp">Verification Code</Label>
            <Input
              id="otp"
              type="text"
              placeholder="Enter 6-digit code"
              value={phoneData.otp}
              onChange={(e) => setPhoneData(prev => ({ ...prev, otp: e.target.value }))}
              maxLength={6}
              className="text-center text-2xl tracking-widest"
            />
          </div>
          <Button onClick={handleVerifyOTP} disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            {isLoading ? "Verifying..." : "Verify Code"}
            <Check className="w-4 h-4 ml-2" />
          </Button>
          <Button variant="outline" onClick={() => onNext('phone')} className="w-full">
            Change Phone Number
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderPermissionsScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800">Allow Access</CardTitle>
          <CardDescription className="text-gray-600">
            Enable these permissions for the best VITO experience
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-3">
                <Contact className="w-6 h-6 text-blue-600" />
                <div>
                  <h3 className="font-semibold">Contacts</h3>
                  <p className="text-sm text-gray-500">Find friends on VITO</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.contacts}
                onCheckedChange={(checked) => setPermissions(prev => ({ ...prev, contacts: checked as boolean }))}
              />
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-3">
                <Camera className="w-6 h-6 text-green-600" />
                <div>
                  <h3 className="font-semibold">Camera</h3>
                  <p className="text-sm text-gray-500">Take photos and videos</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.camera}
                onCheckedChange={(checked) => setPermissions(prev => ({ ...prev, camera: checked as boolean }))}
              />
            </div>
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-3">
                <Mic className="w-6 h-6 text-purple-600" />
                <div>
                  <h3 className="font-semibold">Microphone</h3>
                  <p className="text-sm text-gray-500">Send voice messages</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.microphone}
                onCheckedChange={(checked) => setPermissions(prev => ({ ...prev, microphone: checked as boolean }))}
              />
            </div>
          </div>
          <Button onClick={() => onNext('profile')} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Continue
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderProfileScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img src={vitoLogoUrl} alt="VITO Logo" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Profile Setup</CardTitle>
          <CardDescription className="text-gray-600">
            Tell us a bit about yourself
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
                {phoneData.profileImage ? (
                  <img 
                    src={phoneData.profileImage} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : phoneData.firstName ? (
                  <span className="text-2xl font-semibold text-gray-600">
                    {phoneData.firstName.charAt(0).toUpperCase()}
                    {phoneData.lastName.charAt(0).toUpperCase()}
                  </span>
                ) : (
                  <User className="w-8 h-8 text-gray-400" />
                )}
              </div>
              <label className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                <Camera className="w-4 h-4 text-white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                placeholder="Enter your first name"
                value={phoneData.firstName}
                onChange={(e) => setPhoneData(prev => ({ ...prev, firstName: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                placeholder="Enter your last name"
                value={phoneData.lastName}
                onChange={(e) => setPhoneData(prev => ({ ...prev, lastName: e.target.value }))}
              />
            </div>
          </div>

          <Button 
            onClick={handleCompleteProfile}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isLoading ? "Creating Account..." : "Complete Setup"}
            <Check className="w-4 h-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const stepComponents = {
    welcome: renderWelcomeScreen,
    terms: renderTermsScreen,
    phone: renderPhoneScreen,
    otp: renderOTPScreen,
    permissions: renderPermissionsScreen,
    profile: renderProfileScreen,
    complete: () => null
  };

  return (
    <>
      {stepComponents[currentStep]()}
      
      {/* Circular Image Cropper */}
      <CircularImageCropper
        open={showImageCropper}
        onClose={() => {
          setShowImageCropper(false);
          setSelectedImageFile(null);
        }}
        onCrop={handleImageCrop}
        imageFile={selectedImageFile}
      />
    </>
  );
}