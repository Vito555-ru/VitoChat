import { useState, useEffect, useRef } from 'react';
import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import type { CallWithUsers } from '@shared/schema';

interface CallInterfaceProps {
  call: CallWithUsers;
  onEndCall: () => void;
  onToggleMute: () => void;
  onToggleVideo: () => void;
  onToggleSpeaker: () => void;
  isMuted: boolean;
  isVideoEnabled: boolean;
  isSpeakerOn: boolean;
}

export function CallInterface({
  call,
  onEndCall,
  onToggleMute,
  onToggleVideo,
  onToggleSpeaker,
  isMuted,
  isVideoEnabled,
  isSpeakerOn
}: CallInterfaceProps) {
  const [callDuration, setCallDuration] = useState(0);
  const [isCallActive, setIsCallActive] = useState(call.status === 'active');
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  // Format call duration
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Call timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isCallActive) {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isCallActive]);

  // Update call status
  useEffect(() => {
    setIsCallActive(call.status === 'active');
    if (call.status === 'ended' || call.status === 'declined') {
      setCallDuration(0);
    }
  }, [call.status]);

  const isVideoCall = call.type === 'video';
  const otherUser = call.callerId === call.caller.id ? call.receiver : call.caller;

  return (
    <div className="fixed inset-0 z-50 bg-gray-900 flex flex-col">
      {/* Video containers for video calls */}
      {isVideoCall && (
        <>
          {/* Remote video (full screen) */}
          <div className="flex-1 relative bg-black">
            <video
              ref={remoteVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
            />
            
            {/* Local video (small window) */}
            <div className="absolute top-4 right-4 w-32 h-24 bg-gray-800 rounded-lg overflow-hidden border-2 border-white">
              <video
                ref={localVideoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
                muted
              />
            </div>
          </div>
        </>
      )}

      {/* Voice call UI or video call overlay */}
      <div className={`${isVideoCall ? 'absolute inset-0 bg-black bg-opacity-50' : 'flex-1 bg-gradient-to-b from-blue-600 to-blue-800'} flex flex-col justify-center items-center text-white`}>
        
        {/* User info and status */}
        <div className="text-center mb-8">
          <Avatar className="w-32 h-32 mx-auto mb-4 border-4 border-white">
            <AvatarImage src={otherUser.profileImageUrl || undefined} />
            <AvatarFallback className="text-4xl bg-blue-500">
              {otherUser.firstName?.[0]}{otherUser.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          
          <h2 className="text-2xl font-semibold mb-2">
            {otherUser.firstName} {otherUser.lastName}
          </h2>
          
          <p className="text-lg opacity-90">
            {call.status === 'ringing' && 'Calling...'}
            {call.status === 'active' && formatDuration(callDuration)}
            {call.status === 'ended' && 'Call ended'}
            {call.status === 'declined' && 'Call declined'}
          </p>
        </div>

        {/* Call controls */}
        <div className="flex items-center space-x-6">
          {/* Mute button */}
          <Button
            size="lg"
            variant={isMuted ? "destructive" : "secondary"}
            className="w-16 h-16 rounded-full"
            onClick={onToggleMute}
          >
            {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
          </Button>

          {/* Video toggle (only for video calls) */}
          {isVideoCall && (
            <Button
              size="lg"
              variant={isVideoEnabled ? "secondary" : "destructive"}
              className="w-16 h-16 rounded-full"
              onClick={onToggleVideo}
            >
              {isVideoEnabled ? <Video size={24} /> : <VideoOff size={24} />}
            </Button>
          )}

          {/* Speaker toggle */}
          <Button
            size="lg"
            variant={isSpeakerOn ? "secondary" : "outline"}
            className="w-16 h-16 rounded-full"
            onClick={onToggleSpeaker}
          >
            <Volume2 size={24} />
          </Button>

          {/* End call button */}
          <Button
            size="lg"
            variant="destructive"
            className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
            onClick={onEndCall}
          >
            <PhoneOff size={24} />
          </Button>
        </div>
      </div>

      {/* Call statistics (for active calls) */}
      {call.status === 'active' && (
        <div className="absolute top-4 left-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-sm">
          {formatDuration(callDuration)}
        </div>
      )}
    </div>
  );
}