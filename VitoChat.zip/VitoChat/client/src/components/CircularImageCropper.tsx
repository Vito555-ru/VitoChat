import { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Slider } from '@/components/ui/slider';
import { RotateCcw, ZoomIn, ZoomOut, Check, X } from 'lucide-react';

interface CircularImageCropperProps {
  open: boolean;
  onClose: () => void;
  onCrop: (croppedImageUrl: string) => void;
  imageFile: File | null;
}

export function CircularImageCropper({ open, onClose, onCrop, imageFile }: CircularImageCropperProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scale, setScale] = useState([1]);
  const [rotation, setRotation] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [imagePosition, setImagePosition] = useState({ x: 0, y: 0 });
  const [imageData, setImageData] = useState<HTMLImageElement | null>(null);

  const CROP_SIZE = 300; // Fixed circle size

  useEffect(() => {
    if (imageFile && open) {
      const img = new Image();
      img.onload = () => {
        setImageData(img);
        // Center the image initially
        const canvas = canvasRef.current;
        if (canvas) {
          const centerX = (canvas.width - img.width * scale[0]) / 2;
          const centerY = (canvas.height - img.height * scale[0]) / 2;
          setImagePosition({ x: centerX, y: centerY });
        }
      };
      img.src = URL.createObjectURL(imageFile);
    }
  }, [imageFile, open]);

  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || !imageData) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Save context
    ctx.save();

    // Draw image with transformations
    ctx.translate(imagePosition.x + (imageData.width * scale[0]) / 2, imagePosition.y + (imageData.height * scale[0]) / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.scale(scale[0], scale[0]);
    ctx.drawImage(imageData, -imageData.width / 2, -imageData.height / 2);

    // Restore context
    ctx.restore();

    // Draw crop circle overlay
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = CROP_SIZE / 2;

    // Create overlay (darken everything outside circle)
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Cut out circle
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.fill();

    // Draw circle border
    ctx.globalCompositeOperation = 'source-over';
    ctx.strokeStyle = '#3B82F6';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    ctx.stroke();

    ctx.restore();
  }, [imageData, imagePosition, scale, rotation]);

  useEffect(() => {
    drawCanvas();
  }, [drawCanvas]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - imagePosition.x, y: e.clientY - imagePosition.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setImagePosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetImage = () => {
    setScale([1]);
    setRotation(0);
    if (imageData && canvasRef.current) {
      const canvas = canvasRef.current;
      const centerX = (canvas.width - imageData.width) / 2;
      const centerY = (canvas.height - imageData.height) / 2;
      setImagePosition({ x: centerX, y: centerY });
    }
  };

  const cropImage = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx || !imageData) return;

    // Create a new canvas for the cropped image
    const cropCanvas = document.createElement('canvas');
    const cropCtx = cropCanvas.getContext('2d');
    if (!cropCtx) return;

    cropCanvas.width = CROP_SIZE;
    cropCanvas.height = CROP_SIZE;

    // Calculate the crop area
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = CROP_SIZE / 2;

    // Create circular clip
    cropCtx.beginPath();
    cropCtx.arc(radius, radius, radius, 0, 2 * Math.PI);
    cropCtx.clip();

    // Draw the transformed image portion within the circle
    cropCtx.save();
    cropCtx.translate(radius, radius);
    cropCtx.translate(imagePosition.x - centerX + (imageData.width * scale[0]) / 2, imagePosition.y - centerY + (imageData.height * scale[0]) / 2);
    cropCtx.rotate((rotation * Math.PI) / 180);
    cropCtx.scale(scale[0], scale[0]);
    cropCtx.drawImage(imageData, -imageData.width / 2, -imageData.height / 2);
    cropCtx.restore();

    // Convert to blob and pass back
    cropCanvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        onCrop(url);
        onClose();
      }
    }, 'image/jpeg', 0.9);
  };

  if (!open || !imageFile) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Crop Profile Photo</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="relative border rounded-lg overflow-hidden bg-gray-100">
            <canvas
              ref={canvasRef}
              width={400}
              height={400}
              className="w-full h-full cursor-move"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <ZoomOut className="w-4 h-4" />
              <Slider
                value={scale}
                onValueChange={setScale}
                min={0.5}
                max={3}
                step={0.1}
                className="flex-1"
              />
              <ZoomIn className="w-4 h-4" />
            </div>

            <div className="flex items-center space-x-3">
              <RotateCcw className="w-4 h-4" />
              <Slider
                value={[rotation]}
                onValueChange={(value) => setRotation(value[0])}
                min={-180}
                max={180}
                step={1}
                className="flex-1"
              />
              <span className="text-sm text-gray-500 w-12">{rotation}°</span>
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <Button variant="outline" onClick={resetImage}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
            
            <div className="flex space-x-2">
              <Button variant="outline" onClick={onClose}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={cropImage} className="bg-blue-600 hover:bg-blue-700">
                <Check className="w-4 h-4 mr-2" />
                Apply
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}