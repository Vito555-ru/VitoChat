import { useState } from "react";
import { useChats, useSearchUsers, useCreateChat } from "@/hooks/useMessages";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, MessageCircle, Plus } from "lucide-react";
import type { ChatWithUsers, User } from "@shared/schema";

interface ChatListProps {
  onChatSelect: (chat: ChatWithUsers) => void;
}

export function ChatList({ onChatSelect }: ChatListProps) {
  const [activeTab, setActiveTab] = useState<"chats" | "status" | "calls">("chats");
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewChat, setShowNewChat] = useState(false);

  const { data: chats, isLoading: chatsLoading } = useChats();
  const { data: searchResults, isLoading: searchLoading } = useSearchUsers(searchQuery);
  const createChatMutation = useCreateChat();

  const handleCreateChat = async (user: User) => {
    try {
      await createChatMutation.mutateAsync(user.id);
      setShowNewChat(false);
      setSearchQuery("");
    } catch (error) {
      console.error("Failed to create chat:", error);
    }
  };

  const formatTime = (date: Date | string) => {
    const messageDate = new Date(date);
    const now = new Date();
    const diffInHours = (now.getTime() - messageDate.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return messageDate.toLocaleTimeString('en-US', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      });
    } else {
      return messageDate.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric' 
      });
    }
  };

  const getDefaultAvatar = (name: string) => {
    const initials = name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
    
    return (
      <div className="w-12 h-12 rounded-full bg-vito-blue flex items-center justify-center text-white font-semibold">
        {initials}
      </div>
    );
  };

  if (chatsLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-white">
      {/* Header */}
      <header className="bg-vito-blue text-white px-4 py-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <MessageCircle className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-semibold font-inter">VITO</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white hover:bg-opacity-10"
              onClick={() => setShowNewChat(!showNewChat)}
            >
              <Plus className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white hover:bg-opacity-10"
            >
              <Search className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <nav className="bg-vito-blue border-b border-vito-dark">
        <div className="flex">
          {[
            { id: "chats", label: "Chats" },
            { id: "status", label: "Status" },
            { id: "calls", label: "Calls" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 py-3 text-center font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "text-white border-white"
                  : "text-blue-100 border-transparent hover:text-white"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </nav>

      {/* New Chat Search */}
      {showNewChat && (
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Search users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          {searchLoading && (
            <div className="flex items-center justify-center py-4">
              <LoadingSpinner size="sm" />
            </div>
          )}
          
          {searchResults && searchResults.length > 0 && (
            <div className="mt-2 space-y-2 max-h-48 overflow-y-auto">
              {searchResults.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center space-x-3 p-2 hover:bg-gray-100 rounded cursor-pointer"
                  onClick={() => handleCreateChat(user)}
                >
                  {user.profileImageUrl ? (
                    <img
                      src={user.profileImageUrl}
                      alt={user.username || user.email}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-vito-blue flex items-center justify-center text-white text-sm font-semibold">
                      {(user.username || user.email)[0].toUpperCase()}
                    </div>
                  )}
                  <div>
                    <p className="font-medium text-sm">{user.username || user.firstName || user.email}</p>
                    <p className="text-xs text-gray-500">{user.email}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto">
        {activeTab === "chats" && (
          <>
            {!chats || chats.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-gray-500 p-8">
                <MessageCircle className="w-16 h-16 mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No chats yet</h3>
                <p className="text-sm text-center">Start a conversation by searching for users above</p>
              </div>
            ) : (
              chats.map((chat) => (
                <div
                  key={chat.id}
                  className="border-b border-gray-100 px-4 py-3 hover:bg-gray-50 transition-colors cursor-pointer"
                  onClick={() => onChatSelect(chat)}
                >
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      {chat.otherUser.profileImageUrl ? (
                        <img
                          src={chat.otherUser.profileImageUrl}
                          alt={chat.otherUser.username || chat.otherUser.email}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        getDefaultAvatar(chat.otherUser.username || chat.otherUser.email)
                      )}
                      {chat.otherUser.isOnline && (
                        <div className="online-indicator" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-gray-900 truncate">
                          {chat.otherUser.firstName && chat.otherUser.lastName
                            ? `${chat.otherUser.firstName} ${chat.otherUser.lastName}`
                            : chat.otherUser.username || chat.otherUser.email}
                        </h3>
                        {chat.lastMessage && (
                          <span className="text-sm text-gray-500">
                            {formatTime(chat.lastMessage.createdAt!)}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-600 truncate">
                          {chat.lastMessage?.content || "No messages yet"}
                        </p>
                        {chat.unreadCount > 0 && (
                          <Badge className="bg-vito-blue text-white text-xs">
                            {chat.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </>
        )}

        {activeTab === "status" && (
          <div className="flex-1 flex items-center justify-center text-gray-500 p-8">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">Status Updates</h3>
              <p className="text-sm">Coming soon!</p>
            </div>
          </div>
        )}

        {activeTab === "calls" && (
          <div className="flex-1 flex items-center justify-center text-gray-500 p-8">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">Call History</h3>
              <p className="text-sm">Coming soon!</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
