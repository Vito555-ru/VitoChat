import { useState, useEffect } from 'react';
import { Phone, PhoneOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import type { CallWithUsers } from '@shared/schema';

interface IncomingCallProps {
  call: CallWithUsers;
  onAnswer: () => void;
  onDecline: () => void;
}

export function IncomingCall({ call, onAnswer, onDecline }: IncomingCallProps) {
  const [isRinging, setIsRinging] = useState(true);

  // Create ringing animation effect
  useEffect(() => {
    const interval = setInterval(() => {
      setIsRinging(prev => !prev);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const caller = call.caller;
  const isVideoCall = call.type === 'video';

  return (
    <div className="fixed inset-0 z-50 bg-black bg-opacity-90 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 max-w-sm w-full mx-4 text-center">
        
        {/* Incoming call header */}
        <div className="mb-6">
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
            Incoming {isVideoCall ? 'video' : 'voice'} call
          </p>
          
          {/* Caller avatar with ring animation */}
          <div className={`relative mx-auto mb-4 ${isRinging ? 'scale-105' : 'scale-100'} transition-transform duration-300`}>
            <Avatar className="w-32 h-32 mx-auto border-4 border-blue-500">
              <AvatarImage src={caller.profileImageUrl || undefined} />
              <AvatarFallback className="text-4xl bg-blue-500 text-white">
                {caller.firstName?.[0]}{caller.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            
            {/* Ringing circles animation */}
            <div className={`absolute inset-0 rounded-full border-2 border-blue-500 ${isRinging ? 'animate-ping' : ''}`}></div>
          </div>
          
          {/* Caller info */}
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-1">
            {caller.firstName} {caller.lastName}
          </h2>
          <p className="text-gray-500 dark:text-gray-400">
            {caller.phoneNumber}
          </p>
        </div>

        {/* Call action buttons */}
        <div className="flex justify-center space-x-8">
          {/* Decline button */}
          <Button
            size="lg"
            variant="destructive"
            className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
            onClick={onDecline}
          >
            <PhoneOff size={24} />
          </Button>

          {/* Answer button */}
          <Button
            size="lg"
            className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600 text-white"
            onClick={onAnswer}
          >
            <Phone size={24} />
          </Button>
        </div>

        {/* Call type indicator */}
        <p className="text-xs text-gray-400 mt-4">
          {isVideoCall ? 'Video call' : 'Voice call'}
        </p>
      </div>
    </div>
  );
}