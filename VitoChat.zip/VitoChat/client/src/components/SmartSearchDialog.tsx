import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Search, 
  MessageCircle, 
  Image, 
  FileText, 
  Calendar,
  Clock,
  Brain,
  Sparkles,
  Filter,
  ArrowRight
} from "lucide-react";

interface SmartSearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectResult: (result: any) => void;
}

export function SmartSearchDialog({ open, onOpenChange, onSelectResult }: SmartSearchDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState("messages");

  // Sample search results with AI-powered context understanding
  const mockSearchResults = {
    messages: [
      {
        id: 1,
        chatName: "Alex Johnson",
        message: "Hey, the meeting is at Starbucks on 5th street at 3 PM tomorrow",
        timestamp: "2 days ago",
        context: "Meeting location request",
        relevanceScore: 0.95,
        aiSummary: "Meeting location and time details",
        avatar: ""
      },
      {
        id: 2,
        chatName: "Sarah Wilson",
        message: "Your flight confirmation: AA1234 departing 8:30 AM",
        timestamp: "1 week ago",
        context: "Travel documents",
        relevanceScore: 0.88,
        aiSummary: "Flight ticket information",
        avatar: ""
      },
      {
        id: 3,
        chatName: "Mom",
        message: "Don't forget to pick up your passport from the office",
        timestamp: "3 days ago",
        context: "Travel preparation",
        relevanceScore: 0.82,
        aiSummary: "Important reminder about travel documents",
        avatar: ""
      }
    ],
    media: [
      {
        id: 1,
        type: "image",
        chatName: "Team Group",
        description: "Restaurant menu photos",
        count: 5,
        timestamp: "Yesterday",
        category: "Food",
        aiTags: ["food", "menu", "restaurant"]
      },
      {
        id: 2,
        type: "document",
        chatName: "Sarah Wilson",
        description: "Meeting agenda and notes",
        count: 3,
        timestamp: "3 days ago",
        category: "Work",
        aiTags: ["meeting", "agenda", "work"]
      },
      {
        id: 3,
        type: "image",
        chatName: "Holiday Trip",
        description: "Beach vacation photos",
        count: 12,
        timestamp: "2 weeks ago",
        category: "Travel",
        aiTags: ["vacation", "beach", "travel"]
      }
    ],
    summaries: [
      {
        id: 1,
        chatName: "Alex Johnson",
        period: "Last week",
        summary: "Discussed project deadlines, meeting scheduling, and shared restaurant recommendations for team lunch.",
        keyTopics: ["work", "meetings", "food"],
        messageCount: 24
      },
      {
        id: 2,
        chatName: "Family Group",
        period: "Last 3 days",
        summary: "Planned weekend family gathering, shared photos from cousin's wedding, discussed travel arrangements.",
        keyTopics: ["family", "events", "travel"],
        messageCount: 18
      }
    ]
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const response = await fetch('/api/search/smart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          query: searchQuery, 
          searchType: activeTab 
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('Search results:', data);
        // Results would be handled here in a full implementation
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  useEffect(() => {
    if (searchQuery.length > 2) {
      const debounceTimer = setTimeout(handleSearch, 300);
      return () => clearTimeout(debounceTimer);
    }
  }, [searchQuery]);

  const formatSearchQuery = (query: string) => {
    // Highlight AI interpretation of the search
    if (query.toLowerCase().includes("meeting location")) {
      return "🎯 Looking for location details in meeting-related messages";
    }
    if (query.toLowerCase().includes("flight") || query.toLowerCase().includes("ticket")) {
      return "✈️ Searching travel documents and flight information";
    }
    if (query.toLowerCase().includes("when did")) {
      return "📅 Finding temporal context and message timestamps";
    }
    return `🧠 AI-powered contextual search for: "${query}"`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Brain className="w-5 h-5 text-purple-600" />
            <span>Smart Search</span>
            <Sparkles className="w-4 h-4 text-yellow-500" />
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 flex-1 overflow-hidden">
          {/* Smart Search Input */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Ask anything... 'Find where Ali sent me the meeting location'"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-3 text-base"
              />
              {isSearching && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-purple-600 border-t-transparent"></div>
                </div>
              )}
            </div>
            
            {searchQuery && (
              <div className="text-sm text-purple-600 bg-purple-50 px-3 py-2 rounded-lg">
                {formatSearchQuery(searchQuery)}
              </div>
            )}
          </div>

          {/* Quick Suggestions */}
          {!searchQuery && (
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-gray-700">Try asking:</h3>
              <div className="grid grid-cols-1 gap-2">
                {[
                  "Find the message where Ali sent me the meeting location",
                  "When did Sarah send me the flight ticket?",
                  "Show me all food photos from last week",
                  "Summarize my chat with Mom this week"
                ].map((suggestion, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className="justify-start text-left h-auto py-3 px-4 hover:bg-gray-50"
                    onClick={() => setSearchQuery(suggestion)}
                  >
                    <ArrowRight className="w-4 h-4 mr-2 text-gray-400" />
                    <span className="text-sm">{suggestion}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {searchQuery && (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="messages" className="flex items-center space-x-2">
                  <MessageCircle className="w-4 h-4" />
                  <span>Messages</span>
                </TabsTrigger>
                <TabsTrigger value="media" className="flex items-center space-x-2">
                  <Image className="w-4 h-4" />
                  <span>Media</span>
                </TabsTrigger>
                <TabsTrigger value="summaries" className="flex items-center space-x-2">
                  <Brain className="w-4 h-4" />
                  <span>AI Insights</span>
                </TabsTrigger>
              </TabsList>

              <div className="flex-1 overflow-y-auto mt-4">
                <TabsContent value="messages" className="space-y-3 mt-0">
                  {mockSearchResults.messages.map((result) => (
                    <div
                      key={result.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => onSelectResult(result)}
                    >
                      <div className="flex items-start space-x-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={result.avatar} />
                          <AvatarFallback className="bg-purple-100 text-purple-600">
                            {result.chatName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-medium text-gray-900">{result.chatName}</h4>
                            <div className="flex items-center space-x-2">
                              <Badge variant="secondary" className="text-xs">
                                {Math.round(result.relevanceScore * 100)}% match
                              </Badge>
                              <span className="text-xs text-gray-500">{result.timestamp}</span>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{result.message}</p>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-xs">
                              {result.context}
                            </Badge>
                            <span className="text-xs text-purple-600">📝 {result.aiSummary}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="media" className="space-y-3 mt-0">
                  {mockSearchResults.media.map((item) => (
                    <div
                      key={item.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => onSelectResult(item)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          {item.type === "image" ? (
                            <Image className="w-5 h-5 text-blue-600" />
                          ) : (
                            <FileText className="w-5 h-5 text-blue-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-medium text-gray-900">{item.chatName}</h4>
                            <span className="text-xs text-gray-500">{item.timestamp}</span>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                          <div className="flex items-center space-x-2">
                            <Badge className="text-xs">{item.category}</Badge>
                            <span className="text-xs text-gray-500">{item.count} items</span>
                            <div className="flex space-x-1">
                              {item.aiTags.map((tag, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  #{tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </TabsContent>

                <TabsContent value="summaries" className="space-y-3 mt-0">
                  {mockSearchResults.summaries.map((summary) => (
                    <div
                      key={summary.id}
                      className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => onSelectResult(summary)}
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-gray-900">{summary.chatName}</h4>
                          <Badge variant="outline" className="text-xs">
                            {summary.period}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 leading-relaxed">
                          {summary.summary}
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex space-x-1">
                            {summary.keyTopics.map((topic, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {topic}
                              </Badge>
                            ))}
                          </div>
                          <span className="text-xs text-gray-500">
                            {summary.messageCount} messages analyzed
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </TabsContent>
              </div>
            </Tabs>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}