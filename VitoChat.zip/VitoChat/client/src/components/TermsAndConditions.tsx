import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754890634577.png";

interface TermsAndConditionsProps {
  onAccept: () => void;
}

export function TermsAndConditions({ onAccept }: TermsAndConditionsProps) {
  const [hasAgreed, setHasAgreed] = useState(false);

  const handleAccept = () => {
    if (hasAgreed) {
      onAccept();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-vito-blue to-vito-dark flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] flex flex-col">
        <CardHeader className="text-center flex-shrink-0">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-vito-blue rounded-2xl flex items-center justify-center">
              <img 
                src={vitoLogoPath} 
                alt="VITO Logo" 
                className="w-12 h-12 object-contain"
              />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold font-inter">Terms and Conditions</CardTitle>
          <CardDescription>
            Please read and accept our terms to continue using VITO
          </CardDescription>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col">
          <ScrollArea className="flex-1 pr-4 mb-6">
            <div className="space-y-6">
              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">1. Acceptance of Terms</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  By accessing and using VITO messaging application, you accept and agree to be bound by the terms 
                  and provision of this agreement. These terms apply to all users of the application.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">2. Privacy and Data Protection</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Your privacy is important to us. We collect and process your personal information in accordance 
                  with our Privacy Policy. We implement appropriate security measures to protect your data and 
                  communications within the application.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">3. User Conduct</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  You agree not to use VITO for any unlawful purposes or to transmit any harmful, threatening, 
                  abusive, or defamatory content. We reserve the right to suspend or terminate accounts that 
                  violate these guidelines.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">4. Service Availability</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  We strive to provide continuous service but cannot guarantee uninterrupted availability. 
                  We may temporarily suspend the service for maintenance or updates without prior notice.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">5. Intellectual Property</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  VITO and all related trademarks, logos, and content are the property of Blackhole Networks. 
                  You may not reproduce, distribute, or create derivative works without explicit permission.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">6. Limitation of Liability</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Blackhole Networks shall not be liable for any indirect, incidental, special, or consequential 
                  damages arising from your use of VITO. Our liability is limited to the maximum extent permitted by law.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">7. Changes to Terms</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  We reserve the right to modify these terms at any time. Continued use of the application after 
                  changes constitutes acceptance of the new terms.
                </p>
              </section>

              <Separator />

              <section>
                <h3 className="text-lg font-semibold mb-3 text-vito-blue">8. Contact Information</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  For questions about these terms, please contact Blackhole Networks support team through 
                  the appropriate channels within the application.
                </p>
              </section>
            </div>
          </ScrollArea>

          <div className="flex-shrink-0 space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="terms-agreement" 
                checked={hasAgreed}
                onCheckedChange={(checked) => setHasAgreed(checked === true)}
              />
              <label 
                htmlFor="terms-agreement" 
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I have read and agree to the Terms and Conditions
              </label>
            </div>

            <Button 
              onClick={handleAccept}
              disabled={!hasAgreed}
              className="w-full bg-vito-blue hover:bg-vito-dark text-white"
            >
              Accept and Continue
            </Button>

            <div className="text-center text-xs text-gray-500">
              Powered by Blackhole Networks
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}