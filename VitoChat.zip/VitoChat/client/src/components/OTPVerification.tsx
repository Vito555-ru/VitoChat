import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChevronLeft } from "lucide-react";

interface OTPVerificationProps {
  phoneNumber: string;
  countryCode: string;
  onVerified: () => void;
  onBack: () => void;
}

export function OTPVerification({ phoneNumber, countryCode, onVerified, onBack }: OTPVerificationProps) {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [timeLeft, setTimeLeft] = useState(60);
  const [canResend, setCanResend] = useState(false);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [timeLeft]);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length <= 1 && /^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Auto-focus next input
      if (value && index < 5) {
        const nextInput = document.getElementById(`otp-${index + 1}`);
        nextInput?.focus();
      }

      // Auto-verify when all digits are entered
      if (newOtp.every(digit => digit) && newOtp.join("").length === 6) {
        handleVerify(newOtp.join(""));
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleVerify = (otpCode?: string) => {
    const code = otpCode || otp.join("");
    if (code.length === 6) {
      // In a real app, verify with backend
      // For demo, accept any 6-digit code
      onVerified();
    }
  };

  const handleResend = () => {
    setTimeLeft(60);
    setCanResend(false);
    setOtp(["", "", "", "", "", ""]);
    // In real app, trigger resend SMS
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center mb-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="p-2">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <CardTitle className="flex-1 text-center">Verify Your Number</CardTitle>
          </div>
          <div className="text-center">
            <p className="text-gray-600 mb-2">
              Enter the 6-digit code sent to:
            </p>
            <p className="font-semibold text-gray-900">
              {countryCode} {phoneNumber}
            </p>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="flex justify-center space-x-2">
            {otp.map((digit, index) => (
              <Input
                key={index}
                id={`otp-${index}`}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleOtpChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-12 text-center text-lg font-semibold"
              />
            ))}
          </div>

          <div className="text-center">
            {canResend ? (
              <Button 
                variant="link" 
                onClick={handleResend}
                className="text-vito-blue hover:text-vito-dark"
              >
                Resend Code
              </Button>
            ) : (
              <p className="text-sm text-gray-500">
                Resend code in {timeLeft}s
              </p>
            )}
          </div>

          <Button 
            onClick={() => handleVerify()}
            disabled={otp.some(digit => !digit)}
            className="w-full bg-vito-blue hover:bg-vito-dark text-white py-3"
          >
            Verify
          </Button>

          <p className="text-xs text-gray-500 text-center leading-relaxed">
            Didn't receive the code? Check your SMS or try resending.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}