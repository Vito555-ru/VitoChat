import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { 
  Camera, 
  Image, 
  Video, 
  Mic, 
  MapPin, 
  File, 
  Send,
  X,
  Square
} from "lucide-react";

interface MediaPickerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSendMedia: (media: MediaMessage) => void;
}

interface MediaMessage {
  type: "image" | "video" | "audio" | "voice" | "location" | "document";
  url?: string;
  file?: File;
  caption?: string;
  duration?: number;
  location?: {
    latitude: number;
    longitude: number;
    address?: string;
  };
  timestamp: Date;
}

export function MediaPicker({ open, onOpenChange, onSendMedia }: MediaPickerProps) {
  const [selectedMedia, setSelectedMedia] = useState<MediaMessage | null>(null);
  const [caption, setCaption] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const documentInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const handleFileSelect = (type: "image" | "video" | "document") => {
    if (type === "image") {
      fileInputRef.current?.click();
    } else if (type === "video") {
      videoInputRef.current?.click();
    } else {
      documentInputRef.current?.click();
    }
  };

  const handleFileSelected = (event: React.ChangeEvent<HTMLInputElement>, type: "image" | "video" | "document") => {
    const file = event.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setSelectedMedia({
      type,
      url,
      file,
      timestamp: new Date()
    });
  };

  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        const file = new File([blob], `voice-${Date.now()}.webm`, { type: 'audio/webm' });
        
        setSelectedMedia({
          type: "voice",
          url,
          file,
          duration: recordingTime,
          timestamp: new Date()
        });
        
        stream.getTracks().forEach(track => track.stop());
      };
      
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      
      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      
    } catch (error) {
      console.error("Error starting voice recording:", error);
      alert("Unable to access microphone. Please check permissions.");
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
    }
  };

  const shareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setSelectedMedia({
            type: "location",
            location: {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              address: `${position.coords.latitude.toFixed(6)}, ${position.coords.longitude.toFixed(6)}`
            },
            timestamp: new Date()
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          alert("Unable to get location. Please check permissions.");
        }
      );
    } else {
      alert("Geolocation is not supported by this browser.");
    }
  };

  const handleSend = () => {
    if (selectedMedia) {
      onSendMedia({
        ...selectedMedia,
        caption: caption.trim() || undefined
      });
      
      // Reset state
      setSelectedMedia(null);
      setCaption("");
      onOpenChange(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0">
        {!selectedMedia ? (
          // Media Selection Grid
          <div className="p-6">
            <DialogHeader className="mb-6">
              <DialogTitle>Share Media</DialogTitle>
            </DialogHeader>
            
            <div className="grid grid-cols-3 gap-4">
              {/* Camera */}
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-3 h-24 hover:bg-blue-50"
                onClick={() => handleFileSelect("image")}
              >
                <Camera className="w-8 h-8 text-blue-500" />
                <span className="text-sm">Camera</span>
              </Button>
              
              {/* Gallery */}
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-3 h-24 hover:bg-green-50"
                onClick={() => handleFileSelect("image")}
              >
                <Image className="w-8 h-8 text-green-500" />
                <span className="text-sm">Gallery</span>
              </Button>
              
              {/* Video */}
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-3 h-24 hover:bg-purple-50"
                onClick={() => handleFileSelect("video")}
              >
                <Video className="w-8 h-8 text-purple-500" />
                <span className="text-sm">Video</span>
              </Button>
              
              {/* Voice Message */}
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-3 h-24 hover:bg-red-50"
                onClick={isRecording ? stopVoiceRecording : startVoiceRecording}
              >
                {isRecording ? (
                  <>
                    <Square className="w-8 h-8 text-red-500" />
                    <span className="text-sm">Stop</span>
                    <span className="text-xs text-red-500">{formatTime(recordingTime)}</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-8 h-8 text-red-500" />
                    <span className="text-sm">Voice</span>
                  </>
                )}
              </Button>
              
              {/* Location */}
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-3 h-24 hover:bg-orange-50"
                onClick={shareLocation}
              >
                <MapPin className="w-8 h-8 text-orange-500" />
                <span className="text-sm">Location</span>
              </Button>
              
              {/* Document */}
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-3 h-24 hover:bg-gray-50"
                onClick={() => handleFileSelect("document")}
              >
                <File className="w-8 h-8 text-gray-500" />
                <span className="text-sm">Document</span>
              </Button>
            </div>
            
            {isRecording && (
              <div className="mt-6 p-4 bg-red-50 rounded-lg border border-red-200">
                <div className="flex items-center justify-center space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                  <span className="text-red-700 font-medium">Recording: {formatTime(recordingTime)}</span>
                </div>
                <p className="text-center text-sm text-red-600 mt-2">
                  Tap Stop when finished
                </p>
              </div>
            )}
          </div>
        ) : (
          // Media Preview and Send
          <div className="p-0">
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 z-10 bg-black/50 text-white hover:bg-black/70"
                onClick={() => setSelectedMedia(null)}
              >
                <X className="w-4 h-4" />
              </Button>
              
              {/* Media Preview */}
              <div className="bg-black flex items-center justify-center min-h-48">
                {selectedMedia.type === "image" && (
                  <img src={selectedMedia.url} alt="Preview" className="max-h-96 w-full object-contain" />
                )}
                {selectedMedia.type === "video" && (
                  <video src={selectedMedia.url} controls className="max-h-96 w-full" />
                )}
                {selectedMedia.type === "voice" && (
                  <div className="text-white p-8 text-center">
                    <Mic className="w-16 h-16 mx-auto mb-4" />
                    <p>Voice Message</p>
                    <p className="text-sm mt-2">Duration: {formatTime(selectedMedia.duration || 0)}</p>
                    <audio src={selectedMedia.url} controls className="mt-4" />
                  </div>
                )}
                {selectedMedia.type === "location" && (
                  <div className="text-white p-8 text-center">
                    <MapPin className="w-16 h-16 mx-auto mb-4" />
                    <p>Live Location</p>
                    <p className="text-sm mt-2">{selectedMedia.location?.address}</p>
                  </div>
                )}
                {selectedMedia.type === "document" && (
                  <div className="text-white p-8 text-center">
                    <File className="w-16 h-16 mx-auto mb-4" />
                    <p>Document</p>
                    <p className="text-sm mt-2">{selectedMedia.file?.name}</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Caption and Send */}
            <div className="p-4 border-t">
              {selectedMedia.type !== "voice" && (
                <Textarea
                  placeholder="Add a caption..."
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  className="mb-4 resize-none"
                  rows={2}
                />
              )}
              
              <Button onClick={handleSend} className="w-full bg-vito-blue hover:bg-vito-blue/90">
                <Send className="w-4 h-4 mr-2" />
                Send
              </Button>
            </div>
          </div>
        )}
        
        {/* Hidden File Inputs */}
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept="image/*"
          onChange={(e) => handleFileSelected(e, "image")}
        />
        <input
          ref={videoInputRef}
          type="file"
          className="hidden"
          accept="video/*"
          onChange={(e) => handleFileSelected(e, "video")}
        />
        <input
          ref={documentInputRef}
          type="file"
          className="hidden"
          accept=".pdf,.doc,.docx,.txt,.zip,.rar"
          onChange={(e) => handleFileSelected(e, "document")}
        />
      </DialogContent>
    </Dialog>
  );
}