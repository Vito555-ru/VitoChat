import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Phone, Shield, MessageCircle, Camera, Mic, Contact, ChevronRight, Check, User, Upload } from "lucide-react";
import vitoLogoUrl from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754902665155.png";
import { CircularImageCropper } from './CircularImageCropper';

type OnboardingStep = 'welcome' | 'terms' | 'phone' | 'otp' | 'permissions' | 'profile' | 'complete';

interface OnboardingFlowProps {
  currentStep: OnboardingStep;
  onNext: (nextStep: OnboardingStep) => void;
  onAuthSuccess: (user: any) => void;
}

interface PhoneData {
  countryCode: string;
  phoneNumber: string;
  otp: string;
  firstName: string;
  lastName: string;
  profileImage: string;
}

const countryCodes = [
  { code: "+92", name: "Pakistan", flag: "🇵🇰" },
  { code: "+1", name: "United States", flag: "🇺🇸" },
  { code: "+44", name: "United Kingdom", flag: "🇬🇧" },
  { code: "+91", name: "India", flag: "🇮🇳" },
  { code: "+86", name: "China", flag: "🇨🇳" },
  { code: "+49", name: "Germany", flag: "🇩🇪" },
  { code: "+33", name: "France", flag: "🇫🇷" },
  { code: "+81", name: "Japan", flag: "🇯🇵" },
  { code: "+82", name: "South Korea", flag: "🇰🇷" },
  { code: "+971", name: "UAE", flag: "🇦🇪" },
  { code: "+966", name: "Saudi Arabia", flag: "🇸🇦" },
  { code: "+90", name: "Turkey", flag: "🇹🇷" },
  { code: "+7", name: "Russia", flag: "🇷🇺" },
  { code: "+55", name: "Brazil", flag: "🇧🇷" },
  { code: "+52", name: "Mexico", flag: "🇲🇽" },
  { code: "+61", name: "Australia", flag: "🇦🇺" },
  { code: "+64", name: "New Zealand", flag: "🇳🇿" },
  { code: "+27", name: "South Africa", flag: "🇿🇦" },
  { code: "+234", name: "Nigeria", flag: "🇳🇬" },
  { code: "+20", name: "Egypt", flag: "🇪🇬" },
];

export default function OnboardingFlow({ currentStep, onNext, onAuthSuccess }: OnboardingFlowProps) {
  const [phoneData, setPhoneData] = useState<PhoneData>({
    countryCode: '+92',
    phoneNumber: '',
    otp: '',
    firstName: '',
    lastName: '',
    profileImage: ''
  });
  const [devOtp, setDevOtp] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [permissions, setPermissions] = useState({
    contacts: false,
    camera: false,
    microphone: false,
    notifications: false
  });
  const [showImageCropper, setShowImageCropper] = useState(false);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const { toast } = useToast();

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImageFile(file);
      setShowImageCropper(true);
    }
  };

  const handleImageCrop = (croppedImageUrl: string) => {
    setPhoneData(prev => ({ ...prev, profileImage: croppedImageUrl }));
    setShowImageCropper(false);
    setSelectedImageFile(null);
  };
  };

  const handleSendOTP = async () => {
    if (!phoneData.phoneNumber.trim()) {
      toast({
        title: "Error",
        description: "Please enter your phone number",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phoneData.phoneNumber,
          countryCode: phoneData.countryCode
        })
      });

      if (response.ok) {
        const result = await response.json();
        if (result.devOtp) {
          setDevOtp(result.devOtp);
        }
        toast({
          title: "OTP Sent",
          description: result.devOtp ? `Development OTP: ${result.devOtp}` : "Check your messages for the verification code",
        });
        onNext('otp');
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Failed to send OTP');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send OTP. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!phoneData.otp.trim()) {
      toast({
        title: "Error",
        description: "Please enter the verification code",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phoneData.phoneNumber,
          countryCode: phoneData.countryCode,
          otp: phoneData.otp
        })
      });

      if (response.ok) {
        const result = await response.json();
        localStorage.setItem('authToken', result.authToken);
        onNext('permissions');
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Invalid verification code');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Invalid verification code. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompleteProfile = async () => {
    if (!phoneData.firstName.trim() || !phoneData.lastName.trim()) {
      toast({
        title: "Error",
        description: "Please enter your first and last name",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const authToken = localStorage.getItem('authToken');
      const response = await fetch('/api/auth/complete-profile', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          firstName: phoneData.firstName,
          lastName: phoneData.lastName,
          profileImageUrl: phoneData.profileImage
        })
      });

      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Welcome to VITO!",
          description: "Your account has been created successfully.",
        });
        onAuthSuccess(result.user);
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Failed to complete profile');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete registration. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const renderWelcomeScreen = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-0">
        <CardContent className="text-center p-8">
          <div className="w-24 h-24 mx-auto mb-6">
            <img 
              src={vitoLogoUrl} 
              alt="VITO Logo" 
              className="w-full h-full object-contain drop-shadow-xl"
            />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Welcome to VITO</h1>
          <p className="text-gray-600 mb-2">by Blackhole Networks</p>
          <p className="text-gray-500 text-sm mb-8">
            Connect instantly with friends and family around the world
          </p>
          <Button 
            onClick={() => onNext('terms')}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
          >
            Get Started
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderTermsScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={vitoLogoUrl} 
              alt="VITO Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Terms & Privacy</CardTitle>
          <CardDescription className="text-gray-600">
            Please review and accept our terms to continue
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg text-sm text-gray-700 max-h-40 overflow-y-auto">
            <h4 className="font-semibold mb-2">Terms of Service</h4>
            <p className="mb-3">
              By using VITO, you agree to our terms of service. We provide secure messaging services 
              to help you connect with others.
            </p>
            <h4 className="font-semibold mb-2">Privacy Policy</h4>
            <p>
              Your privacy is important to us. We use end-to-end encryption to protect your messages 
              and personal information. We do not sell your data to third parties.
            </p>
          </div>
          
          <div className="flex items-start space-x-3">
            <Checkbox id="terms" className="mt-1" />
            <Label htmlFor="terms" className="text-sm text-gray-700 leading-relaxed">
              I agree to the Terms of Service and Privacy Policy
            </Label>
          </div>
          
          <Button 
            onClick={() => onNext('phone')}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            Accept and Continue
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderPhoneScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={vitoLogoUrl} 
              alt="VITO Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Enter Phone Number</CardTitle>
          <CardDescription className="text-gray-600">
            We'll send you a verification code
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="country">Country</Label>
            <Select value={phoneData.countryCode} onValueChange={(value) => 
              setPhoneData(prev => ({ ...prev, countryCode: value }))
            }>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-60">
                {countryCodes.map((country) => (
                  <SelectItem key={country.code} value={country.code}>
                    {country.flag} {country.name} ({country.code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <div className="flex space-x-2">
              <div className="flex items-center bg-gray-100 px-3 py-2 rounded-md text-gray-700 min-w-fit">
                {phoneData.countryCode}
              </div>
              <Input
                id="phone"
                type="tel"
                placeholder="Enter your phone number"
                value={phoneData.phoneNumber}
                onChange={(e) => setPhoneData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                className="flex-1"
              />
            </div>
          </div>

          <Button 
            onClick={handleSendOTP}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isLoading ? "Sending..." : "Send Verification Code"}
            <Phone className="w-4 h-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderOTPScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={vitoLogoUrl} 
              alt="VITO Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Verify Phone Number</CardTitle>
          <CardDescription className="text-gray-600">
            Enter the 6-digit code sent to {phoneData.countryCode} {phoneData.phoneNumber}
            {devOtp && (
              <div className="mt-2 p-2 bg-blue-50 rounded text-blue-700 text-sm">
                Development OTP: <strong>{devOtp}</strong>
              </div>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="otp">Verification Code</Label>
            <Input
              id="otp"
              type="text"
              placeholder="Enter 6-digit code"
              value={phoneData.otp}
              onChange={(e) => setPhoneData(prev => ({ ...prev, otp: e.target.value }))}
              className="text-center text-2xl tracking-widest"
              maxLength={6}
            />
          </div>

          <Button 
            onClick={handleVerifyOTP}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isLoading ? "Verifying..." : "Verify Code"}
            <Shield className="w-4 h-4 ml-2" />
          </Button>

          <Button 
            variant="ghost" 
            onClick={() => onNext('phone')}
            className="w-full text-blue-600"
          >
            Change Phone Number
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderPermissionsScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={vitoLogoUrl} 
              alt="VITO Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">App Permissions</CardTitle>
          <CardDescription className="text-gray-600">
            Allow VITO to access these features for the best experience
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
              <div className="flex items-center space-x-3">
                <Contact className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-gray-800">Contacts</p>
                  <p className="text-sm text-gray-600">Find friends who use VITO</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.contacts}
                onCheckedChange={(checked) => 
                  setPermissions(prev => ({ ...prev, contacts: !!checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
              <div className="flex items-center space-x-3">
                <Camera className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-gray-800">Camera</p>
                  <p className="text-sm text-gray-600">Take photos and videos</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.camera}
                onCheckedChange={(checked) => 
                  setPermissions(prev => ({ ...prev, camera: !!checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
              <div className="flex items-center space-x-3">
                <Mic className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-gray-800">Microphone</p>
                  <p className="text-sm text-gray-600">Send voice messages and make calls</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.microphone}
                onCheckedChange={(checked) => 
                  setPermissions(prev => ({ ...prev, microphone: !!checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
              <div className="flex items-center space-x-3">
                <MessageCircle className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-gray-800">Notifications</p>
                  <p className="text-sm text-gray-600">Get notified of new messages</p>
                </div>
              </div>
              <Checkbox 
                checked={permissions.notifications}
                onCheckedChange={(checked) => 
                  setPermissions(prev => ({ ...prev, notifications: !!checked }))
                }
              />
            </div>
          </div>

          <Button 
            onClick={() => onNext('profile')}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            Continue
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const renderProfileScreen = () => (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={vitoLogoUrl} 
              alt="VITO Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">Profile Setup</CardTitle>
          <CardDescription className="text-gray-600">
            Tell us a bit about yourself
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
                {phoneData.profileImage ? (
                  <img 
                    src={phoneData.profileImage} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : phoneData.firstName ? (
                  <span className="text-2xl font-semibold text-gray-600">
                    {phoneData.firstName.charAt(0).toUpperCase()}
                    {phoneData.lastName.charAt(0).toUpperCase()}
                  </span>
                ) : (
                  <User className="w-8 h-8 text-gray-400" />
                )}
              </div>
              <label className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                <Camera className="w-4 h-4 text-white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>
            <p className="text-sm text-gray-500 text-center">
              Tap the camera icon to add a profile photo
            </p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                placeholder="Enter your first name"
                value={phoneData.firstName}
                onChange={(e) => setPhoneData(prev => ({ ...prev, firstName: e.target.value }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                placeholder="Enter your last name"
                value={phoneData.lastName}
                onChange={(e) => setPhoneData(prev => ({ ...prev, lastName: e.target.value }))}
              />
            </div>
          </div>

          <Button 
            onClick={handleCompleteProfile}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isLoading ? "Creating Account..." : "Complete Setup"}
            <Check className="w-4 h-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  const stepComponents = {
    welcome: renderWelcomeScreen,
    terms: renderTermsScreen,
    phone: renderPhoneScreen,
    otp: renderOTPScreen,
    permissions: renderPermissionsScreen,
    profile: renderProfileScreen,
    complete: () => null
  };

  return (
    <>
      {stepComponents[currentStep]()}
      
      {/* Circular Image Cropper */}
      <CircularImageCropper
        open={showImageCropper}
        onClose={() => {
          setShowImageCropper(false);
          setSelectedImageFile(null);
        }}
        onCrop={handleImageCrop}
        imageFile={selectedImageFile}
      />
    </>
  );
}