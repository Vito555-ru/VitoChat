import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Phone, 
  PhoneOff, 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  UserPlus,
  MoreVertical,
  Camera,
  SwitchCamera,
  Minimize2,
  Maximize2,
  Settings,
  Users,
  MessageCircle,
  ArrowLeft
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

interface CallParticipant {
  id: string;
  name: string;
  avatar?: string;
  isMuted: boolean;
  isVideoOn: boolean;
  isConnected: boolean;
}

interface CallScreenProps {
  onEndCall: () => void;
  onBack?: () => void;
  callType: "voice" | "video";
  contact: {
    name: string;
    avatar?: string;
    phone?: string;
  };
  isIncoming?: boolean;
  isGroup?: boolean;
}

export function CallScreen({ onEndCall, onBack, callType, contact, isIncoming = false, isGroup = false }: CallScreenProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(callType === "video");
  const [isSpeakerOn, setIsSpeakerOn] = useState(false);
  const [isConnected, setIsConnected] = useState(!isIncoming);
  const [callDuration, setCallDuration] = useState(0);
  const [isMinimized, setIsMinimized] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [participants, setParticipants] = useState<CallParticipant[]>([
    {
      id: "1",
      name: contact.name,
      avatar: contact.avatar,
      isMuted: false,
      isVideoOn: callType === "video",
      isConnected: true
    }
  ]);
  const [frontCamera, setFrontCamera] = useState(true);
  const [showControls, setShowControls] = useState(true);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const callStartTime = useRef<Date>(new Date());

  useEffect(() => {
    if (isConnected) {
      const interval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - callStartTime.current.getTime()) / 1000);
        setCallDuration(elapsed);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isConnected]);

  useEffect(() => {
    // Auto-hide controls after 3 seconds in video calls
    if (callType === "video" && showControls) {
      const timer = setTimeout(() => {
        setShowControls(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [callType, showControls]);

  const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAcceptCall = () => {
    setIsConnected(true);
    callStartTime.current = new Date();
  };

  const handleRejectCall = () => {
    onEndCall();
  };

  const handleEndCall = () => {
    onEndCall();
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const toggleVideo = () => {
    setIsVideoOn(!isVideoOn);
  };

  const toggleSpeaker = () => {
    setIsSpeakerOn(!isSpeakerOn);
  };

  const switchCamera = () => {
    setFrontCamera(!frontCamera);
  };

  const addParticipant = () => {
    // Logic to add participant to group call
    console.log("Adding participant to call");
  };

  const toggleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  if (isMinimized) {
    return (
      <div className="fixed top-4 right-4 z-50">
        <Card className="p-4 bg-vito-blue text-white shadow-xl">
          <div className="flex items-center space-x-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={contact.avatar} alt={contact.name} />
              <AvatarFallback className="bg-white/20 text-white text-xs">
                {contact.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="text-sm font-medium">{contact.name}</p>
              <p className="text-xs text-white/80">{formatCallDuration(callDuration)}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleMinimize}
              className="text-white hover:bg-white/20 w-8 h-8 p-0"
            >
              <Maximize2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleEndCall}
              className="text-red-300 hover:bg-red-500/20 w-8 h-8 p-0"
            >
              <PhoneOff className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div 
      className={`h-screen flex flex-col relative ${
        callType === "video" ? "bg-black" : "bg-gradient-to-br from-vito-blue to-blue-700"
      }`}
      onClick={() => callType === "video" && setShowControls(true)}
    >
      {/* Header */}
      {(callType === "voice" || showControls) && (
        <div className="absolute top-0 left-0 right-0 z-10 p-4 flex items-center justify-between text-white">
          {onBack && (
            <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-white/20">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          )}
          
          <div className="flex-1 text-center">
            <h2 className="font-medium">{contact.name}</h2>
            <p className="text-sm text-white/80">
              {isIncoming && !isConnected ? "Incoming call..." : 
               !isConnected ? "Calling..." : 
               formatCallDuration(callDuration)}
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleMinimize}
              className="text-white hover:bg-white/20"
            >
              <Minimize2 className="w-5 h-5" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
                  <MoreVertical className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={() => setShowParticipants(true)}>
                  <Users className="w-4 h-4 mr-2" />
                  Participants ({participants.length})
                </DropdownMenuItem>
                
                <DropdownMenuItem>
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Chat
                </DropdownMenuItem>
                
                <DropdownMenuItem>
                  <Settings className="w-4 h-4 mr-2" />
                  Call Settings
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      )}

      {/* Video Content */}
      {callType === "video" && isConnected && (
        <div className="flex-1 relative">
          {/* Remote Video */}
          <video
            ref={remoteVideoRef}
            className="w-full h-full object-cover"
            autoPlay
            playsInline
          />
          
          {/* Local Video (Picture-in-Picture) */}
          <div className="absolute top-20 right-4 w-32 h-40 bg-gray-800 rounded-lg overflow-hidden border-2 border-white/20">
            <video
              ref={localVideoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
              muted
            />
            {!isVideoOn && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
                <VideoOff className="w-8 h-8 text-white/60" />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Voice Call Content */}
      {callType === "voice" && (
        <div className="flex-1 flex flex-col items-center justify-center text-white">
          <Avatar className="w-32 h-32 mb-6">
            <AvatarImage src={contact.avatar} alt={contact.name} />
            <AvatarFallback className="bg-white/20 text-white text-4xl">
              {contact.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          
          <h2 className="text-2xl font-medium mb-2">{contact.name}</h2>
          <p className="text-white/80 mb-4">{contact.phone}</p>
          
          <div className="flex items-center space-x-4 mb-8">
            {isMuted && <Badge variant="secondary" className="bg-red-500/20 text-red-300">Muted</Badge>}
            {isSpeakerOn && <Badge variant="secondary" className="bg-blue-500/20 text-blue-300">Speaker</Badge>}
          </div>
        </div>
      )}

      {/* Incoming Call Screen */}
      {isIncoming && !isConnected && (
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white bg-gradient-to-br from-vito-blue to-blue-700">
          <div className="text-center mb-8">
            <p className="text-lg mb-4">Incoming {callType} call</p>
            <Avatar className="w-32 h-32 mx-auto mb-4">
              <AvatarImage src={contact.avatar} alt={contact.name} />
              <AvatarFallback className="bg-white/20 text-white text-4xl">
                {contact.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <h2 className="text-2xl font-medium mb-2">{contact.name}</h2>
            <p className="text-white/80">{contact.phone}</p>
          </div>
          
          <div className="flex items-center space-x-8">
            <Button
              onClick={handleRejectCall}
              className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 border-4 border-white/20"
            >
              <PhoneOff className="w-8 h-8" />
            </Button>
            
            <Button
              onClick={handleAcceptCall}
              className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600 border-4 border-white/20"
            >
              <Phone className="w-8 h-8" />
            </Button>
          </div>
        </div>
      )}

      {/* Call Controls */}
      {isConnected && (callType === "voice" || showControls) && (
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="flex items-center justify-center space-x-4">
            {/* Mute Button */}
            <Button
              onClick={toggleMute}
              className={`w-12 h-12 rounded-full ${
                isMuted 
                  ? "bg-red-500 hover:bg-red-600" 
                  : "bg-white/20 hover:bg-white/30"
              }`}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </Button>

            {/* Video Toggle (only show if video call) */}
            {callType === "video" && (
              <Button
                onClick={toggleVideo}
                className={`w-12 h-12 rounded-full ${
                  !isVideoOn 
                    ? "bg-red-500 hover:bg-red-600" 
                    : "bg-white/20 hover:bg-white/30"
                }`}
              >
                {isVideoOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
              </Button>
            )}

            {/* Speaker Toggle */}
            <Button
              onClick={toggleSpeaker}
              className={`w-12 h-12 rounded-full ${
                isSpeakerOn 
                  ? "bg-blue-500 hover:bg-blue-600" 
                  : "bg-white/20 hover:bg-white/30"
              }`}
            >
              {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
            </Button>

            {/* Switch Camera (only show if video call) */}
            {callType === "video" && isVideoOn && (
              <Button
                onClick={switchCamera}
                className="w-12 h-12 rounded-full bg-white/20 hover:bg-white/30"
              >
                <SwitchCamera className="w-6 h-6" />
              </Button>
            )}

            {/* Add Participant */}
            <Button
              onClick={addParticipant}
              className="w-12 h-12 rounded-full bg-white/20 hover:bg-white/30"
            >
              <UserPlus className="w-6 h-6" />
            </Button>

            {/* End Call */}
            <Button
              onClick={handleEndCall}
              className="w-14 h-14 rounded-full bg-red-500 hover:bg-red-600"
            >
              <PhoneOff className="w-7 h-7" />
            </Button>
          </div>
        </div>
      )}

      {/* Connection Status */}
      {!isConnected && !isIncoming && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <div className="w-16 h-16 border-4 border-white/30 border-t-white rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-lg">Connecting...</p>
          </div>
        </div>
      )}

      {/* Participants Panel */}
      {showParticipants && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-20">
          <Card className="w-80 max-h-96 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium">Participants ({participants.length})</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowParticipants(false)}
              >
                ×
              </Button>
            </div>
            
            <div className="space-y-3 overflow-y-auto">
              {participants.map((participant) => (
                <div key={participant.id} className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={participant.avatar} alt={participant.name} />
                    <AvatarFallback>
                      {participant.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <p className="font-medium">{participant.name}</p>
                    <div className="flex items-center space-x-2">
                      {participant.isMuted && <MicOff className="w-3 h-3 text-red-500" />}
                      {!participant.isVideoOn && <VideoOff className="w-3 h-3 text-gray-500" />}
                      <span className={`text-xs ${participant.isConnected ? "text-green-600" : "text-gray-500"}`}>
                        {participant.isConnected ? "Connected" : "Connecting..."}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}