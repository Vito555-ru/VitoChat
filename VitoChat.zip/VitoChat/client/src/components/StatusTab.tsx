import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Plus, 
  Camera, 
  Video, 
  Play, 
  Pause,
  Eye,
  EyeOff,
  Users,
  Globe,
  Settings,
  MoreVertical,
  Clock,
  X
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

interface StatusUpdate {
  id: string;
  type: "image" | "video" | "text";
  mediaUrl?: string;
  text?: string;
  backgroundColor?: string;
  timestamp: Date;
  expiresAt: Date;
  privacy: "everyone" | "contacts" | "selected";
  selectedContacts?: string[];
  views: Array<{
    userId: string;
    userName: string;
    viewedAt: Date;
  }>;
}

interface Contact {
  id: string;
  name: string;
  avatar?: string;
  isOnline: boolean;
}

const myStatus: StatusUpdate[] = [
  {
    id: "1",
    type: "image",
    mediaUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=600&fit=crop",
    timestamp: new Date(Date.now() - 3600000),
    expiresAt: new Date(Date.now() + 82800000), // 23 hours remaining
    privacy: "everyone",
    views: [
      { userId: "1", userName: "Alice Johnson", viewedAt: new Date(Date.now() - 1800000) },
      { userId: "2", userName: "Bob Smith", viewedAt: new Date(Date.now() - 900000) }
    ]
  }
];

const contactsStatus: Array<{
  contact: Contact;
  statuses: StatusUpdate[];
  unviewedCount: number;
}> = [
  {
    contact: { id: "1", name: "Alice Johnson", avatar: "", isOnline: true },
    statuses: [
      {
        id: "2",
        type: "video",
        mediaUrl: "https://sample-videos.com/zip/10/mp4/SampleVideo_360x240_1mb.mp4",
        timestamp: new Date(Date.now() - 1800000),
        expiresAt: new Date(Date.now() + 84600000),
        privacy: "contacts",
        views: []
      }
    ],
    unviewedCount: 1
  },
  {
    contact: { id: "2", name: "Sarah Wilson", avatar: "", isOnline: false },
    statuses: [
      {
        id: "3",
        type: "text",
        text: "Just finished an amazing workout! 💪",
        backgroundColor: "#FF6B6B",
        timestamp: new Date(Date.now() - 7200000),
        expiresAt: new Date(Date.now() + 79200000),
        privacy: "everyone",
        views: []
      }
    ],
    unviewedCount: 1
  }
];

const contacts: Contact[] = [
  { id: "1", name: "Alice Johnson", avatar: "", isOnline: true },
  { id: "2", name: "Sarah Wilson", avatar: "", isOnline: false },
  { id: "3", name: "Mike Davis", avatar: "", isOnline: true },
  { id: "4", name: "Emma Brown", avatar: "", isOnline: false }
];

export function StatusTab() {
  const [showCreateStatus, setShowCreateStatus] = useState(false);
  const [showStatusViewer, setShowStatusViewer] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<StatusUpdate[] | null>(null);
  const [currentStatusIndex, setCurrentStatusIndex] = useState(0);
  const [newStatusText, setNewStatusText] = useState("");
  const [statusPrivacy, setStatusPrivacy] = useState<"everyone" | "contacts" | "selected">("contacts");
  const [selectedContactIds, setSelectedContactIds] = useState<string[]>([]);
  const [statusBackground, setStatusBackground] = useState("#1E90FF");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const formatTimeRemaining = (expiresAt: Date) => {
    const now = new Date();
    const diff = expiresAt.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  const handleCreateTextStatus = () => {
    if (!newStatusText.trim()) return;

    const newStatus: StatusUpdate = {
      id: Date.now().toString(),
      type: "text",
      text: newStatusText,
      backgroundColor: statusBackground,
      timestamp: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
      privacy: statusPrivacy,
      selectedContacts: statusPrivacy === "selected" ? selectedContactIds : undefined,
      views: []
    };

    // Add to status list (in real app, would send to server)
    console.log("Creating status:", newStatus);
    
    setNewStatusText("");
    setShowCreateStatus(false);
  };

  const handleFileUpload = (type: "image" | "video") => {
    if (type === "image") {
      fileInputRef.current?.click();
    } else {
      videoInputRef.current?.click();
    }
  };

  const handleFileSelected = (event: React.ChangeEvent<HTMLInputElement>, type: "image" | "video") => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size and duration
    if (type === "video") {
      const video = document.createElement('video');
      video.src = URL.createObjectURL(file);
      video.onloadedmetadata = () => {
        if (video.duration > 60) {
          alert("Video must be 1 minute or shorter");
          return;
        }
        createMediaStatus(file, type);
      };
    } else {
      createMediaStatus(file, type);
    }
  };

  const createMediaStatus = (file: File, type: "image" | "video") => {
    const mediaUrl = URL.createObjectURL(file);
    
    const newStatus: StatusUpdate = {
      id: Date.now().toString(),
      type,
      mediaUrl,
      timestamp: new Date(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      privacy: statusPrivacy,
      selectedContacts: statusPrivacy === "selected" ? selectedContactIds : undefined,
      views: []
    };

    console.log("Creating media status:", newStatus);
    setShowCreateStatus(false);
  };

  const openStatusViewer = (statuses: StatusUpdate[], startIndex: number = 0) => {
    setSelectedStatus(statuses);
    setCurrentStatusIndex(startIndex);
    setShowStatusViewer(true);
  };

  const nextStatus = () => {
    if (selectedStatus && currentStatusIndex < selectedStatus.length - 1) {
      setCurrentStatusIndex(currentStatusIndex + 1);
    }
  };

  const previousStatus = () => {
    if (currentStatusIndex > 0) {
      setCurrentStatusIndex(currentStatusIndex - 1);
    }
  };

  const getPrivacyIcon = (privacy: string) => {
    switch (privacy) {
      case "everyone": return <Globe className="w-4 h-4" />;
      case "contacts": return <Users className="w-4 h-4" />;
      case "selected": return <EyeOff className="w-4 h-4" />;
      default: return <Eye className="w-4 h-4" />;
    }
  };

  const backgroundColors = [
    "#1E90FF", "#FF6B6B", "#4ECDC4", "#45B7D1", 
    "#96CEB4", "#FFEAA7", "#DDA0DD", "#98D8C8"
  ];

  return (
    <div className="h-full bg-gray-50">
      {/* My Status Section */}
      <div className="bg-white p-4 border-b">
        <h2 className="text-lg font-semibold mb-4">My Status</h2>
        
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Avatar className="w-14 h-14">
              <AvatarImage src="" />
              <AvatarFallback className="bg-vito-blue text-white text-lg">ME</AvatarFallback>
            </Avatar>
            <Button
              size="sm"
              className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-vito-blue hover:bg-vito-blue/90 p-0"
              onClick={() => setShowCreateStatus(true)}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="flex-1">
            {myStatus.length > 0 ? (
              <div 
                className="cursor-pointer"
                onClick={() => openStatusViewer(myStatus)}
              >
                <h3 className="font-medium">My Status</h3>
                <p className="text-sm text-gray-600">
                  {formatTimeRemaining(myStatus[myStatus.length - 1].expiresAt)} remaining
                </p>
              </div>
            ) : (
              <div
                className="cursor-pointer"
                onClick={() => setShowCreateStatus(true)}
              >
                <h3 className="font-medium">My Status</h3>
                <p className="text-sm text-gray-600">Tap to add status update</p>
              </div>
            )}
          </div>
          
          {myStatus.length > 0 && (
            <div className="flex items-center space-x-2">
              <Eye className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                {myStatus[myStatus.length - 1].views.length}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Recent Updates */}
      <div className="bg-white">
        <div className="p-4 border-b">
          <h3 className="font-medium text-gray-600">Recent updates</h3>
        </div>
        
        <div className="divide-y divide-gray-100">
          {contactsStatus.map((item, index) => (
            <div 
              key={item.contact.id}
              className="p-4 hover:bg-gray-50 cursor-pointer"
              onClick={() => openStatusViewer(item.statuses)}
            >
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={item.contact.avatar} />
                    <AvatarFallback className="bg-vito-blue text-white">
                      {item.contact.name[0]}
                    </AvatarFallback>
                  </Avatar>
                  {item.unviewedCount > 0 && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-vito-blue rounded-full flex items-center justify-center">
                      <span className="text-xs text-white font-bold">{item.unviewedCount}</span>
                    </div>
                  )}
                  {item.contact.isOnline && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                  )}
                </div>
                
                <div className="flex-1">
                  <h4 className="font-medium">{item.contact.name}</h4>
                  <p className="text-sm text-gray-600">
                    {formatTimeRemaining(item.statuses[item.statuses.length - 1].expiresAt)} ago
                  </p>
                </div>
                
                <div className="flex items-center space-x-2">
                  {getPrivacyIcon(item.statuses[item.statuses.length - 1].privacy)}
                  {item.statuses[item.statuses.length - 1].type === "video" && (
                    <Video className="w-4 h-4 text-gray-500" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Create Status Dialog */}
      <Dialog open={showCreateStatus} onOpenChange={setShowCreateStatus}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create Status Update</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Upload Options */}
            <div className="grid grid-cols-3 gap-4">
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-20"
                onClick={() => handleFileUpload("image")}
              >
                <Camera className="w-6 h-6 text-blue-500" />
                <span className="text-xs">Photo</span>
              </Button>
              
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-20"
                onClick={() => handleFileUpload("video")}
              >
                <Video className="w-6 h-6 text-green-500" />
                <span className="text-xs">Video</span>
                <span className="text-xs text-gray-500">1 min max</span>
              </Button>
              
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-20"
                onClick={() => {/* Focus on text input */}}
              >
                <div className="w-6 h-6 bg-purple-500 rounded flex items-center justify-center">
                  <span className="text-white text-xs font-bold">Aa</span>
                </div>
                <span className="text-xs">Text</span>
              </Button>
            </div>

            {/* Text Status */}
            <div className="space-y-4">
              <div 
                className="min-h-32 p-4 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: statusBackground }}
              >
                <Textarea
                  value={newStatusText}
                  onChange={(e) => setNewStatusText(e.target.value)}
                  placeholder="Type a status update..."
                  className="bg-transparent border-none text-white placeholder-white/70 resize-none text-center"
                  maxLength={100}
                />
              </div>
              
              {/* Background Colors */}
              <div className="flex space-x-2 overflow-x-auto">
                {backgroundColors.map((color) => (
                  <button
                    key={color}
                    className="w-8 h-8 rounded-full border-2 border-gray-300 flex-shrink-0"
                    style={{ backgroundColor: color }}
                    onClick={() => setStatusBackground(color)}
                  />
                ))}
              </div>
            </div>

            {/* Privacy Settings */}
            <div className="space-y-3">
              <h4 className="font-medium">Who can see this status?</h4>
              
              <Select value={statusPrivacy} onValueChange={(value: any) => setStatusPrivacy(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="everyone">
                    <div className="flex items-center space-x-2">
                      <Globe className="w-4 h-4" />
                      <span>Everyone</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="contacts">
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4" />
                      <span>My Contacts</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="selected">
                    <div className="flex items-center space-x-2">
                      <EyeOff className="w-4 h-4" />
                      <span>Selected Contacts</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>

              {/* Contact Selection for "Selected" privacy */}
              {statusPrivacy === "selected" && (
                <div className="max-h-40 overflow-y-auto border rounded-lg p-2">
                  {contacts.map((contact) => (
                    <div key={contact.id} className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded">
                      <input
                        type="checkbox"
                        checked={selectedContactIds.includes(contact.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedContactIds([...selectedContactIds, contact.id]);
                          } else {
                            setSelectedContactIds(selectedContactIds.filter(id => id !== contact.id));
                          }
                        }}
                      />
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={contact.avatar} />
                        <AvatarFallback className="bg-vito-blue text-white text-xs">
                          {contact.name[0]}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{contact.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Create Button */}
            <Button 
              onClick={handleCreateTextStatus}
              className="w-full bg-vito-blue hover:bg-vito-blue/90"
              disabled={!newStatusText.trim() && statusPrivacy === "selected" && selectedContactIds.length === 0}
            >
              Share Status
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Status Viewer Dialog */}
      <Dialog open={showStatusViewer} onOpenChange={setShowStatusViewer}>
        <DialogContent className="max-w-md p-0 bg-black">
          {selectedStatus && selectedStatus[currentStatusIndex] && (
            <div className="relative w-full h-96">
              {/* Close Button */}
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-4 right-4 z-10 text-white hover:bg-white/20"
                onClick={() => setShowStatusViewer(false)}
              >
                <X className="w-5 h-5" />
              </Button>

              {/* Status Progress Bars */}
              <div className="absolute top-4 left-4 right-16 z-10 flex space-x-1">
                {selectedStatus.map((_, index) => (
                  <div 
                    key={index}
                    className={`h-1 rounded-full flex-1 ${
                      index <= currentStatusIndex ? "bg-white" : "bg-white/30"
                    }`}
                  />
                ))}
              </div>

              {/* Status Content */}
              <div className="w-full h-full flex items-center justify-center">
                {selectedStatus[currentStatusIndex].type === "text" ? (
                  <div 
                    className="w-full h-full flex items-center justify-center p-8"
                    style={{ backgroundColor: selectedStatus[currentStatusIndex].backgroundColor }}
                  >
                    <p className="text-white text-lg text-center font-medium">
                      {selectedStatus[currentStatusIndex].text}
                    </p>
                  </div>
                ) : selectedStatus[currentStatusIndex].type === "image" ? (
                  <img
                    src={selectedStatus[currentStatusIndex].mediaUrl}
                    alt="Status"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <video
                    src={selectedStatus[currentStatusIndex].mediaUrl}
                    className="w-full h-full object-cover"
                    controls
                    autoPlay
                  />
                )}
              </div>

              {/* Navigation */}
              <div className="absolute inset-y-0 left-0 w-1/3 cursor-pointer" onClick={previousStatus} />
              <div className="absolute inset-y-0 right-0 w-1/3 cursor-pointer" onClick={nextStatus} />

              {/* Status Info */}
              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">
                      {formatTimeRemaining(selectedStatus[currentStatusIndex].expiresAt)} remaining
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getPrivacyIcon(selectedStatus[currentStatusIndex].privacy)}
                    <Eye className="w-4 h-4" />
                    <span className="text-sm">{selectedStatus[currentStatusIndex].views.length}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Hidden File Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept="image/*"
        onChange={(e) => handleFileSelected(e, "image")}
      />
      <input
        ref={videoInputRef}
        type="file"
        className="hidden"
        accept="video/*"
        onChange={(e) => handleFileSelected(e, "video")}
      />
    </div>
  );
}