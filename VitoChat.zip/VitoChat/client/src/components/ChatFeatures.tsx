import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Clock, 
  Timer, 
  Zap, 
  Heart, 
  ThumbsUp, 
  Smile, 
  Angry,
  Star,
  Pin,
  Reply,
  Forward,
  Copy,
  Trash2,
  Info,
  Eye,
  EyeOff,
  Calendar,
  MapPin,
  Globe
} from "lucide-react";

// Message Reactions Component
interface MessageReactionsProps {
  reactions: { emoji: string; count: number; users: string[] }[];
  onReact: (emoji: string) => void;
  showAll?: boolean;
}

export function MessageReactions({ reactions, onReact, showAll = false }: MessageReactionsProps) {
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  
  const quickReactions = ["❤️", "👍", "😂", "😮", "😢", "🔥"];
  
  return (
    <div className="flex items-center space-x-1 mt-1">
      {reactions.map((reaction, index) => (
        <Button
          key={index}
          variant="outline"
          size="sm"
          className="h-6 px-2 text-xs"
          onClick={() => onReact(reaction.emoji)}
        >
          <span className="mr-1">{reaction.emoji}</span>
          <span>{reaction.count}</span>
        </Button>
      ))}
      
      <Button
        variant="ghost"
        size="sm"
        className="h-6 w-6 p-0"
        onClick={() => setShowReactionPicker(!showReactionPicker)}
      >
        <Smile className="w-3 h-3" />
      </Button>
      
      {showReactionPicker && (
        <div className="absolute bg-white shadow-lg rounded-lg p-2 flex space-x-1 z-10">
          {quickReactions.map((emoji) => (
            <Button
              key={emoji}
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              onClick={() => {
                onReact(emoji);
                setShowReactionPicker(false);
              }}
            >
              {emoji}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}

// Disappearing Messages Component
interface DisappearingMessageProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSet: (duration: number) => void;
}

export function DisappearingMessageDialog({ open, onOpenChange, onSet }: DisappearingMessageProps) {
  const durations = [
    { label: "24 hours", value: 24 * 60 * 60 * 1000 },
    { label: "7 days", value: 7 * 24 * 60 * 60 * 1000 },
    { label: "90 days", value: 90 * 24 * 60 * 60 * 1000 },
    { label: "Off", value: 0 }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Timer className="w-5 h-5" />
            <span>Disappearing Messages</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-3">
          <p className="text-sm text-gray-600">
            New messages will disappear from this chat after the selected time.
          </p>
          
          {durations.map((duration) => (
            <Button
              key={duration.value}
              variant="outline"
              className="w-full justify-start"
              onClick={() => {
                onSet(duration.value);
                onOpenChange(false);
              }}
            >
              <Clock className="w-4 h-4 mr-2" />
              {duration.label}
            </Button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Quick Reply Component
interface QuickReplyProps {
  suggestions: string[];
  onReply: (text: string) => void;
}

export function QuickReply({ suggestions, onReply }: QuickReplyProps) {
  if (suggestions.length === 0) return null;
  
  return (
    <div className="p-2 border-t bg-gray-50">
      <p className="text-xs text-gray-600 mb-2">Quick replies:</p>
      <div className="flex flex-wrap gap-1">
        {suggestions.map((suggestion, index) => (
          <Button
            key={index}
            variant="outline"
            size="sm"
            className="h-7 text-xs"
            onClick={() => onReply(suggestion)}
          >
            {suggestion}
          </Button>
        ))}
      </div>
    </div>
  );
}

// Message Scheduler Component
interface MessageSchedulerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSchedule: (message: string, scheduledTime: Date) => void;
}

export function MessageScheduler({ open, onOpenChange, onSchedule }: MessageSchedulerProps) {
  const [message, setMessage] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");

  const handleSchedule = () => {
    if (message && selectedDate && selectedTime) {
      const scheduledTime = new Date(`${selectedDate}T${selectedTime}`);
      onSchedule(message, scheduledTime);
      setMessage("");
      setSelectedDate("");
      setSelectedTime("");
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Calendar className="w-5 h-5" />
            <span>Schedule Message</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Textarea
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
          />
          
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-sm font-medium mb-1">Date</label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Time</label>
              <Input
                type="time"
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
              />
            </div>
          </div>
          
          <Button 
            onClick={handleSchedule} 
            className="w-full bg-vito-blue hover:bg-vito-blue/90"
            disabled={!message || !selectedDate || !selectedTime}
          >
            <Zap className="w-4 h-4 mr-2" />
            Schedule Message
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Chat Info Component
interface ChatInfoProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contact: any;
  messageCount: number;
  sharedMedia: number;
}

export function ChatInfo({ open, onOpenChange, contact, messageCount, sharedMedia }: ChatInfoProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Info className="w-5 h-5" />
            <span>Chat Info</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Chat Statistics */}
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-vito-blue">{messageCount}</div>
              <div className="text-sm text-gray-600">Messages</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-vito-blue">{sharedMedia}</div>
              <div className="text-sm text-gray-600">Media Files</div>
            </div>
          </div>
          
          {/* Chat Features */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Encryption</span>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                End-to-end encrypted
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Chat backup</span>
              <span className="text-sm text-gray-500">Last: 2 hours ago</span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Message delivery</span>
              <span className="text-sm text-gray-500">Always</span>
            </div>
          </div>
          
          {/* Privacy Settings */}
          <div className="space-y-2 pt-4 border-t">
            <h4 className="font-medium">Privacy & Security</h4>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Read receipts</span>
              <Eye className="w-4 h-4 text-vito-blue" />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Last seen</span>
              <Globe className="w-4 h-4 text-vito-blue" />
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Live location sharing</span>
              <MapPin className="w-4 h-4 text-gray-400" />
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Message Context Menu
interface MessageContextMenuProps {
  message: any;
  onReply: () => void;
  onForward: () => void;
  onCopy: () => void;
  onDelete: () => void;
  onPin: () => void;
  onStar: () => void;
  onInfo: () => void;
}

export function MessageContextMenu({ 
  message, 
  onReply, 
  onForward, 
  onCopy, 
  onDelete, 
  onPin, 
  onStar, 
  onInfo 
}: MessageContextMenuProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg border p-1 min-w-48">
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={onReply}>
        <Reply className="w-4 h-4 mr-2" />
        Reply
      </Button>
      
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={onForward}>
        <Forward className="w-4 h-4 mr-2" />
        Forward
      </Button>
      
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={onCopy}>
        <Copy className="w-4 h-4 mr-2" />
        Copy
      </Button>
      
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={onStar}>
        <Star className="w-4 h-4 mr-2" />
        Star
      </Button>
      
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={onPin}>
        <Pin className="w-4 h-4 mr-2" />
        Pin
      </Button>
      
      <Button variant="ghost" size="sm" className="w-full justify-start" onClick={onInfo}>
        <Info className="w-4 h-4 mr-2" />
        Message Info
      </Button>
      
      <div className="border-t my-1" />
      
      <Button variant="ghost" size="sm" className="w-full justify-start text-red-600" onClick={onDelete}>
        <Trash2 className="w-4 h-4 mr-2" />
        Delete
      </Button>
    </div>
  );
}