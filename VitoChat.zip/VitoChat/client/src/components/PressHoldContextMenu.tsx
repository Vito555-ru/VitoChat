import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Reply, 
  Forward, 
  Star, 
  Copy, 
  Trash2, 
  Heart,
  Smile,
  ThumbsUp,
  Laugh,
  Angry,
  Frown
} from 'lucide-react';

interface PressHoldContextMenuProps {
  isVisible: boolean;
  position: { x: number; y: number };
  onClose: () => void;
  onReply: () => void;
  onForward: () => void;
  onStar: () => void;
  onCopy: () => void;
  onDelete: () => void;
  onReact: (emoji: string) => void;
  canDelete?: boolean;
}

const REACTIONS = [
  { emoji: '❤️', icon: Heart, label: 'Love' },
  { emoji: '😂', icon: Laugh, label: 'Laugh' },
  { emoji: '👍', icon: ThumbsUp, label: 'Like' },
  { emoji: '😮', icon: Smile, label: 'Wow' },
  { emoji: '😢', icon: Frown, label: 'Sad' },
  { emoji: '😡', icon: Angry, label: 'Angry' },
];

export function PressHoldContextMenu({
  isVisible,
  position,
  onClose,
  onReply,
  onForward,
  onStar,
  onCopy,
  onDelete,
  onReact,
  canDelete = true
}: PressHoldContextMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isVisible) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscapeKey);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
        document.removeEventListener('keydown', handleEscapeKey);
      };
    }
  }, [isVisible, onClose]);

  if (!isVisible) return null;

  const handleAction = (action: () => void) => {
    action();
    onClose();
  };

  const handleReaction = (emoji: string) => {
    onReact(emoji);
    onClose();
  };

  return (
    <div
      ref={menuRef}
      className="fixed z-50 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 p-2 min-w-64"
      style={{
        left: Math.min(position.x, window.innerWidth - 280),
        top: Math.max(10, Math.min(position.y, window.innerHeight - 300)),
      }}
    >
      {/* Quick Reactions */}
      <div className="flex justify-center space-x-1 mb-3 pb-3 border-b border-gray-200 dark:border-gray-600">
        {REACTIONS.map(({ emoji, icon: Icon, label }) => (
          <Button
            key={emoji}
            variant="ghost"
            size="sm"
            className="w-10 h-10 p-0 text-lg hover:bg-blue-50 dark:hover:bg-blue-900/20"
            onClick={() => handleReaction(emoji)}
            title={label}
          >
            {emoji}
          </Button>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="space-y-1">
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          onClick={() => handleAction(onReply)}
        >
          <Reply className="w-4 h-4 mr-3" />
          Reply
        </Button>

        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          onClick={() => handleAction(onForward)}
        >
          <Forward className="w-4 h-4 mr-3" />
          Forward
        </Button>

        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          onClick={() => handleAction(onStar)}
        >
          <Star className="w-4 h-4 mr-3" />
          Star
        </Button>

        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          onClick={() => handleAction(onCopy)}
        >
          <Copy className="w-4 h-4 mr-3" />
          Copy
        </Button>

        {canDelete && (
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-start text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
            onClick={() => handleAction(onDelete)}
          >
            <Trash2 className="w-4 h-4 mr-3" />
            Delete
          </Button>
        )}
      </div>
    </div>
  );
}

// Hook for press and hold functionality
export function usePressHold(onPressHold: (event: React.MouseEvent) => void, delay = 500) {
  const timeoutRef = useRef<NodeJS.Timeout>();
  const [isPressed, setIsPressed] = useState(false);

  const start = (event: React.MouseEvent) => {
    setIsPressed(true);
    timeoutRef.current = setTimeout(() => {
      onPressHold(event);
    }, delay);
  };

  const clear = () => {
    setIsPressed(false);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
  };

  return {
    onMouseDown: start,
    onMouseUp: clear,
    onMouseLeave: clear,
    onTouchStart: start,
    onTouchEnd: clear,
    isPressed
  };
}