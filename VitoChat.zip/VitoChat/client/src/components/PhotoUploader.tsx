import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Camera, Upload, Trash2, User } from "lucide-react";

interface PhotoUploaderProps {
  currentPhoto?: string;
  onPhotoChange: (photo: string) => void;
  userName: string;
}

export function PhotoUploader({ currentPhoto, onPhotoChange, userName }: PhotoUploaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Create object URL for preview
      const photoUrl = URL.createObjectURL(file);
      onPhotoChange(photoUrl);
      setIsOpen(false);
    }
  };

  const handleCameraCapture = () => {
    // Trigger camera capture
    if (fileInputRef.current) {
      fileInputRef.current.setAttribute('capture', 'camera');
      fileInputRef.current.click();
    }
  };

  const handleGallerySelect = () => {
    // Trigger gallery selection
    if (fileInputRef.current) {
      fileInputRef.current.removeAttribute('capture');
      fileInputRef.current.click();
    }
  };

  const handleRemovePhoto = () => {
    onPhotoChange("");
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <div className="relative cursor-pointer">
          <Avatar className="w-32 h-32">
            <AvatarImage src={currentPhoto} alt={userName} />
            <AvatarFallback className="bg-vito-blue text-white text-4xl">
              {userName.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <Button
            size="sm"
            className="absolute bottom-0 right-0 rounded-full w-10 h-10 bg-vito-blue hover:bg-vito-blue/90"
          >
            <Camera className="w-4 h-4" />
          </Button>
        </div>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Profile Photo</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex justify-center">
            <Avatar className="w-24 h-24">
              <AvatarImage src={currentPhoto} alt={userName} />
              <AvatarFallback className="bg-vito-blue text-white text-2xl">
                {userName.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={handleCameraCapture} className="flex items-center justify-center">
              <Camera className="w-4 h-4 mr-2" />
              Camera
            </Button>
            <Button variant="outline" onClick={handleGallerySelect} className="flex items-center justify-center">
              <Upload className="w-4 h-4 mr-2" />
              Gallery
            </Button>
          </div>

          {currentPhoto && (
            <Button variant="outline" onClick={handleRemovePhoto} className="w-full text-red-600">
              <Trash2 className="w-4 h-4 mr-2" />
              Remove Photo
            </Button>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}