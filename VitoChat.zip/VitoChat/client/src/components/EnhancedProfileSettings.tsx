import { useState } from 'react';
import { Camera, Edit3, Shield, Smartphone, Trash2, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import type { User } from '@shared/schema';

interface EnhancedProfileSettingsProps {
  user: User;
  onUpdateProfile: (updates: Partial<User>) => Promise<void>;
  onChangeNumber: (newNumber: string) => Promise<void>;
  onDeleteAccount: () => Promise<void>;
}

export function EnhancedProfileSettings({ 
  user, 
  onUpdateProfile, 
  onChangeNumber, 
  onDeleteAccount 
}: EnhancedProfileSettingsProps) {
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isChangingNumber, setIsChangingNumber] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  const [isSecuritySetup, setIsSecuritySetup] = useState(false);
  
  const [profileForm, setProfileForm] = useState({
    firstName: user.firstName || '',
    lastName: user.lastName || '',
    about: user.about || user.bio || '',
    profileImageUrl: user.profileImageUrl || ''
  });
  
  const [privacySettings, setPrivacySettings] = useState({
    lastSeenPrivacy: user.lastSeenPrivacy || 'everyone',
    profilePhotoPrivacy: user.profilePhotoPrivacy || 'everyone',
    aboutPrivacy: user.aboutPrivacy || 'everyone'
  });
  
  const [newPhoneNumber, setNewPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleUpdateProfile = async () => {
    setLoading(true);
    try {
      await onUpdateProfile(profileForm);
      setIsEditingProfile(false);
      toast({
        title: 'Profile Updated',
        description: 'Your profile has been updated successfully.',
      });
    } catch (error) {
      console.error('Failed to update profile:', error);
      toast({
        title: 'Update Failed',
        description: 'Unable to update your profile. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePrivacy = async (setting: string, value: string) => {
    setLoading(true);
    try {
      const updates = { [setting]: value };
      await onUpdateProfile(updates);
      setPrivacySettings(prev => ({ ...prev, [setting]: value }));
      toast({
        title: 'Privacy Updated',
        description: 'Your privacy settings have been updated.',
      });
    } catch (error) {
      console.error('Failed to update privacy settings:', error);
      toast({
        title: 'Update Failed',
        description: 'Unable to update privacy settings.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleChangeNumber = async () => {
    if (!newPhoneNumber.trim()) return;
    
    setLoading(true);
    try {
      await onChangeNumber(newPhoneNumber);
      setIsChangingNumber(false);
      setNewPhoneNumber('');
      toast({
        title: 'OTP Sent',
        description: 'Verification code sent to your new number.',
      });
    } catch (error) {
      console.error('Failed to change number:', error);
      toast({
        title: 'Change Failed',
        description: 'Unable to change phone number. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    setLoading(true);
    try {
      await onDeleteAccount();
    } catch (error) {
      console.error('Failed to delete account:', error);
      toast({
        title: 'Deletion Failed',
        description: 'Unable to delete account. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const formatLastSeen = (date: Date | string | null) => {
    if (!date) return 'Never';
    const lastSeen = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffMs = now.getTime() - lastSeen.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffHours < 24) return `${diffHours} hours ago`;
    if (diffDays < 7) return `${diffDays} days ago`;
    return lastSeen.toLocaleDateString();
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      
      {/* Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Edit3 size={20} />
            Profile Information
          </CardTitle>
          <CardDescription>
            Manage your profile details and visibility
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Profile Photo & Status */}
          <div className="flex items-start space-x-6">
            <div className="relative">
              <Avatar className="w-24 h-24 border-4 border-blue-200">
                <AvatarImage src={user.profileImageUrl || undefined} />
                <AvatarFallback className="text-2xl bg-blue-500 text-white">
                  {user.firstName?.[0]}{user.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              {user.isOnline && (
                <div className="absolute bottom-0 right-0 w-6 h-6 bg-green-500 border-2 border-white rounded-full"></div>
              )}
            </div>
            
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-semibold">
                  {user.firstName} {user.lastName}
                </h3>
                <Badge variant={user.isOnline ? "default" : "secondary"}>
                  {user.isOnline ? "Online" : "Offline"}
                </Badge>
              </div>
              <p className="text-sm text-gray-500">
                Last seen: {formatLastSeen(user.lastSeen)}
              </p>
              <p className="text-gray-600 dark:text-gray-400">
                {user.about || user.bio || 'No status set'}
              </p>
              <Button variant="outline" className="flex items-center gap-2">
                <Camera size={16} />
                Change Photo
              </Button>
            </div>
          </div>

          {/* Profile Edit Form */}
          {!isEditingProfile ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="text-sm font-medium text-gray-600">Phone Number</Label>
                <p className="font-mono text-lg">{user.countryCode}{user.phoneNumber}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-600">Member Since</Label>
                <p>{new Date(user.createdAt).toLocaleDateString()}</p>
              </div>
              <div className="md:col-span-2">
                <Button onClick={() => setIsEditingProfile(true)}>
                  Edit Profile
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={profileForm.firstName}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, firstName: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={profileForm.lastName}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, lastName: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="about">About / Status</Label>
                <Textarea
                  id="about"
                  value={profileForm.about}
                  onChange={(e) => setProfileForm(prev => ({ ...prev, about: e.target.value }))}
                  placeholder="Tell people about yourself..."
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleUpdateProfile} disabled={loading}>
                  {loading ? 'Saving...' : 'Save Changes'}
                </Button>
                <Button variant="outline" onClick={() => setIsEditingProfile(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Privacy & Security */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield size={20} />
            Privacy & Security
          </CardTitle>
          <CardDescription>
            Control who can see your information and secure your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          
          {/* Privacy Settings */}
          <div className="space-y-4">
            <h4 className="font-medium">Privacy Settings</h4>
            
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <Label className="font-medium">Last Seen</Label>
                  <p className="text-sm text-gray-500">Who can see when you were last online</p>
                </div>
                <Select
                  value={privacySettings.lastSeenPrivacy}
                  onValueChange={(value) => handleUpdatePrivacy('lastSeenPrivacy', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <Label className="font-medium">Profile Photo</Label>
                  <p className="text-sm text-gray-500">Who can see your profile photo</p>
                </div>
                <Select
                  value={privacySettings.profilePhotoPrivacy}
                  onValueChange={(value) => handleUpdatePrivacy('profilePhotoPrivacy', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <Label className="font-medium">About</Label>
                  <p className="text-sm text-gray-500">Who can see your about information</p>
                </div>
                <Select
                  value={privacySettings.aboutPrivacy}
                  onValueChange={(value) => handleUpdatePrivacy('aboutPrivacy', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator />

          {/* Security Features */}
          <div className="space-y-4">
            <h4 className="font-medium">Security Features</h4>
            <div className="grid gap-3">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Lock size={20} className="text-green-600" />
                  <div>
                    <Label className="font-medium">End-to-End Encryption</Label>
                    <p className="text-sm text-gray-500">Your messages and calls are secure</p>
                  </div>
                </div>
                <Badge variant="default" className="bg-green-500">Enabled</Badge>
              </div>
              
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <Label className="font-medium">Two-Step Verification</Label>
                  <p className="text-sm text-gray-500">Add extra security to your account</p>
                </div>
                <Button variant="outline" onClick={() => setIsSecuritySetup(true)}>
                  Setup
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Account Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone size={20} />
            Account Management
          </CardTitle>
          <CardDescription>
            Manage your account settings and data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          
          <div className="grid gap-4">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <Label className="font-medium">Change Phone Number</Label>
                <p className="text-sm text-gray-500">Update your phone number with OTP verification</p>
              </div>
              <Button variant="outline" onClick={() => setIsChangingNumber(true)}>
                Change Number
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg border-red-200">
              <div>
                <Label className="font-medium text-red-600">Delete Account</Label>
                <p className="text-sm text-gray-500">Permanently delete your account and all data</p>
              </div>
              <Button variant="destructive" onClick={() => setIsDeletingAccount(true)}>
                <Trash2 size={16} className="mr-2" />
                Delete Account
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Change Number Dialog */}
      <Dialog open={isChangingNumber} onOpenChange={setIsChangingNumber}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Phone Number</DialogTitle>
            <DialogDescription>
              Enter your new phone number. You'll receive an OTP for verification.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="newPhone">New Phone Number</Label>
              <Input
                id="newPhone"
                type="tel"
                value={newPhoneNumber}
                onChange={(e) => setNewPhoneNumber(e.target.value)}
                placeholder="+1 (555) 123-4567"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsChangingNumber(false)}>
              Cancel
            </Button>
            <Button onClick={handleChangeNumber} disabled={loading || !newPhoneNumber.trim()}>
              {loading ? 'Sending OTP...' : 'Verify Number'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={isDeletingAccount} onOpenChange={setIsDeletingAccount}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-600">Delete Account</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete your account and remove all your data from our servers, including:
              <br /><br />
              • All messages and chat history
              <br />
              • Profile information and photos  
              <br />
              • Call history and contacts
              <br />
              • Your phone number will be available for re-registration
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeletingAccount(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={loading}>
              {loading ? 'Deleting Account...' : 'Delete Account Permanently'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Security Setup Dialog */}
      <Dialog open={isSecuritySetup} onOpenChange={setIsSecuritySetup}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Two-Step Verification</DialogTitle>
            <DialogDescription>
              Add an extra layer of security to your VITO account with two-step verification.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm">
              When enabled, you'll need to enter both your password and a verification code sent to your phone when signing in to VITO from a new device.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSecuritySetup(false)}>
              Maybe Later
            </Button>
            <Button onClick={() => setIsSecuritySetup(false)}>
              Enable Two-Step Verification
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}