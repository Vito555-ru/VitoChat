import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Search, Phone, Video, Users } from "lucide-react";

interface NewCallDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStartCall: (contact: any, callType: "voice" | "video") => void;
}

export function NewCallDialog({ open, onOpenChange, onStartCall }: NewCallDialogProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const contacts = [
    {
      id: 1,
      name: "Alex Johnson",
      phoneNumber: "+1 (555) 123-4567",
      avatar: "",
      isOnline: true,
      lastSeen: "2 min ago"
    },
    {
      id: 2,
      name: "Sarah Wilson", 
      phoneNumber: "+1 (555) 987-6543",
      avatar: "",
      isOnline: false,
      lastSeen: "1 hour ago"
    },
    {
      id: 3,
      name: "Mom",
      phoneNumber: "+1 (555) 555-0123",
      avatar: "",
      isOnline: true,
      lastSeen: "5 min ago"
    },
    {
      id: 4,
      name: "Mike Chen",
      phoneNumber: "+1 (555) 246-8135",
      avatar: "",
      isOnline: false,
      lastSeen: "2 hours ago"
    },
    {
      id: 5,
      name: "Team Group",
      phoneNumber: "",
      avatar: "",
      isOnline: false,
      lastSeen: "",
      isGroup: true,
      memberCount: 5
    }
  ];

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.phoneNumber.includes(searchTerm)
  );

  const handleCall = (contact: any, callType: "voice" | "video") => {
    onStartCall(contact, callType);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>New Call</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search contacts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Contacts List */}
          <div className="max-h-80 overflow-y-auto space-y-1">
            {filteredContacts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Phone className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p>No contacts found</p>
              </div>
            ) : (
              filteredContacts.map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg"
                >
                  <div className="relative">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={contact.avatar} alt={contact.name} />
                      <AvatarFallback className="bg-vito-blue text-white text-sm">
                        {contact.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    {contact.isOnline && !contact.isGroup && (
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-medium text-gray-900 truncate">{contact.name}</h3>
                      {contact.isGroup && (
                        <Users className="w-4 h-4 text-gray-500" />
                      )}
                    </div>
                    <p className="text-sm text-gray-500 truncate">
                      {contact.isGroup 
                        ? `${contact.memberCount} members`
                        : contact.phoneNumber || (contact.isOnline ? "Online" : contact.lastSeen)
                      }
                    </p>
                  </div>

                  {/* Call Buttons */}
                  <div className="flex space-x-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-green-600 hover:text-green-700 hover:bg-green-50 w-9 h-9"
                      onClick={() => handleCall(contact, "voice")}
                    >
                      <Phone className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 w-9 h-9"
                      onClick={() => handleCall(contact, "video")}
                    >
                      <Video className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}