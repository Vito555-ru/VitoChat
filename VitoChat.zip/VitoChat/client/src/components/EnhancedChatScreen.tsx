import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  Send, 
  Plus, 
  Camera, 
  Mic, 
  Smile, 
  Paperclip,
  Play,
  Pause,
  Download,
  Eye,
  Check,
  CheckCheck,
  Clock,
  User,
  Bell,
  Search,
  Archive,
  Trash2,
  Shield,
  Reply,
  Forward,
  Copy,
  Star,
  Share,
  Info,
  Pin,
  Image,
  FileText,
  MapPin,
  UserPlus,
  Palette,
  BellOff,
  X,
  Settings
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { MediaPicker } from "./MediaPicker";
import { ChatSettings } from "./ChatSettings";
import { MessageReactions, MessageContextMenu } from "./ChatFeatures";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

interface Message {
  id: string;
  text?: string;
  type: "text" | "image" | "video" | "voice" | "document" | "contact" | "location";
  sender: "me" | "other";
  timestamp: Date;
  status?: "sending" | "sent" | "delivered" | "read";
  mediaUrl?: string;
  mediaSize?: { width: number; height: number };
  duration?: number;
  fileName?: string;
  reactions?: { emoji: string; userId: string }[];
  replyTo?: string;
  isDeleted?: boolean;
  isStarred?: boolean;
}

interface ChatScreenProps {
  onBack: () => void;
  onCall?: (type: "voice" | "video") => void;
  onViewProfile?: () => void;
  contact: {
    name: string;
    avatar?: string;
    isOnline: boolean;
    lastSeen?: string;
    isGroup?: boolean;
    members?: string[];
    phone?: string;
    about?: string;
    mutualGroups?: number;
  };
}

export function EnhancedChatScreen({ onBack, onCall, contact }: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hey! How are you doing?",
      type: "text",
      sender: "other",
      timestamp: new Date(Date.now() - 3600000),
      status: "read"
    },
    {
      id: "2",
      text: "I'm doing great! Just working on some projects. How about you?",
      type: "text",
      sender: "me",
      timestamp: new Date(Date.now() - 3500000),
      status: "read"
    }
  ]);
  
  const [newMessage, setNewMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [showMediaOptions, setShowMediaOptions] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);
  const [showMessageInfo, setShowMessageInfo] = useState<Message | null>(null);

  const [searchTerm, setSearchTerm] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showContextMenu, setShowContextMenu] = useState<{messageId: string, x: number, y: number} | null>(null);
  const [starredMessages, setStarredMessages] = useState<string[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [showChatSettings, setShowChatSettings] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Get saved wallpaper for this chat
  const getChatWallpaperKey = (contactName: string) => `chat_wallpaper_${contactName.replace(/\s+/g, '_')}`;
  
  const getAppliedWallpaper = () => {
    const saved = localStorage.getItem(getChatWallpaperKey(contact.name));
    if (saved) {
      const { wallpaper, type } = JSON.parse(saved);
      if (type === "solid") {
        return { background: wallpaper };
      } else if (type === "gallery" || type === "vito") {
        return { backgroundImage: `url(${wallpaper})`, backgroundSize: 'cover', backgroundPosition: 'center' };
      }
    }
    return { background: "#f3f4f6" }; // Default background
  };
  
  const wallpaperStyle = getAppliedWallpaper();
  
  // Re-apply wallpaper when returning from settings
  useEffect(() => {
    // Force re-render when component mounts to apply saved wallpaper
  }, [contact.name]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "sending": return <Clock className="w-3 h-3 text-gray-400" />;
      case "sent": return <Check className="w-3 h-3 text-gray-400" />;
      case "delivered": return <CheckCheck className="w-3 h-3 text-gray-400" />;
      case "read": return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default: return null;
    }
  };

  const handleSendMessage = () => {
    if (!newMessage.trim() && !replyingTo) return;

    const message: Message = {
      id: Date.now().toString(),
      text: newMessage,
      type: "text",
      sender: "me",
      timestamp: new Date(),
      status: "sending",
      replyTo: replyingTo?.id
    };

    setMessages(prev => [...prev, message]);
    setNewMessage("");
    setReplyingTo(null);

    // Simulate message status updates
    setTimeout(() => {
      setMessages(msgs => msgs.map(m => 
        m.id === message.id ? { ...m, status: "sent" } : m
      ));
    }, 500);

    setTimeout(() => {
      setMessages(msgs => msgs.map(m => 
        m.id === message.id ? { ...m, status: "delivered" } : m
      ));
    }, 1000);
  };

  const handleMessageLongPress = (message: Message, event: React.MouseEvent) => {
    event.preventDefault();
    setShowContextMenu({
      messageId: message.id,
      x: event.clientX,
      y: event.clientY
    });
  };

  const handleReplyToMessage = (message: Message) => {
    setReplyingTo(message);
    setShowContextMenu(null);
  };

  const handleForwardMessage = (message: Message) => {
    console.log("Forwarding message:", message);
    setShowContextMenu(null);
  };

  const handleDeleteMessage = (messageId: string, deleteForEveryone = false) => {
    if (deleteForEveryone) {
      setMessages(msgs => msgs.filter(m => m.id !== messageId));
    } else {
      setMessages(msgs => msgs.map(m => 
        m.id === messageId ? { ...m, text: "This message was deleted", isDeleted: true } : m
      ));
    }
    setShowContextMenu(null);
  };

  const handleStarMessage = (messageId: string) => {
    setStarredMessages(prev => 
      prev.includes(messageId) 
        ? prev.filter(id => id !== messageId)
        : [...prev, messageId]
    );
    setShowContextMenu(null);
  };

  const handleReactToMessage = (messageId: string, emoji: string) => {
    setMessages(msgs => msgs.map(m => 
      m.id === messageId 
        ? { ...m, reactions: [...(m.reactions || []), { emoji, userId: "me" }] }
        : m
    ));
  };

  const handleCopyMessage = (message: Message) => {
    if (message.text) {
      navigator.clipboard.writeText(message.text);
    }
    setShowContextMenu(null);
  };

  const handleMediaSend = (media: any) => {
    const message: Message = {
      id: Date.now().toString(),
      text: media.caption,
      type: media.type,
      sender: "me",
      timestamp: new Date(),
      status: "sending",
      mediaUrl: media.url,
      duration: media.duration,
      fileName: media.file?.name
    };
    setMessages([...messages, message]);
  };

  const quickReplies = ["👍", "Thanks!", "Sure thing", "On my way", "Let me check"];
  const emojis = ["😀", "😂", "🥰", "😮", "😢", "🙏", "👍", "❤️"];

  const filteredMessages = searchTerm 
    ? messages.filter(m => m.text?.toLowerCase().includes(searchTerm.toLowerCase()))
    : messages;

  if (showChatSettings) {
    return <ChatSettings contact={contact} onBack={() => setShowChatSettings(false)} />;
  }

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-vito-blue text-white p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-white/20 p-1">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <Avatar className="w-10 h-10" onClick={() => setShowProfile(true)}>
            <AvatarImage src={contact.avatar} alt={contact.name} />
            <AvatarFallback className="bg-white/20 text-white">
              {contact.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 cursor-pointer" onClick={() => setShowProfile(true)}>
            <h2 className="font-medium">{contact.name}</h2>
            <p className="text-sm text-white/80">
              {contact.isOnline ? "online" : contact.lastSeen || "last seen recently"}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowSearch(!showSearch)}
            className="text-white hover:bg-white/20"
          >
            <Search className="w-5 h-5" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onCall?.("video")}
            className="text-white hover:bg-white/20"
          >
            <Video className="w-5 h-5" />
          </Button>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onCall?.("voice")}
            className="text-white hover:bg-white/20"
          >
            <Phone className="w-5 h-5" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => setShowProfile(true)}>
                <User className="w-4 h-4 mr-2" />
                View Contact
              </DropdownMenuItem>
              
              <DropdownMenuItem onClick={() => setShowChatSettings(true)}>
                <Settings className="w-4 h-4 mr-2" />
                Chat Settings
              </DropdownMenuItem>
              
              <DropdownMenuItem onClick={() => setIsMuted(!isMuted)}>
                {isMuted ? <Bell className="w-4 h-4 mr-2" /> : <BellOff className="w-4 h-4 mr-2" />}
                {isMuted ? "Unmute" : "Mute"} Notifications
              </DropdownMenuItem>
              
              <DropdownMenuSeparator />
              
              <DropdownMenuItem onClick={() => setShowSearch(true)}>
                <Search className="w-4 h-4 mr-2" />
                Search
              </DropdownMenuItem>
              
              <DropdownMenuItem>
                <Archive className="w-4 h-4 mr-2" />
                Archive Chat
              </DropdownMenuItem>
              
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Chat
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Search Bar */}
      {showSearch && (
        <div className="p-4 border-b bg-gray-50">
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => {
                setShowSearch(false);
                setSearchTerm("");
              }}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Reply Bar */}
      {replyingTo && (
        <div className="p-3 border-b bg-blue-50 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Reply className="w-4 h-4 text-blue-600" />
            <div>
              <p className="text-sm font-medium text-blue-600">Replying to {replyingTo.sender === "me" ? "yourself" : contact.name}</p>
              <p className="text-sm text-gray-600 truncate max-w-48">{replyingTo.text}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setReplyingTo(null)}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Messages */}
      <div 
        className="flex-1 overflow-y-auto p-4 space-y-4" 
        style={wallpaperStyle}
      >
        {filteredMessages.map((message) => {
          let pressTimer: NodeJS.Timeout;

          const handleTouchStart = (e: React.TouchEvent) => {
            pressTimer = setTimeout(() => {
              handleMessageLongPress(message, e as any);
            }, 600); // 600ms for better mobile experience
          };

          const handleTouchEnd = () => {
            clearTimeout(pressTimer);
          };

          const handleMouseDown = (e: React.MouseEvent) => {
            e.preventDefault();
            pressTimer = setTimeout(() => {
              handleMessageLongPress(message, e);
            }, 600);
          };

          const handleMouseUp = () => {
            clearTimeout(pressTimer);
          };

          const handleMouseLeave = () => {
            clearTimeout(pressTimer);
          };

          return (
            <div
              key={message.id}
              className={`flex ${message.sender === "me" ? "justify-end" : "justify-start"}`}
            >
              <div 
                className={`max-w-xs lg:max-w-md relative group cursor-pointer select-none ${
                  message.sender === "me" 
                    ? "bg-vito-blue text-white" 
                    : "bg-gray-100 text-gray-900"
                } rounded-lg p-3 ${selectedMessages.includes(message.id) ? "ring-2 ring-blue-500" : ""}`}
                onTouchStart={handleTouchStart}
                onTouchEnd={handleTouchEnd}
                onMouseDown={handleMouseDown}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseLeave}
                onContextMenu={(e) => {
                  e.preventDefault();
                  handleMessageLongPress(message, e);
                }}
              >
                {/* Reply Reference */}
              {message.replyTo && (
                <div className="mb-2 p-2 bg-black/10 rounded border-l-2 border-current">
                  <p className="text-xs opacity-70">
                    {messages.find(m => m.id === message.replyTo)?.text || "Original message"}
                  </p>
                </div>
              )}

              {/* Message Content */}
              {message.type === "text" && (
                <p className={message.isDeleted ? "italic opacity-70" : ""}>
                  {message.text}
                </p>
              )}

              {message.type === "image" && (
                <div className="space-y-2">
                  <img 
                    src={message.mediaUrl} 
                    alt="Shared image" 
                    className="rounded max-w-full h-auto"
                  />
                  {message.text && <p>{message.text}</p>}
                </div>
              )}

              {message.type === "voice" && (
                <div className="flex items-center space-x-2 min-w-48">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setPlayingVoice(playingVoice === message.id ? null : message.id)}
                    className="text-current hover:bg-black/10"
                  >
                    {playingVoice === message.id ? 
                      <Pause className="w-4 h-4" /> : 
                      <Play className="w-4 h-4" />
                    }
                  </Button>
                  <div className="flex-1 bg-black/10 rounded-full h-1">
                    <div className="bg-current h-1 rounded-full w-1/3"></div>
                  </div>
                  <span className="text-xs">{message.duration}s</span>
                </div>
              )}

              {message.type === "document" && (
                <div className="flex items-center space-x-2">
                  <FileText className="w-6 h-6" />
                  <div>
                    <p className="font-medium">{message.fileName}</p>
                    <p className="text-xs opacity-70">Document</p>
                  </div>
                  <Button variant="ghost" size="sm" className="text-current">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              )}

              {/* Message Reactions */}
              {message.reactions && message.reactions.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  {message.reactions.map((reaction, index) => (
                    <span key={index} className="bg-black/10 rounded-full px-2 py-1 text-xs">
                      {reaction.emoji}
                    </span>
                  ))}
                </div>
              )}

              {/* Quick Reaction Buttons (on hover) */}
              <div className="absolute -top-3 right-0 hidden group-hover:flex space-x-1 bg-white shadow-lg rounded-full p-1">
                {["❤️", "👍", "😂"].map((emoji) => (
                  <Button
                    key={emoji}
                    variant="ghost"
                    size="sm"
                    className="w-8 h-8 p-0 hover:bg-gray-100"
                    onClick={() => handleReactToMessage(message.id, emoji)}
                  >
                    {emoji}
                  </Button>
                ))}
              </div>

              {/* Message Time and Status */}
              <div className={`flex items-center justify-end space-x-1 mt-1 ${
                message.sender === "me" ? "text-white/70" : "text-gray-500"
              }`}>
                <span className="text-xs">{formatTime(message.timestamp)}</span>
                {message.sender === "me" && getStatusIcon(message.status)}
                {starredMessages.includes(message.id) && (
                  <Star className="w-3 h-3 fill-current" />
                )}
              </div>
            </div>
          </div>
          );
        })}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: "0.1s"}}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: "0.2s"}}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Replies */}
      {quickReplies.length > 0 && (
        <div className="px-4 py-2 border-t bg-gray-50">
          <div className="flex space-x-2 overflow-x-auto">
            {quickReplies.map((reply, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="whitespace-nowrap"
                onClick={() => {
                  setNewMessage(reply);
                  handleSendMessage();
                }}
              >
                {reply}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="p-4 border-t bg-white">
        {/* Media Options */}
        {showMediaOptions && (
          <Card className="mb-4 p-4">
            <div className="grid grid-cols-4 gap-4">
              <Button 
                variant="ghost" 
                className="flex flex-col items-center space-y-2 h-auto p-4"
                onClick={() => setShowMediaPicker(true)}
              >
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                  <Image className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm">Gallery</span>
              </Button>
              
              <Button 
                variant="ghost" 
                className="flex flex-col items-center space-y-2 h-auto p-4"
                onClick={() => setShowMediaPicker(true)}
              >
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <Camera className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-sm">Camera</span>
              </Button>
              
              <Button 
                variant="ghost" 
                className="flex flex-col items-center space-y-2 h-auto p-4"
                onClick={() => fileInputRef.current?.click()}
              >
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <FileText className="w-6 h-6 text-orange-600" />
                </div>
                <span className="text-sm">Document</span>
              </Button>
              
              <Button 
                variant="ghost" 
                className="flex flex-col items-center space-y-2 h-auto p-4"
              >
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-green-600" />
                </div>
                <span className="text-sm">Location</span>
              </Button>
            </div>
          </Card>
        )}
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowMediaOptions(!showMediaOptions)}
            className="text-gray-500 hover:bg-gray-100"
          >
            <Plus className="w-5 h-5" />
          </Button>
          
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="pr-20"
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            />
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-8 h-8 p-0 text-gray-500"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              >
                <Smile className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-8 h-8 p-0 text-gray-500"
                onClick={() => setShowMediaPicker(true)}
              >
                <Paperclip className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {newMessage.trim() ? (
            <Button
              onClick={handleSendMessage}
              className="bg-vito-blue hover:bg-vito-blue/90"
            >
              <Send className="w-5 h-5" />
            </Button>
          ) : (
            <Button
              onMouseDown={() => setIsRecording(true)}
              onMouseUp={() => setIsRecording(false)}
              onMouseLeave={() => setIsRecording(false)}
              className={`${isRecording ? "bg-red-500 hover:bg-red-600" : "bg-vito-blue hover:bg-vito-blue/90"}`}
            >
              <Mic className="w-5 h-5" />
            </Button>
          )}
        </div>
        
        {/* Emoji Picker */}
        {showEmojiPicker && (
          <div className="mt-2 p-3 bg-white border rounded-lg shadow-lg">
            <div className="grid grid-cols-8 gap-2">
              {emojis.map((emoji) => (
                <Button
                  key={emoji}
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => {
                    setNewMessage(newMessage + emoji);
                    setShowEmojiPicker(false);
                  }}
                >
                  {emoji}
                </Button>
              ))}
            </div>
          </div>
        )}
        
        {isRecording && (
          <div className="mt-2 flex items-center justify-center space-x-2 text-red-500">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-sm">Recording...</span>
          </div>
        )}
      </div>

      {/* Context Menu */}
      {showContextMenu && (
        <div 
          className="fixed z-50"
          style={{ left: showContextMenu.x, top: showContextMenu.y }}
        >
          <MessageContextMenu
            message={messages.find(m => m.id === showContextMenu.messageId)!}
            onReply={() => handleReplyToMessage(messages.find(m => m.id === showContextMenu.messageId)!)}
            onForward={() => handleForwardMessage(messages.find(m => m.id === showContextMenu.messageId)!)}
            onCopy={() => handleCopyMessage(messages.find(m => m.id === showContextMenu.messageId)!)}
            onDelete={() => handleDeleteMessage(showContextMenu.messageId)}
            onPin={() => {}}
            onStar={() => handleStarMessage(showContextMenu.messageId)}
            onInfo={() => setShowMessageInfo(messages.find(m => m.id === showContextMenu.messageId)!)}
          />
        </div>
      )}

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept="image/*,video/*,.pdf,.doc,.docx"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {
            // Handle file upload
          }
        }}
      />

      {/* Media Picker */}
      <MediaPicker
        open={showMediaPicker}
        onOpenChange={setShowMediaPicker}
        onSendMedia={handleMediaSend}
      />

      {/* Contact Profile Dialog */}
      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Contact Info</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="flex flex-col items-center space-y-4">
              <Avatar className="w-24 h-24">
                <AvatarImage src={contact.avatar} alt={contact.name} />
                <AvatarFallback className="bg-vito-blue text-white text-2xl">
                  {contact.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div className="text-center">
                <h3 className="text-xl font-semibold">{contact.name}</h3>
                <p className="text-gray-600">{contact.phone}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {contact.isOnline ? "Online" : contact.lastSeen}
                </p>
              </div>
            </div>

            {contact.about && (
              <div>
                <h4 className="font-medium mb-2">About</h4>
                <p className="text-gray-600">{contact.about}</p>
              </div>
            )}

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700">Media, links and docs</span>
                <span className="text-sm text-gray-500">47 ›</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-700">Starred messages</span>
                <span className="text-sm text-gray-500">{starredMessages.length} ›</span>
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t">
              <Button variant="ghost" className="w-full justify-start text-sm">
                <Bell className="w-4 h-4 mr-3" />
                Mute Notifications
              </Button>
              
              <Button variant="ghost" className="w-full justify-start text-sm">
                <Archive className="w-4 h-4 mr-3" />
                Archive Chat
              </Button>
              
              <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                <Shield className="w-4 h-4 mr-3" />
                Block Contact
              </Button>
              
              <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                <Trash2 className="w-4 h-4 mr-3" />
                Delete Chat
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Message Context Menu */}
      {showContextMenu && (
        <div 
          className="fixed bg-white shadow-lg rounded-lg py-2 z-50 border"
          style={{ 
            left: showContextMenu.x, 
            top: showContextMenu.y,
            minWidth: '180px'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center space-x-3"
            onClick={() => {
              const message = messages.find(m => m.id === showContextMenu.messageId);
              if (message) handleReplyToMessage(message);
            }}
          >
            <Reply className="w-4 h-4" />
            <span>Reply</span>
          </button>
          
          <button
            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center space-x-3"
            onClick={() => {
              const message = messages.find(m => m.id === showContextMenu.messageId);
              if (message) handleForwardMessage(message);
            }}
          >
            <Share className="w-4 h-4" />
            <span>Forward</span>
          </button>
          
          <button
            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center space-x-3"
            onClick={() => handleStarMessage(showContextMenu.messageId)}
          >
            <Star className="w-4 h-4" />
            <span>{starredMessages.includes(showContextMenu.messageId) ? "Unstar" : "Star"}</span>
          </button>
          
          <button
            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center space-x-3"
            onClick={() => {
              const message = messages.find(m => m.id === showContextMenu.messageId);
              if (message) handleCopyMessage(message);
            }}
          >
            <Copy className="w-4 h-4" />
            <span>Copy</span>
          </button>
          
          {/* Emoji Reactions */}
          <div className="border-t mt-2 pt-2 px-4">
            <div className="text-xs text-gray-500 mb-2">React with:</div>
            <div className="flex space-x-2">
              {["❤️", "👍", "😂", "😮", "😢", "🙏"].map((emoji) => (
                <button
                  key={emoji}
                  className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded"
                  onClick={() => {
                    handleReactToMessage(showContextMenu.messageId, emoji);
                    setShowContextMenu(null);
                  }}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
          
          <button
            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center space-x-3 text-red-600 border-t mt-2"
            onClick={() => handleDeleteMessage(showContextMenu.messageId)}
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete</span>
          </button>
        </div>
      )}

      {/* Click outside to close context menu */}
      {showContextMenu && (
        <div 
          className="fixed inset-0 z-40"
          onClick={() => setShowContextMenu(null)}
        />
      )}
    </div>
  );
}