import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  Send, 
  Plus, 
  Camera, 
  Mic, 
  Smile, 
  Paperclip,
  Users,
  Settings,
  UserPlus,
  UserMinus,
  Shield,
  Bell,
  Search,
  Edit3,
  Crown,
  Check,
  CheckCheck,
  Clock
} from "lucide-react";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

interface GroupMember {
  id: string;
  name: string;
  avatar?: string;
  role: "admin" | "member";
  isOnline: boolean;
  lastSeen?: string;
}

interface GroupMessage {
  id: string;
  text?: string;
  type: "text" | "image" | "video" | "voice" | "document" | "system";
  sender: GroupMember | "system";
  timestamp: Date;
  status?: "sending" | "sent" | "delivered" | "read";
  mediaUrl?: string;
  replyTo?: string;
}

interface GroupChatScreenProps {
  onBack: () => void;
  group: {
    id: string;
    name: string;
    description?: string;
    avatar?: string;
    members: GroupMember[];
    createdBy: string;
    createdAt: Date;
  };
}

const sampleMembers: GroupMember[] = [
  {
    id: "1",
    name: "Alice Johnson",
    avatar: "",
    role: "admin",
    isOnline: true
  },
  {
    id: "2", 
    name: "Bob Smith",
    avatar: "",
    role: "member",
    isOnline: false,
    lastSeen: "2 hours ago"
  },
  {
    id: "3",
    name: "Carol Davis",
    avatar: "",
    role: "member", 
    isOnline: true
  },
  {
    id: "4",
    name: "David Wilson",
    avatar: "",
    role: "member",
    isOnline: false,
    lastSeen: "yesterday"
  },
  {
    id: "me",
    name: "You",
    role: "admin",
    isOnline: true
  }
];

const sampleMessages: GroupMessage[] = [
  {
    id: "1",
    type: "system",
    sender: "system",
    timestamp: new Date(Date.now() - 86400000),
    text: "Alice created this group"
  },
  {
    id: "2",
    text: "Welcome everyone to our project group! 🎉",
    type: "text",
    sender: sampleMembers[0],
    timestamp: new Date(Date.now() - 86300000),
    status: "read"
  },
  {
    id: "3",
    text: "Thanks for creating this Alice! Ready to collaborate.",
    type: "text",
    sender: sampleMembers[1],
    timestamp: new Date(Date.now() - 86200000),
    status: "read"
  },
  {
    id: "4",
    type: "system",
    sender: "system",
    timestamp: new Date(Date.now() - 82800000),
    text: "Carol joined the group"
  },
  {
    id: "5",
    text: "Hi everyone! Excited to work together on this project.",
    type: "text",
    sender: sampleMembers[2],
    timestamp: new Date(Date.now() - 82700000),
    status: "read"
  },
  {
    id: "6",
    text: "When should we schedule our first meeting?",
    type: "text",
    sender: sampleMembers[0],
    timestamp: new Date(Date.now() - 3600000),
    status: "read"
  },
  {
    id: "7",
    text: "How about tomorrow at 2 PM?",
    type: "text",
    sender: sampleMembers[4],
    timestamp: new Date(Date.now() - 3500000),
    status: "delivered"
  }
];

export function GroupChatScreen({ onBack, group }: GroupChatScreenProps) {
  const [messages, setMessages] = useState<GroupMessage[]>(sampleMessages);
  const [newMessage, setNewMessage] = useState("");
  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [showMediaOptions, setShowMediaOptions] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "sending": return <Clock className="w-3 h-3 text-gray-400" />;
      case "sent": return <Check className="w-3 h-3 text-gray-400" />;
      case "delivered": return <CheckCheck className="w-3 h-3 text-gray-400" />;
      case "read": return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default: return null;
    }
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const message: GroupMessage = {
      id: Date.now().toString(),
      text: newMessage,
      type: "text",
      sender: sampleMembers[4], // "me"
      timestamp: new Date(),
      status: "sending"
    };

    setMessages(prev => [...prev, message]);
    setNewMessage("");

    // Simulate message status updates
    setTimeout(() => {
      setMessages(prev => prev.map(msg => 
        msg.id === message.id ? { ...msg, status: "sent" } : msg
      ));
    }, 1000);
  };

  const renderMessage = (message: GroupMessage) => {
    const isMe = message.sender !== "system" && (message.sender as GroupMember).id === "me";
    const isSystem = message.sender === "system";

    if (isSystem) {
      return (
        <div key={message.id} className="flex justify-center mb-4">
          <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-600">
            {message.text}
          </Badge>
        </div>
      );
    }

    const sender = message.sender as GroupMember;

    return (
      <div key={message.id} className={`flex ${isMe ? "justify-end" : "justify-start"} mb-4`}>
        <div className={`max-w-xs lg:max-w-md ${isMe ? "order-2" : "order-1"}`}>
          {!isMe && (
            <div className="flex items-center space-x-2 mb-1">
              <Avatar className="w-6 h-6">
                <AvatarImage src={sender.avatar} />
                <AvatarFallback className="text-xs bg-vito-blue text-white">
                  {sender.name[0]}
                </AvatarFallback>
              </Avatar>
              <span className="text-xs text-gray-500">{sender.name}</span>
              {sender.role === "admin" && (
                <Crown className="w-3 h-3 text-yellow-500" />
              )}
            </div>
          )}
          
          <div
            className={`rounded-lg px-3 py-2 ${
              isMe
                ? "bg-vito-blue text-white"
                : "bg-white border border-gray-200"
            }`}
          >
            <p className="text-sm">{message.text}</p>
            
            <div className={`flex items-center justify-between mt-1 ${isMe ? "text-white/70" : "text-gray-500"}`}>
              <span className="text-xs">{formatTime(message.timestamp)}</span>
              {isMe && <div className="ml-2">{getStatusIcon(message.status)}</div>}
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (showGroupInfo) {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        {/* Group Info Header */}
        <div className="bg-vito-blue text-white p-4 flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowGroupInfo(false)}
            className="text-white hover:bg-white/20 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <img 
            src={vitoLogoPath} 
            alt="VITO Logo" 
            className="w-8 h-8 object-contain"
          />
          <h1 className="text-xl font-semibold">Group Info</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Group Details */}
          <Card>
            <CardContent className="p-6 text-center">
              <Avatar className="w-24 h-24 mx-auto mb-4">
                <AvatarImage src={group.avatar} />
                <AvatarFallback className="bg-vito-blue text-white text-2xl">
                  {group.name[0]}
                </AvatarFallback>
              </Avatar>
              <h3 className="font-semibold text-xl">{group.name}</h3>
              <p className="text-gray-600 mt-1">{group.description || "No description"}</p>
              <p className="text-sm text-gray-500 mt-2">
                Created by {sampleMembers.find(m => m.id === group.createdBy)?.name} • {group.members.length} members
              </p>
              
              <div className="flex justify-center space-x-4 mt-4">
                <Button variant="outline" size="sm">
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit
                </Button>
                <Button variant="outline" size="sm">
                  <Camera className="w-4 h-4 mr-2" />
                  Change Photo
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Group Actions */}
          <Card>
            <CardContent className="p-0">
              <div className="space-y-0">
                <div className="flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer border-b">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <UserPlus className="w-5 h-5 text-blue-600" />
                    </div>
                    <span className="font-medium">Add Members</span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-gray-400 rotate-180" />
                </div>

                <div className="flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer border-b">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-green-100 rounded-full">
                      <Bell className="w-5 h-5 text-green-600" />
                    </div>
                    <span className="font-medium">Notifications</span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-gray-400 rotate-180" />
                </div>

                <div className="flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-red-100 rounded-full">
                      <UserMinus className="w-5 h-5 text-red-600" />
                    </div>
                    <span className="font-medium text-red-600">Exit Group</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Members List */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Members ({group.members.length})</span>
                <Button variant="ghost" size="sm">
                  <Search className="w-4 h-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-0">
                {sampleMembers.map((member, index) => (
                  <div key={member.id} className="flex items-center justify-between p-4 hover:bg-gray-50">
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback className="bg-vito-blue text-white">
                          {member.name[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center space-x-2">
                          <p className="font-medium">{member.name}</p>
                          {member.role === "admin" && (
                            <Crown className="w-4 h-4 text-yellow-500" />
                          )}
                        </div>
                        <p className="text-sm text-gray-500">
                          {member.isOnline ? "online" : member.lastSeen || "offline"}
                        </p>
                      </div>
                    </div>
                    
                    {member.id !== "me" && (
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-vito-blue text-white p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="text-white hover:bg-white/20 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <Avatar className="w-10 h-10">
            <AvatarImage src={group.avatar} />
            <AvatarFallback className="bg-white text-vito-blue">
              {group.name[0]}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <h3 className="font-semibold">{group.name}</h3>
            <p className="text-sm text-white/80">
              {group.members.length} members
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
            <Video className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
            <Phone className="w-5 h-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowGroupInfo(true)}
            className="text-white hover:bg-white/20"
          >
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Date Separator */}
        <div className="flex justify-center">
          <Badge variant="secondary" className="text-xs">
            Today
          </Badge>
        </div>
        
        {messages.map(renderMessage)}
        <div ref={messagesEndRef} />
      </div>

      {/* Typing Indicators */}
      <div className="px-4 pb-2">
        <div className="flex items-center space-x-2">
          <Avatar className="w-6 h-6">
            <AvatarImage src={sampleMembers[1].avatar} />
            <AvatarFallback className="text-xs bg-vito-blue text-white">
              {sampleMembers[1].name[0]}
            </AvatarFallback>
          </Avatar>
          <div className="bg-white rounded-lg px-3 py-2 border">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Message Input */}
      <div className="bg-white border-t p-4">
        {showMediaOptions && (
          <Card className="mb-4 p-4">
            <div className="grid grid-cols-3 gap-4">
              <Button variant="outline" className="flex flex-col items-center space-y-2 h-20">
                <Camera className="w-6 h-6 text-blue-500" />
                <span className="text-xs">Photo</span>
              </Button>
              <Button variant="outline" className="flex flex-col items-center space-y-2 h-20">
                <Video className="w-6 h-6 text-green-500" />
                <span className="text-xs">Video</span>
              </Button>
              <Button variant="outline" className="flex flex-col items-center space-y-2 h-20">
                <Paperclip className="w-6 h-6 text-purple-500" />
                <span className="text-xs">Document</span>
              </Button>
            </div>
          </Card>
        )}
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowMediaOptions(!showMediaOptions)}
            className="text-gray-500 hover:bg-gray-100"
          >
            <Plus className="w-5 h-5" />
          </Button>
          
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="pr-20"
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            />
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
              <Button variant="ghost" size="sm" className="w-8 h-8 p-0 text-gray-500">
                <Smile className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" className="w-8 h-8 p-0 text-gray-500">
                <Paperclip className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {newMessage.trim() ? (
            <Button
              onClick={handleSendMessage}
              className="bg-vito-blue hover:bg-vito-blue/90"
            >
              <Send className="w-5 h-5" />
            </Button>
          ) : (
            <Button className="bg-vito-blue hover:bg-vito-blue/90">
              <Mic className="w-5 h-5" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}