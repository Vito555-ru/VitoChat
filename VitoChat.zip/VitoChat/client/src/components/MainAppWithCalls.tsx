import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MainTabs } from './MainTabs';
import { CallManager } from './CallManager';
import { EnhancedProfileSettings } from './EnhancedProfileSettings';
import { useProfileSettings } from '@/hooks/useProfileSettings';
import { Button } from '@/components/ui/button';
import { Phone, Video, Settings, ArrowLeft } from 'lucide-react';
import type { User } from '@shared/schema';

interface MainAppWithCallsProps {
  initialUser: User;
}

export function MainAppWithCalls({ initialUser }: MainAppWithCallsProps) {
  const [currentView, setCurrentView] = useState<'main' | 'settings'>('main');
  
  // Get current user data with live updates
  const { data: user } = useQuery({
    queryKey: ['/api/auth/me'],
    initialData: initialUser,
    refetchInterval: 5000, // Refresh every 5 seconds for real-time updates
  });

  const {
    updateProfile,
    changeNumber,
    deleteAccount,
    isUpdating,
    isChangingNumber,
    isDeletingAccount,
  } = useProfileSettings(user?.id || '');

  // Show settings view
  if (currentView === 'settings' && user) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        {/* Header */}
        <div className="bg-white dark:bg-gray-800 border-b px-4 py-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentView('main')}
              className="flex items-center gap-2"
            >
              <ArrowLeft size={16} />
              Back
            </Button>
            <h1 className="text-xl font-semibold">Settings</h1>
          </div>
        </div>
        
        {/* Settings Content */}
        <EnhancedProfileSettings
          user={user}
          onUpdateProfile={updateProfile}
          onChangeNumber={changeNumber}
          onDeleteAccount={deleteAccount}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Call Manager - handles all calling functionality */}
      {user && <CallManager userId={user.id} />}
      
      {/* Main App Interface */}
      <div className="max-w-md mx-auto bg-white dark:bg-gray-800 min-h-screen">
        {/* Header with Call Actions */}
        <div className="bg-blue-600 text-white p-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold">VITO</h1>
              <p className="text-sm opacity-90">
                {user?.firstName} {user?.lastName}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {/* Quick Call Actions */}
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-blue-700"
                onClick={() => {
                  // TODO: Open contact selector for voice call
                  console.log('Voice call');
                }}
              >
                <Phone size={18} />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-blue-700"
                onClick={() => {
                  // TODO: Open contact selector for video call
                  console.log('Video call');
                }}
              >
                <Video size={18} />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-blue-700"
                onClick={() => setCurrentView('settings')}
              >
                <Settings size={18} />
              </Button>
            </div>
          </div>
        </div>

        {/* Main App Content */}
        <div className="flex-1">
          <MainTabs />
        </div>
      </div>

      {/* Status Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-green-500 text-white text-center py-1 text-xs">
        {user?.isOnline ? 'Online' : 'Connecting...'}
        {isUpdating && ' • Updating profile...'}
        {isChangingNumber && ' • Changing number...'}
        {isDeletingAccount && ' • Deleting account...'}
      </div>
    </div>
  );
}