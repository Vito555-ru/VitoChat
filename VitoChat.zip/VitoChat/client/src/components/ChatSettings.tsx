import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  ArrowLeft, 
  Palette, 
  Download, 
  Trash2, 
  RotateCcw,
  Image,
  Camera,
  Smartphone
} from "lucide-react";

interface ChatSettingsProps {
  onBack: () => void;
  contact: any;
}

const solidColors = [
  { name: "Default", color: "#f3f4f6" },
  { name: "Blue", color: "#dbeafe" },
  { name: "Green", color: "#dcfce7" },
  { name: "Purple", color: "#f3e8ff" },
  { name: "Pink", color: "#fce7f3" },
  { name: "Yellow", color: "#fef3c7" },
  { name: "Orange", color: "#fed7aa" },
  { name: "Red", color: "#fecaca" },
  { name: "Gray", color: "#f9fafb" },
  { name: "Dark", color: "#374151" }
];

const vitoWallpapers = [
  { name: "VITO Classic", image: "/wallpapers/vito-classic.jpg" },
  { name: "Abstract Blue", image: "/wallpapers/abstract-blue.jpg" },
  { name: "Gradient Flow", image: "/wallpapers/gradient-flow.jpg" },
  { name: "Tech Pattern", image: "/wallpapers/tech-pattern.jpg" },
  { name: "Minimal Dots", image: "/wallpapers/minimal-dots.jpg" },
  { name: "Wave Design", image: "/wallpapers/wave-design.jpg" }
];

export function ChatSettings({ onBack, contact }: ChatSettingsProps) {
  const getChatWallpaperKey = (contactName: string) => `chat_wallpaper_${contactName.replace(/\s+/g, '_')}`;
  
  // Load saved wallpaper preference on component mount
  const loadSavedWallpaper = () => {
    const saved = localStorage.getItem(getChatWallpaperKey(contact.name));
    if (saved) {
      const { wallpaper, type } = JSON.parse(saved);
      return { wallpaper, type };
    }
    return { wallpaper: "default", type: "solid" };
  };
  
  const savedWallpaper = loadSavedWallpaper();
  const [currentWallpaper, setCurrentWallpaper] = useState(savedWallpaper.wallpaper);
  const [wallpaperType, setWallpaperType] = useState<"solid" | "gallery" | "vito">(savedWallpaper.type);
  const [showWallpaperDialog, setShowWallpaperDialog] = useState(false);

  const handleDeleteChat = () => {
    if (confirm(`Are you sure you want to delete this chat with ${contact.name}? This action cannot be undone.`)) {
      alert("Chat would be deleted");
      onBack();
    }
  };

  const handleClearChat = () => {
    if (confirm(`Are you sure you want to clear all messages in this chat with ${contact.name}?`)) {
      alert("Chat messages would be cleared");
    }
  };

  const handleExportChat = () => {
    alert("Chat export functionality would be implemented here");
  };

  const handleWallpaperChange = (wallpaper: string, type: "solid" | "gallery" | "vito") => {
    setCurrentWallpaper(wallpaper);
    setWallpaperType(type);
    
    // Save wallpaper preference to localStorage
    const wallpaperData = { wallpaper, type };
    localStorage.setItem(getChatWallpaperKey(contact.name), JSON.stringify(wallpaperData));
    
    setShowWallpaperDialog(false);
  };

  const handleResetWallpaper = () => {
    // Reset to default wallpaper and remove from localStorage
    localStorage.removeItem(getChatWallpaperKey(contact.name));
    setCurrentWallpaper("default");
    setWallpaperType("solid");
  };

  const handleGalleryUpload = () => {
    // Trigger file input for gallery photo
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const url = URL.createObjectURL(file);
        handleWallpaperChange(url, "gallery");
      }
    };
    input.click();
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-vito-blue text-white p-4 flex items-center">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-white/20 mr-3">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-semibold">Chat Settings</h1>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Chat with {contact.name}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Wallpaper</h4>
                <p className="text-sm text-gray-500">Change chat background</p>
              </div>
              <Button variant="outline" onClick={() => setShowWallpaperDialog(true)}>
                <Palette className="w-4 h-4 mr-2" />
                Change
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Chat Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Export Chat</h4>
                <p className="text-sm text-gray-500">Download chat history</p>
              </div>
              <Button variant="outline" onClick={handleExportChat}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">Clear Chat</h4>
                <p className="text-sm text-gray-500">Delete all messages</p>
              </div>
              <Button variant="outline" onClick={handleClearChat}>
                <Trash2 className="w-4 h-4 mr-2" />
                Clear
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-red-600">Delete Chat</h4>
                <p className="text-sm text-gray-500">Permanently delete this chat</p>
              </div>
              <Button variant="outline" className="text-red-600" onClick={handleDeleteChat}>
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={showWallpaperDialog} onOpenChange={setShowWallpaperDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Change Wallpaper</DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            {/* Solid Colors */}
            <div>
              <h4 className="font-medium mb-3">Solid Colors</h4>
              <div className="grid grid-cols-5 gap-2">
                {solidColors.map((color) => (
                  <button
                    key={color.name}
                    className="w-12 h-12 rounded-lg border-2 border-gray-200 hover:border-vito-blue transition-colors"
                    style={{ backgroundColor: color.color }}
                    onClick={() => handleWallpaperChange(color.color, "solid")}
                    title={color.name}
                  />
                ))}
              </div>
            </div>

            {/* Gallery Photos */}
            <div>
              <h4 className="font-medium mb-3">Gallery Photos</h4>
              <Button variant="outline" onClick={handleGalleryUpload} className="w-full">
                <Image className="w-4 h-4 mr-2" />
                Choose from Gallery
              </Button>
            </div>

            {/* VITO Collection */}
            <div>
              <h4 className="font-medium mb-3">VIOT Wallpaper Collection</h4>
              <div className="grid grid-cols-2 gap-2">
                {vitoWallpapers.map((wallpaper) => (
                  <button
                    key={wallpaper.name}
                    className="aspect-video bg-gradient-to-br from-vito-blue to-blue-600 rounded-lg border-2 border-gray-200 hover:border-vito-blue transition-colors flex items-center justify-center text-white text-xs font-medium"
                    onClick={() => handleWallpaperChange(wallpaper.image, "vito")}
                  >
                    {wallpaper.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Reset to Default */}
            <div className="pt-4 border-t">
              <Button 
                variant="outline" 
                onClick={handleResetWallpaper} 
                className="w-full"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset to Default
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}