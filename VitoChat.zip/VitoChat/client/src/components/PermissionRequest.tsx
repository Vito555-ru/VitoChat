import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Contact, Camera, Bell, ChevronLeft, Check } from "lucide-react";

interface PermissionRequestProps {
  onComplete: () => void;
  onBack: () => void;
}

const permissions = [
  {
    icon: Contact,
    title: "Contacts",
    description: "Find friends who are on VITO and invite others to join",
    required: true
  },
  {
    icon: Camera,
    title: "Camera & Photos",
    description: "Take photos and videos, and send media in chats",
    required: true
  },
  {
    icon: Bell,
    title: "Notifications",
    description: "Get notified when you receive new messages",
    required: false
  }
];

export function PermissionRequest({ onComplete, onBack }: PermissionRequestProps) {
  const [grantedPermissions, setGrantedPermissions] = useState<string[]>([]);
  const [currentStep, setCurrentStep] = useState(0);

  const handleGrantPermission = async (permissionType: string) => {
    // In a real app, request actual permissions here
    try {
      let granted = false;
      
      switch (permissionType) {
        case "Contacts":
          // navigator.permissions API or browser-specific contact access
          granted = true; // Simulated for demo
          break;
        case "Camera & Photos":
          const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
          stream.getTracks().forEach(track => track.stop());
          granted = true;
          break;
        case "Notifications":
          const permission = await Notification.requestPermission();
          granted = permission === "granted";
          break;
        default:
          granted = true;
      }

      if (granted) {
        setGrantedPermissions(prev => [...prev, permissionType]);
      }
    } catch (error) {
      console.log(`Permission ${permissionType} denied or not available`);
    }

    // Move to next permission or complete
    if (currentStep < permissions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handleSkip = () => {
    if (currentStep < permissions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const currentPermission = permissions[currentStep];
  const IconComponent = currentPermission.icon;

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center mb-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="p-2">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <CardTitle className="flex-1 text-center">Permissions</CardTitle>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-500 mb-2">
              {currentStep + 1} of {permissions.length}
            </p>
            <div className="flex justify-center space-x-2">
              {permissions.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full ${
                    index <= currentStep ? 'bg-vito-blue' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="w-20 h-20 bg-vito-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <IconComponent className="w-10 h-10 text-vito-blue" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {currentPermission.title}
            </h3>
            <p className="text-gray-600 leading-relaxed">
              {currentPermission.description}
            </p>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => handleGrantPermission(currentPermission.title)}
              className="w-full bg-vito-blue hover:bg-vito-dark text-white py-3"
            >
              <Check className="w-4 h-4 mr-2" />
              Allow {currentPermission.title}
            </Button>

            {!currentPermission.required && (
              <Button 
                variant="outline"
                onClick={handleSkip}
                className="w-full"
              >
                Skip for now
              </Button>
            )}
          </div>

          <div className="text-center">
            <p className="text-xs text-gray-500 leading-relaxed">
              {currentPermission.required 
                ? "This permission is required for VITO to work properly."
                : "You can change these permissions later in your device settings."
              }
            </p>
          </div>

          {grantedPermissions.length > 0 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800 font-medium">
                Granted permissions:
              </p>
              <ul className="text-sm text-green-700 mt-1">
                {grantedPermissions.map((permission, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="w-3 h-3 mr-1" />
                    {permission}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}