import { useState, useEffect } from "react";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

export function SplashScreen() {
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    // Trigger content animation immediately
    const timer = setTimeout(() => {
      setShowContent(true);
    }, 100);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-vito-blue via-vito-blue to-vito-dark flex flex-col items-center justify-center z-50">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-white/5 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute bottom-1/3 right-1/4 w-24 h-24 bg-white/5 rounded-full blur-xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 right-1/3 w-16 h-16 bg-white/5 rounded-full blur-xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className={`flex flex-col items-center space-y-8 transform transition-all duration-1000 ease-out ${
        showContent ? 'translate-y-0 opacity-100 scale-100' : 'translate-y-8 opacity-0 scale-95'
      }`}>
        {/* VITO Logo with pulse animation */}
        <div className="w-32 h-32 flex items-center justify-center relative">
          <div className="absolute inset-0 bg-white/10 rounded-3xl animate-pulse"></div>
          <img 
            src={vitoLogoPath} 
            alt="VITO Logo" 
            className={`w-28 h-28 object-contain drop-shadow-2xl relative z-10 transform transition-all duration-1000 ease-out ${
              showContent ? 'rotate-0 scale-100' : 'rotate-12 scale-90'
            }`}
          />
        </div>
        
        {/* App Name with staggered animation */}
        <div className="text-center">
          <h1 className={`text-5xl font-bold text-white mb-3 font-inter tracking-wide transform transition-all duration-1000 ease-out ${
            showContent ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
          }`} style={{ transitionDelay: '300ms' }}>
            VITO
          </h1>
          <p className={`text-blue-100 text-xl font-inter font-light tracking-wider transform transition-all duration-1000 ease-out ${
            showContent ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
          }`} style={{ transitionDelay: '500ms' }}>
            Secure Messaging
          </p>
        </div>

        {/* Loading indicator */}
        <div className={`transform transition-all duration-1000 ease-out ${
          showContent ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
        }`} style={{ transitionDelay: '700ms' }}>
          <div className="flex space-x-2">
            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
        </div>
      </div>
      
      {/* Powered by Blackhole Networks with fade-in */}
      <div className={`absolute bottom-12 flex flex-col items-center space-y-3 transform transition-all duration-1000 ease-out ${
        showContent ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
      }`} style={{ transitionDelay: '900ms' }}>
        <p className="text-blue-200 text-sm font-inter font-light tracking-widest">BY</p>
        <span className="text-white font-semibold text-lg font-inter tracking-wide">BLACKHOLE NETWORKS</span>
      </div>
    </div>
  );
}
