import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Users, Phone, Settings, Camera, Plus, Search, MoreVertical, Video, PhoneIncoming, PhoneOutgoing } from "lucide-react";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";
import { useChats } from "@/hooks/useChats";
import { useContacts } from "@/hooks/useContacts";
import { useCalls } from "@/hooks/useCalls";
import { useMessages } from "@/hooks/useMessages";
import { ComprehensiveSettings } from "./ComprehensiveSettings";
import { EnhancedChatScreen } from "./EnhancedChatScreen";
import { GroupChatScreen } from "./GroupChatScreen";
import { MediaViewer } from "./MediaViewer";
import { CallScreen } from "./CallScreen";
import { StatusTab } from "./StatusTab";
import { NewChatDialog } from "./NewChatDialog";
import { NewCallDialog } from "./NewCallDialog";
import { SmartSearchDialog } from "./SmartSearchDialog";

type ViewState = 
  | { type: "main" }
  | { type: "settings" }
  | { type: "chat"; contact: any }
  | { type: "group-chat"; group: any }
  | { type: "media-viewer"; mediaItems: any[]; currentIndex: number }
  | { type: "call"; callType: "voice" | "video"; contact: any; isIncoming?: boolean };

function formatLastSeen(lastSeen: string | Date): string {
  if (!lastSeen) return "";
  const date = new Date(lastSeen);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  
  if (diffMins < 1) return "just now";
  if (diffMins < 60) return `${diffMins} min ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  return date.toLocaleDateString();
}

interface MainTabsProps {
  user: any;
  onLogout: () => void;
}

export function MainTabs({ user, onLogout }: MainTabsProps) {
  const [activeTab, setActiveTab] = useState("chats");
  const [currentView, setCurrentView] = useState<ViewState>({ type: "main" });
  const [showNewChatDialog, setShowNewChatDialog] = useState(false);
  const [showSmartSearch, setShowSmartSearch] = useState(false);

  const handleLogout = () => {
    onLogout();
  };

  // Real-time data from the backend - replacing all mock data
  const { data: chats = [], isLoading: chatsLoading } = useChats();
  const { data: contacts = [] } = useContacts();
  const { data: calls = [] } = useCalls();
  const { isConnected } = useMessages();

  if (currentView.type === "settings") {
    return <ComprehensiveSettings onBack={() => setCurrentView({ type: "main" })} />;
  }

  if (currentView.type === "chat") {
    return (
      <EnhancedChatScreen 
        onBack={() => setCurrentView({ type: "main" })}
        onCall={(type) => setCurrentView({ 
          type: "call", 
          callType: type, 
          contact: currentView.contact 
        })}
        contact={currentView.contact}
      />
    );
  }

  if (currentView.type === "call") {
    return (
      <CallScreen 
        onEndCall={() => setCurrentView({ type: "main" })}
        onBack={() => setCurrentView({ type: "main" })}
        callType={currentView.callType}
        contact={currentView.contact}
        isIncoming={currentView.isIncoming}
      />
    );
  }

  if (currentView.type === "group-chat") {
    return (
      <GroupChatScreen 
        onBack={() => setCurrentView({ type: "main" })}
        group={currentView.group}
      />
    );
  }

  if (currentView.type === "media-viewer") {
    return (
      <MediaViewer 
        mediaItems={currentView.mediaItems}
        currentIndex={currentView.currentIndex}
        onClose={() => setCurrentView({ type: "main" })}
        onIndexChange={(index) => setCurrentView({ 
          type: "media-viewer", 
          mediaItems: currentView.mediaItems, 
          currentIndex: index 
        })}
      />
    );
  }

  if (currentView.type === "call") {
    return (
      <CallScreen 
        onEndCall={() => setCurrentView({ type: "main" })}
        onBack={() => setCurrentView({ type: "main" })}
        callType={currentView.callType}
        contact={currentView.contact}
        isIncoming={currentView.isIncoming}
      />
    );
  }

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="bg-vito-blue text-white p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <img 
            src={vitoLogoPath} 
            alt="VITO Logo" 
            className="w-8 h-8 object-contain"
          />
          <h1 className="text-xl font-semibold">VITO</h1>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-white hover:bg-white/20"
            onClick={() => setShowSmartSearch(true)}
          >
            <Search className="w-5 h-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setCurrentView({ type: "settings" })}
            className="text-white hover:bg-white/20"
          >
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsContent value="chats" className="flex-1 p-0 m-0">
          <ChatsTab 
            chats={chats}
            isLoading={chatsLoading}
            onOpenChat={(contact) => setCurrentView({ type: "chat", contact })}
            onOpenGroupChat={(group) => setCurrentView({ type: "group-chat", group })}
          />
        </TabsContent>
        
        <TabsContent value="status" className="flex-1 p-0 m-0">
          <StatusTab />
        </TabsContent>
        
        <TabsContent value="calls" className="flex-1 p-0 m-0">
          <CallsTab onStartCall={(contact, callType) => setCurrentView({ 
            type: "call", 
            callType, 
            contact, 
            isIncoming: false 
          })} />
        </TabsContent>
        
        <TabsContent value="communities" className="flex-1 p-0 m-0">
          <CommunitiesTab />
        </TabsContent>

        {/* Bottom Navigation */}
        <TabsList className="grid w-full grid-cols-4 bg-gray-100 h-16">
          <TabsTrigger 
            value="chats" 
            className="flex flex-col items-center space-y-1 py-2 data-[state=active]:bg-white data-[state=active]:text-vito-blue"
          >
            <MessageCircle className="w-5 h-5" />
            <span className="text-xs">Chats</span>
            <Badge variant="destructive" className="w-5 h-5 text-xs p-0 flex items-center justify-center">
              3
            </Badge>
          </TabsTrigger>
          
          <TabsTrigger 
            value="status" 
            className="flex flex-col items-center space-y-1 py-2 data-[state=active]:bg-white data-[state=active]:text-vito-blue"
          >
            <div className="relative">
              <Camera className="w-5 h-5" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
            </div>
            <span className="text-xs">Status</span>
          </TabsTrigger>
          
          <TabsTrigger 
            value="calls" 
            className="flex flex-col items-center space-y-1 py-2 data-[state=active]:bg-white data-[state=active]:text-vito-blue"
          >
            <Phone className="w-5 h-5" />
            <span className="text-xs">Calls</span>
          </TabsTrigger>
          
          <TabsTrigger 
            value="communities" 
            className="flex flex-col items-center space-y-1 py-2 data-[state=active]:bg-white data-[state=active]:text-vito-blue"
          >
            <Users className="w-5 h-5" />
            <span className="text-xs">Communities</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Smart Search Dialog */}
      <SmartSearchDialog
        open={showSmartSearch}
        onOpenChange={setShowSmartSearch}
        onSelectResult={(result) => {
          // Handle different types of search results
          if (result.chatName) {
            // If it's a message result, open the chat
            setCurrentView({ 
              type: "chat", 
              contact: {
                name: result.chatName,
                avatar: result.avatar || "",
                isOnline: true,
                lastSeen: undefined
              }
            });
          }
          setShowSmartSearch(false);
        }}
      />
    </div>
  );
}

function ChatsTab({ onOpenChat, onOpenGroupChat }: { 
  onOpenChat: (contact: any) => void; 
  onOpenGroupChat: (group: any) => void; 
}) {
  const [showNewChatDialog, setShowNewChatDialog] = useState(false);
  
  const chats = [
    {
      id: 1,
      name: "Alex Johnson",
      lastMessage: "Hey, how are you doing?",
      time: "2:30 PM",
      unreadCount: 2,
      avatar: "",
      isOnline: true
    },
    {
      id: 2,
      name: "Sarah Wilson",
      lastMessage: "Thanks for the help!",
      time: "1:15 PM",
      unreadCount: 0,
      avatar: "",
      isOnline: false
    },
    {
      id: 3,
      name: "Team Group",
      lastMessage: "Meeting at 3 PM",
      time: "12:45 PM",
      unreadCount: 1,
      avatar: "",
      isOnline: false,
      isGroup: true
    }
  ];

  return (
    <div className="flex-1 bg-white">
      {chats.length > 0 ? (
        <div className="divide-y divide-gray-100">
          {chats.map((chat) => (
            <div 
              key={chat.id} 
              className="p-4 hover:bg-gray-50 cursor-pointer"
              onClick={() => {
                if (chat.isGroup) {
                  onOpenGroupChat({
                    id: chat.id.toString(),
                    name: chat.name,
                    members: [{ id: "1", name: "Alice", role: "admin", isOnline: true }],
                    createdBy: "1",
                    createdAt: new Date()
                  });
                } else {
                  onOpenChat({
                    name: chat.name,
                    avatar: chat.avatar,
                    isOnline: chat.isOnline,
                    lastSeen: chat.isOnline ? undefined : "2 hours ago"
                  });
                }
              }}
            >
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={chat.avatar} alt={chat.name} />
                    <AvatarFallback className="bg-vito-blue text-white">
                      {chat.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  {chat.isOnline && !chat.isGroup && (
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h3 className="font-medium text-gray-900 truncate">{chat.name}</h3>
                    <span className="text-xs text-gray-500">{chat.time}</span>
                  </div>
                  <p className="text-sm text-gray-600 truncate mt-1">{chat.lastMessage}</p>
                </div>
                {chat.unreadCount > 0 && (
                  <Badge variant="destructive" className="w-6 h-6 text-xs p-0 flex items-center justify-center">
                    {chat.unreadCount}
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No chats yet</h3>
            <p className="text-gray-600 mb-6">Start a conversation to see your chats here</p>
            <Button 
              className="bg-green-600 hover:bg-green-700 text-white"
              onClick={() => setShowNewChatDialog(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          </div>
        </div>
      )}
      
      {/* Floating Action Button */}
      <Button 
        className="fixed bottom-20 right-6 w-14 h-14 rounded-full bg-green-600 hover:bg-green-700 text-white shadow-lg"
        size="icon"
        onClick={() => setShowNewChatDialog(true)}
      >
        <Plus className="w-6 h-6" />
      </Button>

      {/* New Chat Dialog */}
      <NewChatDialog
        open={showNewChatDialog}
        onOpenChange={setShowNewChatDialog}
        onStartChat={(user) => {
          onOpenChat({
            name: `${user.firstName} ${user.lastName || ""}`.trim(),
            avatar: user.profileImage || "",
            isOnline: user.isOnline,
            lastSeen: user.lastSeen ? "Last seen " + formatLastSeen(user.lastSeen) : undefined,
            phoneNumber: user.phoneNumber
          });
        }}
      />
    </div>
  );
}



function CallsTab({ onStartCall }: { onStartCall?: (contact: any, callType: "voice" | "video") => void }) {
  const [showNewCallDialog, setShowNewCallDialog] = useState(false);

  const callHistory = [
    {
      id: 1,
      name: "Alex Johnson",
      type: "outgoing" as const,
      callType: "video" as const,
      time: "Today, 2:30 PM",
      duration: "12:34",
      avatar: "",
      missed: false,
      phoneNumber: "+1 (555) 123-4567"
    },
    {
      id: 2,
      name: "Sarah Wilson", 
      type: "incoming" as const,
      callType: "voice" as const,
      time: "Today, 1:15 PM",
      duration: "5:42",
      avatar: "",
      missed: false,
      phoneNumber: "+1 (555) 987-6543"
    },
    {
      id: 3,
      name: "Mom",
      type: "incoming" as const,
      callType: "voice" as const,
      time: "Yesterday, 8:20 PM",
      duration: "",
      avatar: "",
      missed: true,
      phoneNumber: "+1 (555) 555-0123"
    },
    {
      id: 4,
      name: "Team Group",
      type: "outgoing" as const,
      callType: "video" as const,
      time: "Yesterday, 3:45 PM", 
      duration: "25:18",
      avatar: "",
      missed: false,
      isGroup: true,
      phoneNumber: ""
    }
  ];

  const handleCallContact = (contact: any, callType: "voice" | "video") => {
    console.log(`Starting ${callType} call with ${contact.name}`);
    if (onStartCall) {
      onStartCall(contact, callType);
    }
    setShowNewCallDialog(false);
  };

  const handleCallFromHistory = (call: any, callType: "voice" | "video") => {
    const contact = {
      name: call.name,
      avatar: call.avatar,
      phoneNumber: call.phoneNumber,
      isGroup: call.isGroup
    };
    handleCallContact(contact, callType);
  };

  return (
    <div className="flex-1 bg-white">
      {callHistory.length > 0 ? (
        <>
          {/* Call History List */}
          <div className="divide-y divide-gray-100">
            {callHistory.map((call) => (
              <div key={call.id} className="p-4 hover:bg-gray-50">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={call.avatar} alt={call.name} />
                      <AvatarFallback className="bg-vito-blue text-white">
                        {call.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <h3 className="font-medium text-gray-900 truncate">{call.name}</h3>
                      {call.isGroup && (
                        <Users className="w-4 h-4 text-gray-500" />
                      )}
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      {call.type === "incoming" ? (
                        <PhoneIncoming className={`w-4 h-4 ${call.missed ? 'text-red-500' : 'text-green-500'}`} />
                      ) : (
                        <PhoneOutgoing className="w-4 h-4 text-blue-500" />
                      )}
                      {call.callType === "video" && (
                        <Video className="w-4 h-4 text-gray-500" />
                      )}
                      <span className="text-sm text-gray-600">{call.time}</span>
                      {call.duration && (
                        <>
                          <span className="text-gray-400">•</span>
                          <span className="text-sm text-gray-600">{call.duration}</span>
                        </>
                      )}
                      {call.missed && (
                        <span className="text-sm text-red-500">(Missed)</span>
                      )}
                    </div>
                  </div>

                  {/* Call Actions */}
                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      className="text-green-600 hover:text-green-700 hover:bg-green-50"
                      onClick={() => handleCallFromHistory(call, "voice")}
                    >
                      <Phone className="w-5 h-5" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                      onClick={() => handleCallFromHistory(call, "video")}
                    >
                      <Video className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center py-8">
            <Phone className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No calls yet</h3>
            <p className="text-gray-600 mb-6">Your call history will appear here</p>
            <Button 
              className="bg-vito-blue hover:bg-vito-dark text-white"
              onClick={() => setShowNewCallDialog(true)}
            >
              <Phone className="w-4 h-4 mr-2" />
              New Call
            </Button>
          </div>
        </div>
      )}
      
      {/* Floating Action Button for New Call */}
      <Button 
        className="fixed bottom-20 right-6 w-14 h-14 rounded-full bg-green-600 hover:bg-green-700 text-white shadow-lg"
        size="icon"
        onClick={() => setShowNewCallDialog(true)}
      >
        <Phone className="w-6 h-6" />
      </Button>

      {/* New Call Dialog */}
      <NewCallDialog
        open={showNewCallDialog}
        onOpenChange={setShowNewCallDialog}
        onStartCall={handleCallContact}
      />
    </div>
  );
}

function CommunitiesTab() {
  return (
    <div className="flex-1 bg-white p-4">
      <div className="text-center py-8">
        <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Stay connected with a community</h3>
        <p className="text-gray-600 mb-6">Communities bring members together in topic-based groups</p>
        <Button className="bg-vito-blue hover:bg-vito-dark text-white">
          <Plus className="w-4 h-4 mr-2" />
          Start Community
        </Button>
      </div>
    </div>
  );
}

