import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { 
  ArrowLeft, 
  Camera, 
  Edit2, 
  Shield, 
  Bell, 
  Moon, 
  Sun, 
  Palette, 
  Download,
  Trash2,
  Phone,
  Mail,
  User,
  Lock,
  Eye,
  EyeOff,
  Settings,
  LogOut,
  Check,
  X,
  ChevronRight,
  MessageSquare,
  Archive,
  Upload,
  RefreshCw,
  Info,
  HelpCircle,
  Volume2,
  Smartphone,
  Users,
  FileText,
  Cloud,
  Calendar,
  Globe,
  Home,
  UserCheck,
  AlertTriangle,
  Save,
  RotateCcw
} from "lucide-react";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";
import { PhotoUploader } from "./PhotoUploader";

interface ComprehensiveSettingsProps {
  onBack: () => void;
}

type SettingsView = 
  | "main"
  | "profile" 
  | "account"
  | "privacy"
  | "chats"
  | "notifications"
  | "theme"
  | "backup"
  | "two-step";

export function ComprehensiveSettings({ onBack }: ComprehensiveSettingsProps) {
  const [currentView, setCurrentView] = useState<SettingsView>("main");
  const [isEditing, setIsEditing] = useState(false);
  const { user, logout, deleteAccount } = useAuth();
  const { toast } = useToast();
  
  // Profile settings
  const [profile, setProfile] = useState({
    name: "",
    about: "",
    phone: "",
    avatar: ""
  });

  // Load real user data when available
  useEffect(() => {
    if (user) {
      const fullName = user.firstName && user.lastName 
        ? `${user.firstName} ${user.lastName}` 
        : (user.firstName || user.lastName || "VITO User");
      
      const phoneDisplay = user.phoneNumber 
        ? `${user.countryCode || '+92'} ${user.phoneNumber}`
        : "";
      
      setProfile({
        name: fullName,
        about: user.bio || "Hey there! I am using VITO.",
        phone: phoneDisplay,
        avatar: user.profileImageUrl || ""
      });
    }
  }, [user]);

  // Privacy settings
  const [privacy, setPrivacy] = useState({
    lastSeen: "everyone",
    profilePhoto: "everyone",
    about: "everyone",
    status: "contacts",
    readReceipts: true,
    groups: "everyone"
  });

  // Theme settings
  const [theme, setTheme] = useState({
    mode: "light",
    wallpaper: "default",
    fontSize: 16,
    bubbleStyle: "rounded"
  });

  // Notification settings
  const [notifications, setNotifications] = useState({
    messageNotifications: true,
    messageTone: "default",
    callNotifications: true,
    ringtone: "default",
    groupNotifications: true,
    groupTone: "default",
    vibration: true,
    popup: true
  });

  // Chat settings
  const [chatSettings, setChatSettings] = useState({
    enterToSend: true,
    mediaAutoDownload: true,
    backupFrequency: "weekly",
    backupToCloud: false,
    archiveSettings: "manual"
  });

  // Two-step verification
  const [twoStep, setTwoStep] = useState({
    enabled: false,
    pin: "",
    confirmPin: "",
    email: "",
    hint: ""
  });

  const handleSaveProfile = () => {
    setIsEditing(false);
    // Save profile logic here
  };

  const handleLogout = async () => {
    try {
      console.log('User initiated logout');
      await logout();
      
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out. Redirecting to login screen.",
        variant: "default"
      });
    } catch (error: any) {
      console.error('Logout failed:', error);
      toast({
        title: "Logout Failed", 
        description: error.message || "Failed to log out. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleDeleteAccount = async () => {
    // Enhanced confirmation dialog for permanent account deletion
    const confirmFirst = confirm(
      "⚠️ WARNING: This will permanently delete your account!\n\n" +
      "This action will:\n" +
      "• Delete ALL your messages and chat history\n" +
      "• Remove your profile and contact list\n" +
      "• Erase all call logs and shared media\n" +
      "• Free your phone number for re-registration\n\n" +
      "This action CANNOT be undone!\n\n" +
      "Are you absolutely sure you want to continue?"
    );
    
    if (!confirmFirst) return;
    
    // Second confirmation to prevent accidental deletion
    const confirmSecond = confirm(
      "Final confirmation required!\n\n" +
      "Type confirmation: Are you 100% sure you want to PERMANENTLY DELETE your VITO account?\n\n" +
      "Click OK to proceed with permanent deletion, or Cancel to keep your account."
    );
    
    if (!confirmSecond) return;
    
    try {
      console.log('🗑️ User confirmed account deletion - proceeding...');
      await deleteAccount();
      
      // Account deletion will automatically redirect to welcome screen
      toast({
        title: "Account Deleted",
        description: "Your account has been permanently deleted. You can now register again with your phone number.",
        variant: "default"
      });
    } catch (error: any) {
      console.error('Account deletion failed:', error);
      toast({
        title: "Deletion Failed",
        description: error.message || "Failed to delete account. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleExportChats = () => {
    // Export chat functionality
    alert("Chat export would be implemented here");
  };

  const handleBackupNow = () => {
    // Immediate backup functionality
    alert("Starting backup...");
  };

  const handleClearAllChats = () => {
    // Clear all chats with confirmation
    if (confirm("Are you sure you want to clear all chats? This action cannot be undone.")) {
      alert("All chats would be cleared");
    }
  };

  if (currentView === "profile") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("main")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Profile</h1>
        </div>

        <div className="flex-1 overflow-y-auto">
          <div className="p-6">
            <div className="flex flex-col items-center mb-6">
              <PhotoUploader
                currentPhoto={profile.avatar}
                onPhotoChange={(photo) => setProfile({ ...profile, avatar: photo })}
                userName={profile.name}
              />
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <Input
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    disabled={!isEditing}
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsEditing(!isEditing)}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div>
                <Label htmlFor="about">About</Label>
                <Textarea
                  id="about"
                  value={profile.about}
                  onChange={(e) => setProfile({ ...profile, about: e.target.value })}
                  disabled={!isEditing}
                  className="mt-1"
                  placeholder="Add a few words about yourself..."
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={profile.phone}
                  disabled
                  className="mt-1"
                />
                <p className="text-sm text-gray-500 mt-1">
                  This is not your username or pin. This phone number is visible to your VIOT contacts.
                </p>
              </div>

              {isEditing && (
                <div className="flex space-x-2 pt-4">
                  <Button onClick={handleSaveProfile} className="flex-1">
                    <Check className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1">
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentView === "privacy") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("main")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Privacy & Security</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Who can see my personal info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Last Seen</Label>
                <Select value={privacy.lastSeen} onValueChange={(value) => setPrivacy({ ...privacy, lastSeen: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Profile Photo</Label>
                <Select value={privacy.profilePhoto} onValueChange={(value) => setPrivacy({ ...privacy, profilePhoto: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>About</Label>
                <Select value={privacy.about} onValueChange={(value) => setPrivacy({ ...privacy, about: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Status</Label>
                <Select value={privacy.status} onValueChange={(value) => setPrivacy({ ...privacy, status: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="everyone">Everyone</SelectItem>
                    <SelectItem value="contacts">My Contacts</SelectItem>
                    <SelectItem value="nobody">Nobody</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Read Receipts</Label>
                <Switch
                  checked={privacy.readReceipts}
                  onCheckedChange={(checked) => setPrivacy({ ...privacy, readReceipts: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <Shield className="w-4 h-4 mr-2" />
                Two-Step Verification
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Two-Step Verification</Label>
                  <p className="text-sm text-gray-500">Add extra security to your account</p>
                </div>
                <Button variant="outline" onClick={() => setCurrentView("two-step")}>
                  {twoStep.enabled ? "Enabled" : "Setup"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentView === "chats") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("main")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Chats</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Display</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Theme</Label>
                <Select value={theme.mode} onValueChange={(value) => setTheme({ ...theme, mode: value })}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="auto">Auto</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Wallpaper</Label>
                <Button variant="outline" onClick={() => setCurrentView("theme")}>
                  <Palette className="w-4 h-4 mr-2" />
                  Change
                </Button>
              </div>

              <div>
                <Label>Font Size</Label>
                <div className="mt-2">
                  <Slider
                    value={[theme.fontSize]}
                    onValueChange={([value]) => setTheme({ ...theme, fontSize: value })}
                    max={24}
                    min={12}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-500 mt-1">
                    <span>Small</span>
                    <span>Medium</span>
                    <span>Large</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Chat History</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Chat Backup</Label>
                  <p className="text-sm text-gray-500">Back up to Google Drive</p>
                </div>
                <Button variant="outline" onClick={() => setCurrentView("backup")}>
                  <Cloud className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Export Chat</Label>
                  <p className="text-sm text-gray-500">Export chat history</p>
                </div>
                <Button variant="outline" onClick={handleExportChats}>
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Clear All Chats</Label>
                  <p className="text-sm text-gray-500">Delete all chat data</p>
                </div>
                <Button variant="outline" className="text-red-600" onClick={handleClearAllChats}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentView === "notifications") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("main")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Notifications</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Message Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Show notifications</Label>
                <Switch
                  checked={notifications.messageNotifications}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, messageNotifications: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Notification tone</Label>
                <Select value={notifications.messageTone} onValueChange={(value) => setNotifications({ ...notifications, messageTone: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default (VITO)</SelectItem>
                    <SelectItem value="classic">Classic</SelectItem>
                    <SelectItem value="gentle">Gentle</SelectItem>
                    <SelectItem value="custom">Choose from device</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label>Vibration</Label>
                <Switch
                  checked={notifications.vibration}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, vibration: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Popup notification</Label>
                <Switch
                  checked={notifications.popup}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, popup: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Call Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Ringtone</Label>
                <Select value={notifications.ringtone} onValueChange={(value) => setNotifications({ ...notifications, ringtone: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="classic">Classic</SelectItem>
                    <SelectItem value="modern">Modern</SelectItem>
                    <SelectItem value="custom">Choose from device</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Group Notifications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Show notifications</Label>
                <Switch
                  checked={notifications.groupNotifications}
                  onCheckedChange={(checked) => setNotifications({ ...notifications, groupNotifications: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Notification tone</Label>
                <Select value={notifications.groupTone} onValueChange={(value) => setNotifications({ ...notifications, groupTone: value })}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default</SelectItem>
                    <SelectItem value="subtle">Subtle</SelectItem>
                    <SelectItem value="custom">Choose from device</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentView === "two-step") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("privacy")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Two-Step Verification</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center">
                <Shield className="w-4 h-4 mr-2" />
                Enhanced Security
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">
                Two-step verification provides additional security by asking for a PIN when registering your phone number with VIOT again.
              </p>

              {!twoStep.enabled ? (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="pin">Create a 6-digit PIN</Label>
                    <Input
                      id="pin"
                      type="password"
                      value={twoStep.pin}
                      onChange={(e) => setTwoStep({ ...twoStep, pin: e.target.value })}
                      maxLength={6}
                      placeholder="Enter 6-digit PIN"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="confirmPin">Confirm PIN</Label>
                    <Input
                      id="confirmPin"
                      type="password"
                      value={twoStep.confirmPin}
                      onChange={(e) => setTwoStep({ ...twoStep, confirmPin: e.target.value })}
                      maxLength={6}
                      placeholder="Confirm 6-digit PIN"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label htmlFor="email">Email Address (Optional)</Label>
                    <Input
                      id="email"
                      type="email"
                      value={twoStep.email}
                      onChange={(e) => setTwoStep({ ...twoStep, email: e.target.value })}
                      placeholder="Enter email for PIN recovery"
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      This email will be used to reset your PIN if you forget it.
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="hint">PIN Hint (Optional)</Label>
                    <Input
                      id="hint"
                      value={twoStep.hint}
                      onChange={(e) => setTwoStep({ ...twoStep, hint: e.target.value })}
                      placeholder="Add a hint to remember your PIN"
                      className="mt-1"
                    />
                  </div>

                  <Button 
                    className="w-full" 
                    onClick={() => setTwoStep({ ...twoStep, enabled: true })}
                    disabled={!twoStep.pin || twoStep.pin !== twoStep.confirmPin || twoStep.pin.length !== 6}
                  >
                    Enable Two-Step Verification
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center">
                      <Check className="w-5 h-5 text-green-600 mr-2" />
                      <span className="text-green-800 font-medium">Two-step verification is enabled</span>
                    </div>
                    <p className="text-green-700 text-sm mt-1">
                      Your account is protected with an additional security layer.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      Change PIN
                    </Button>
                    <Button variant="outline" className="w-full">
                      Change Email
                    </Button>
                    <Button variant="outline" className="w-full text-red-600" onClick={() => setTwoStep({ ...twoStep, enabled: false })}>
                      Disable Two-Step Verification
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentView === "account") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("main")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Account</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Account Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Change Number</Label>
                  <p className="text-sm text-gray-500">Switch or change your phone number</p>
                </div>
                <Button variant="outline">
                  <Smartphone className="w-4 h-4 mr-2" />
                  Change
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Request Account Info</Label>
                  <p className="text-sm text-gray-500">Download your account information</p>
                </div>
                <Button variant="outline">
                  <Info className="w-4 h-4 mr-2" />
                  Request
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Delete My Account</Label>
                  <p className="text-sm text-gray-500">Permanently delete your account</p>
                </div>
                <Button variant="outline" className="text-red-600" onClick={handleDeleteAccount}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <Button variant="outline" className="w-full" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentView === "backup") {
    return (
      <div className="h-screen bg-gray-50 flex flex-col">
        <div className="bg-vito-blue text-white p-4 flex items-center">
          <Button variant="ghost" size="sm" onClick={() => setCurrentView("chats")} className="text-white hover:bg-white/20 mr-3">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-semibold">Chat Backup</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Backup to Google Drive</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Auto Backup</Label>
                <Switch
                  checked={chatSettings.backupToCloud}
                  onCheckedChange={(checked) => setChatSettings({ ...chatSettings, backupToCloud: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Backup Frequency</Label>
                <Select value={chatSettings.backupFrequency} onValueChange={(value) => setChatSettings({ ...chatSettings, backupFrequency: value })}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button className="w-full" onClick={handleBackupNow}>
                <Cloud className="w-4 h-4 mr-2" />
                Backup Now
              </Button>

              <div className="text-sm text-gray-500 bg-gray-100 p-3 rounded">
                <p className="font-medium mb-1">Last backup: Never</p>
                <p>Your chats will be backed up to Google Drive when linked to your Google account.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Main settings menu
  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      <div className="bg-vito-blue text-white p-4 flex items-center">
        <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-white/20 mr-3">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg font-semibold">Settings</h1>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-4">
          <Card className="mb-4">
            <CardContent className="p-4">
              <div className="flex items-center space-x-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={profile.avatar} alt={profile.name} />
                  <AvatarFallback className="bg-vito-blue text-white text-xl">
                    {profile.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{profile.name}</h3>
                  <p className="text-gray-500">{profile.about}</p>
                  <p className="text-sm text-gray-400">{profile.phone}</p>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setCurrentView("profile")}>
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="px-4 space-y-1">
          <Button
            variant="ghost"
            className="w-full justify-start h-12 px-4"
            onClick={() => setCurrentView("account")}
          >
            <User className="w-5 h-5 mr-3" />
            <span className="flex-1 text-left">Account</span>
            <ChevronRight className="w-4 h-4" />
          </Button>

          <Button
            variant="ghost"
            className="w-full justify-start h-12 px-4"
            onClick={() => setCurrentView("privacy")}
          >
            <Shield className="w-5 h-5 mr-3" />
            <span className="flex-1 text-left">Privacy & Security</span>
            <ChevronRight className="w-4 h-4" />
          </Button>

          <Button
            variant="ghost"
            className="w-full justify-start h-12 px-4"
            onClick={() => setCurrentView("chats")}
          >
            <MessageSquare className="w-5 h-5 mr-3" />
            <span className="flex-1 text-left">Chats</span>
            <ChevronRight className="w-4 h-4" />
          </Button>

          <Button
            variant="ghost"
            className="w-full justify-start h-12 px-4"
            onClick={() => setCurrentView("notifications")}
          >
            <Bell className="w-5 h-5 mr-3" />
            <span className="flex-1 text-left">Notifications</span>
            <ChevronRight className="w-4 h-4" />
          </Button>

          <Separator className="my-4" />

          <Button
            variant="ghost"
            className="w-full justify-start h-12 px-4"
          >
            <HelpCircle className="w-5 h-5 mr-3" />
            <span className="flex-1 text-left">Help</span>
            <ChevronRight className="w-4 h-4" />
          </Button>

          <Button
            variant="ghost"
            className="w-full justify-start h-12 px-4"
          >
            <Info className="w-5 h-5 mr-3" />
            <span className="flex-1 text-left">About VIOT</span>
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-4 pt-8">
          <div className="text-center text-sm text-gray-500">
            <p>VITO by Blackhole Networks</p>
            <p>Version 1.0.0</p>
          </div>
        </div>
      </div>
    </div>
  );
}