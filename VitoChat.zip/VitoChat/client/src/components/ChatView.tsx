import { useState, useRef, useEffect } from "react";
import { useMessages, useSendMessage } from "@/hooks/useMessages";
import { useAuth } from "@/hooks/useAuth";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Phone, Video, MoreVertical, Send, Smile, Plus } from "lucide-react";
import type { ChatWithUsers } from "@shared/schema";

interface ChatViewProps {
  chat: ChatWithUsers;
  onBack: () => void;
}

export function ChatView({ chat, onBack }: ChatViewProps) {
  const [messageText, setMessageText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user: currentUser } = useAuth();
  
  const { data: messages, isLoading } = useMessages(chat.id);
  const sendMessageMutation = useSendMessage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    e?.preventDefault();
    
    if (!messageText.trim() || sendMessageMutation.isPending) return;

    try {
      await sendMessageMutation.mutateAsync({
        chatId: chat.id,
        content: messageText.trim(),
      });
      setMessageText("");
    } catch (error) {
      console.error("Failed to send message:", error);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatMessageTime = (date: Date | string) => {
    return new Date(date).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const getDefaultAvatar = (name: string) => {
    const initials = name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
    
    return (
      <div className="w-8 h-8 rounded-full bg-vito-blue flex items-center justify-center text-white text-xs font-semibold">
        {initials}
      </div>
    );
  };

  const getUserDisplayName = () => {
    const user = chat.otherUser;
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user.username || user.email;
  };

  const getUserStatus = () => {
    if (chat.otherUser.isOnline) {
      return "online";
    }
    
    if (chat.otherUser.lastSeen) {
      const lastSeen = new Date(chat.otherUser.lastSeen);
      const now = new Date();
      const diffInMinutes = (now.getTime() - lastSeen.getTime()) / (1000 * 60);
      
      if (diffInMinutes < 60) {
        return "last seen recently";
      } else if (diffInMinutes < 24 * 60) {
        return "last seen today";
      } else {
        return "last seen " + lastSeen.toLocaleDateString();
      }
    }
    
    return "offline";
  };

  return (
    <div className="flex flex-col h-full bg-gray-100">
      {/* Chat Header */}
      <div className="bg-vito-blue text-white px-4 py-3 shadow-sm">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white hover:bg-opacity-10 p-1"
            onClick={onBack}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="relative">
            {chat.otherUser.profileImageUrl ? (
              <img
                src={chat.otherUser.profileImageUrl}
                alt={getUserDisplayName()}
                className="w-10 h-10 rounded-full object-cover"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-white bg-opacity-20 flex items-center justify-center text-white font-semibold">
                {getUserDisplayName()[0].toUpperCase()}
              </div>
            )}
            {chat.otherUser.isOnline && (
              <div className="online-indicator" />
            )}
          </div>
          <div className="flex-1">
            <h3 className="font-semibold font-inter">{getUserDisplayName()}</h3>
            <p className="text-sm text-blue-100">{getUserStatus()}</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white hover:bg-opacity-10"
            >
              <Video className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white hover:bg-opacity-10"
            >
              <Phone className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white hover:bg-opacity-10"
            >
              <MoreVertical className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <LoadingSpinner size="lg" />
          </div>
        ) : !messages || messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">Start a conversation</h3>
              <p className="text-sm">Send a message to begin chatting</p>
            </div>
          </div>
        ) : (
          <>
            {messages.map((message) => {
              const isOwn = message.senderId === currentUser?.id;
              
              return (
                <div
                  key={message.id}
                  className={`flex items-start space-x-2 ${isOwn ? 'justify-end' : ''}`}
                >
                  {!isOwn && (
                    <>
                      {message.sender.profileImageUrl ? (
                        <img
                          src={message.sender.profileImageUrl}
                          alt={message.sender.username || message.sender.email}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                      ) : (
                        getDefaultAvatar(message.sender.username || message.sender.email)
                      )}
                    </>
                  )}
                  
                  <div className={`flex flex-col space-y-1 max-w-xs ${isOwn ? 'items-end' : 'items-start'}`}>
                    <div
                      className={`rounded-2xl px-4 py-2 ${
                        isOwn
                          ? 'chat-bubble-sent text-white rounded-tr-md'
                          : 'chat-bubble-received text-gray-800 rounded-tl-md'
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <div className={`flex items-center space-x-1 px-2 ${isOwn ? 'flex-row-reverse space-x-reverse' : ''}`}>
                      <span className="message-time text-gray-500">
                        {formatMessageTime(message.createdAt!)}
                      </span>
                      {isOwn && (
                        <div className="text-vito-blue text-xs">
                          {message.isRead ? '✓✓' : '✓'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Message Input */}
      <div className="bg-white border-t border-gray-200 px-4 py-3">
        <form onSubmit={handleSendMessage} className="flex items-center space-x-3">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="text-gray-500 hover:text-vito-blue"
          >
            <Plus className="w-5 h-5" />
          </Button>
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Type a message..."
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              className="pr-10 rounded-full border-gray-300 focus:ring-vito-blue focus:border-vito-blue"
              disabled={sendMessageMutation.isPending}
            />
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-vito-blue p-1"
            >
              <Smile className="w-4 h-4" />
            </Button>
          </div>
          <Button
            type="submit"
            size="icon"
            className="bg-vito-blue hover:bg-vito-dark text-white rounded-full"
            disabled={!messageText.trim() || sendMessageMutation.isPending}
          >
            {sendMessageMutation.isPending ? (
              <LoadingSpinner size="sm" className="border-white border-t-transparent" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
