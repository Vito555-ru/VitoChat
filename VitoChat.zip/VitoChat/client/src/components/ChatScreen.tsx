import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MediaPicker } from "./MediaPicker";
import { Card } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  Send, 
  Plus, 
  Camera, 
  Mic, 
  Smile, 
  Paperclip,
  Play,
  Pause,
  Download,
  Eye,
  Check,
  CheckCheck,
  Clock,
  User,
  Bell,
  Search,
  Archive,
  Trash2,
  Shield
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

interface Message {
  id: string;
  text?: string;
  type: "text" | "image" | "video" | "voice" | "document";
  sender: "me" | "other";
  timestamp: Date;
  status?: "sending" | "sent" | "delivered" | "read";
  mediaUrl?: string;
  mediaSize?: { width: number; height: number };
  duration?: number; // for voice messages
  fileName?: string; // for documents
}

interface ChatScreenProps {
  onBack: () => void;
  onCall?: (type: "voice" | "video") => void;
  onViewProfile?: () => void;
  contact: {
    name: string;
    avatar?: string;
    isOnline: boolean;
    lastSeen?: string;
    isGroup?: boolean;
    members?: string[];
    phone?: string;
    about?: string;
    mutualGroups?: number;
  };
}

const sampleMessages: Message[] = [
  {
    id: "1",
    text: "Hey! How are you doing?",
    type: "text",
    sender: "other",
    timestamp: new Date(Date.now() - 3600000),
    status: "read"
  },
  {
    id: "2",
    text: "I'm doing great! Just working on some projects. How about you?",
    type: "text",
    sender: "me",
    timestamp: new Date(Date.now() - 3500000),
    status: "read"
  },
  {
    id: "3",
    type: "image",
    sender: "other",
    timestamp: new Date(Date.now() - 3000000),
    status: "read",
    mediaUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop",
    mediaSize: { width: 400, height: 300 }
  },
  {
    id: "4",
    text: "Beautiful sunset! 😍",
    type: "text",
    sender: "other",
    timestamp: new Date(Date.now() - 2900000),
    status: "read"
  },
  {
    id: "5",
    text: "Wow, that's amazing! Where was this taken?",
    type: "text",
    sender: "me",
    timestamp: new Date(Date.now() - 2800000),
    status: "read"
  },
  {
    id: "6",
    type: "voice",
    sender: "other",
    timestamp: new Date(Date.now() - 1800000),
    status: "delivered",
    duration: 45
  },
  {
    id: "7",
    text: "Let me send you the location details",
    type: "text",
    sender: "me",
    timestamp: new Date(Date.now() - 300000),
    status: "sent"
  },
  {
    id: "8",
    text: "Typing...",
    type: "text",
    sender: "me",
    timestamp: new Date(),
    status: "sending"
  }
];

export function ChatScreen({ onBack, onCall, onViewProfile, contact }: ChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>(sampleMessages.slice(0, -1));
  const [newMessage, setNewMessage] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [showMediaOptions, setShowMediaOptions] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [playingVoice, setPlayingVoice] = useState<string | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);
  const [showMessageInfo, setShowMessageInfo] = useState<Message | null>(null);
  const [showChatWallpaper, setShowChatWallpaper] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [showContextMenu, setShowContextMenu] = useState<{messageId: string, x: number, y: number} | null>(null);
  const [starredMessages, setStarredMessages] = useState<string[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "sending": return <Clock className="w-3 h-3 text-gray-400" />;
      case "sent": return <Check className="w-3 h-3 text-gray-400" />;
      case "delivered": return <CheckCheck className="w-3 h-3 text-gray-400" />;
      case "read": return <CheckCheck className="w-3 h-3 text-blue-500" />;
      default: return null;
    }
  };

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;

    const message: Message = {
      id: Date.now().toString(),
      text: newMessage,
      type: "text",
      sender: "me",
      timestamp: new Date(),
      status: "sending"
    };

    setMessages(prev => [...prev, message]);
    setNewMessage("");

    // Simulate message status updates
    setTimeout(() => {
      setMessages(prev => prev.map(msg => 
        msg.id === message.id ? { ...msg, status: "sent" } : msg
      ));
    }, 1000);

    setTimeout(() => {
      setMessages(prev => prev.map(msg => 
        msg.id === message.id ? { ...msg, status: "delivered" } : msg
      ));
    }, 2000);
  };

  const handleFileUpload = (type: "image" | "video" | "document") => {
    const message: Message = {
      id: Date.now().toString(),
      type,
      sender: "me",
      timestamp: new Date(),
      status: "sending",
      mediaUrl: type === "image" ? "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop" : undefined,
      mediaSize: type === "image" ? { width: 400, height: 300 } : undefined,
      fileName: type === "document" ? "document.pdf" : undefined
    };

    setMessages(prev => [...prev, message]);
    setShowMediaOptions(false);
  };

  const toggleVoicePlayback = (messageId: string) => {
    if (playingVoice === messageId) {
      setPlayingVoice(null);
    } else {
      setPlayingVoice(messageId);
    }
  };

  const renderMessage = (message: Message) => {
    const isMe = message.sender === "me";
    
    return (
      <div key={message.id} className={`flex ${isMe ? "justify-end" : "justify-start"} mb-4`}>
        <div className={`max-w-xs lg:max-w-md ${isMe ? "order-2" : "order-1"}`}>
          {!isMe && (
            <div className="flex items-center space-x-2 mb-1">
              <Avatar className="w-6 h-6">
                <AvatarImage src={contact.avatar} />
                <AvatarFallback className="text-xs bg-vito-blue text-white">
                  {contact.name[0]}
                </AvatarFallback>
              </Avatar>
              <span className="text-xs text-gray-500">{contact.name}</span>
            </div>
          )}
          
          <div
            className={`rounded-lg px-3 py-2 ${
              isMe
                ? "bg-vito-blue text-white"
                : "bg-white border border-gray-200"
            }`}
          >
            {message.type === "text" && (
              <p className="text-sm">{message.text}</p>
            )}
            
            {message.type === "image" && (
              <div className="relative">
                <img
                  src={message.mediaUrl}
                  alt="Shared image"
                  className="rounded-lg max-w-full h-auto cursor-pointer"
                  onClick={() => {/* Open media viewer */}}
                />
                <Button
                  size="sm"
                  variant="secondary"
                  className="absolute top-2 right-2 w-8 h-8 p-0 bg-black/50 hover:bg-black/70"
                >
                  <Eye className="w-4 h-4 text-white" />
                </Button>
              </div>
            )}
            
            {message.type === "voice" && (
              <div className="flex items-center space-x-2 min-w-[150px]">
                <Button
                  size="sm"
                  variant="ghost"
                  className={`w-8 h-8 p-0 ${isMe ? "text-white hover:bg-white/20" : "text-gray-600 hover:bg-gray-100"}`}
                  onClick={() => toggleVoicePlayback(message.id)}
                >
                  {playingVoice === message.id ? (
                    <Pause className="w-4 h-4" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                </Button>
                <div className="flex-1">
                  <div className={`h-1 rounded-full ${isMe ? "bg-white/30" : "bg-gray-300"}`}>
                    <div className={`h-1 rounded-full w-1/3 ${isMe ? "bg-white" : "bg-vito-blue"}`}></div>
                  </div>
                </div>
                <span className={`text-xs ${isMe ? "text-white/80" : "text-gray-500"}`}>
                  {message.duration}s
                </span>
              </div>
            )}
            
            {message.type === "document" && (
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Paperclip className="w-5 h-5 text-gray-500" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{message.fileName}</p>
                  <p className="text-xs text-gray-500">PDF • 2.4 MB</p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className={`w-8 h-8 p-0 ${isMe ? "text-white hover:bg-white/20" : "text-gray-600 hover:bg-gray-100"}`}
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            )}
            
            <div className={`flex items-center justify-between mt-1 ${isMe ? "text-white/70" : "text-gray-500"}`}>
              <span className="text-xs">{formatTime(message.timestamp)}</span>
              {isMe && <div className="ml-2">{getStatusIcon(message.status)}</div>}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-vito-blue text-white p-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="text-white hover:bg-white/20 p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <div 
            className="flex items-center space-x-3 flex-1 cursor-pointer hover:bg-white/10 rounded-lg p-2 -m-2"
            onClick={() => setShowProfile(true)}
          >
            <Avatar className="w-10 h-10">
              <AvatarImage src={contact.avatar} />
              <AvatarFallback className="bg-white text-vito-blue">
                {contact.name[0]}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <h3 className="font-semibold">{contact.name}</h3>
              <p className="text-sm text-white/80">
                {contact.isGroup ? `${contact.members?.length} members` : 
                 contact.isOnline ? "online" : `last seen ${contact.lastSeen}`}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-white hover:bg-white/20"
            onClick={() => onCall?.("video")}
          >
            <Video className="w-5 h-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-white hover:bg-white/20"
            onClick={() => onCall?.("voice")}
          >
            <Phone className="w-5 h-5" />
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => setShowProfile(true)}>
                <User className="w-4 h-4 mr-2" />
                View Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Search className="w-4 h-4 mr-2" />
                Search Messages
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Bell className="w-4 h-4 mr-2" />
                Mute Notifications
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Archive className="w-4 h-4 mr-2" />
                Archive Chat
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <Shield className="w-4 h-4 mr-2" />
                Block Contact
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Chat
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Date Separator */}
        <div className="flex justify-center">
          <Badge variant="secondary" className="text-xs">
            Today
          </Badge>
        </div>
        
        {messages.map(renderMessage)}
        <div ref={messagesEndRef} />
      </div>

      {/* Typing Indicator */}
      <div className="px-4 pb-2">
        <div className="flex items-center space-x-2">
          <Avatar className="w-6 h-6">
            <AvatarImage src={contact.avatar} />
            <AvatarFallback className="text-xs bg-vito-blue text-white">
              {contact.name[0]}
            </AvatarFallback>
          </Avatar>
          <div className="bg-white rounded-lg px-3 py-2 border">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Message Input */}
      <div className="bg-white border-t p-4">
        {showMediaOptions && (
          <Card className="mb-4 p-4">
            <div className="grid grid-cols-3 gap-4">
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-20"
                onClick={() => handleFileUpload("image")}
              >
                <Camera className="w-6 h-6 text-blue-500" />
                <span className="text-xs">Photo</span>
              </Button>
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-20"
                onClick={() => handleFileUpload("video")}
              >
                <Video className="w-6 h-6 text-green-500" />
                <span className="text-xs">Video</span>
              </Button>
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-20"
                onClick={() => handleFileUpload("document")}
              >
                <Paperclip className="w-6 h-6 text-purple-500" />
                <span className="text-xs">Document</span>
              </Button>
            </div>
          </Card>
        )}
        
        <div className="flex items-center space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowMediaPicker(true)}
            className="text-gray-500 hover:bg-gray-100"
          >
            <Plus className="w-5 h-5" />
          </Button>
          
          <div className="flex-1 relative">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="pr-20"
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            />
            <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
              <Button variant="ghost" size="sm" className="w-8 h-8 p-0 text-gray-500">
                <Smile className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-8 h-8 p-0 text-gray-500"
                onClick={() => setShowMediaPicker(true)}
              >
                <Paperclip className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {newMessage.trim() ? (
            <Button
              onClick={handleSendMessage}
              className="bg-vito-blue hover:bg-vito-blue/90"
            >
              <Send className="w-5 h-5" />
            </Button>
          ) : (
            <Button
              onMouseDown={() => setIsRecording(true)}
              onMouseUp={() => setIsRecording(false)}
              onMouseLeave={() => setIsRecording(false)}
              className={`${isRecording ? "bg-red-500 hover:bg-red-600" : "bg-vito-blue hover:bg-vito-blue/90"}`}
            >
              <Mic className="w-5 h-5" />
            </Button>
          )}
        </div>
        
        {isRecording && (
          <div className="mt-2 flex items-center justify-center space-x-2 text-red-500">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-sm">Recording...</span>
          </div>
        )}
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept="image/*,video/*,.pdf,.doc,.docx"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) {
            // Handle file upload
          }
        }}
      />

      {/* Contact Profile Dialog */}
      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Contact Info</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Profile Header */}
            <div className="flex flex-col items-center space-y-3">
              <Avatar className="w-24 h-24">
                <AvatarImage src={contact.avatar} />
                <AvatarFallback className="bg-vito-blue text-white text-2xl">
                  {contact.name[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="text-center">
                <h3 className="font-semibold text-lg">{contact.name}</h3>
                <p className="text-sm text-gray-500">
                  {contact.phone || "+1 (555) 123-4567"}
                </p>
                <p className="text-sm text-green-600 mt-1">
                  {contact.isOnline ? "Online" : `Last seen ${contact.lastSeen || "2 hours ago"}`}
                </p>
              </div>
            </div>

            {/* About Section */}
            <div>
              <h4 className="font-medium text-sm text-gray-700 mb-2">About</h4>
              <p className="text-sm text-gray-600">
                {contact.about || "Hey there! I am using VITO."}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-3 gap-4">
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-16"
                onClick={() => {
                  setShowProfile(false);
                  onCall?.("voice");
                }}
              >
                <Phone className="w-5 h-5 text-green-500" />
                <span className="text-xs">Call</span>
              </Button>
              
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-16"
                onClick={() => {
                  setShowProfile(false);
                  onCall?.("video");
                }}
              >
                <Video className="w-5 h-5 text-blue-500" />
                <span className="text-xs">Video</span>
              </Button>
              
              <Button
                variant="outline"
                className="flex flex-col items-center space-y-2 h-16"
              >
                <Search className="w-5 h-5 text-purple-500" />
                <span className="text-xs">Search</span>
              </Button>
            </div>

            {/* Additional Info */}
            {!contact.isGroup && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">Mutual Groups</span>
                  <span className="text-sm text-gray-500">{contact.mutualGroups || 3}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-700">Media Shared</span>
                  <span className="text-sm text-gray-500">47</span>
                </div>
              </div>
            )}

            {/* Settings */}
            <div className="space-y-2 pt-4 border-t">
              <Button variant="ghost" className="w-full justify-start text-sm">
                <Bell className="w-4 h-4 mr-3" />
                Mute Notifications
              </Button>
              
              <Button variant="ghost" className="w-full justify-start text-sm">
                <Archive className="w-4 h-4 mr-3" />
                Archive Chat
              </Button>
              
              <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                <Shield className="w-4 h-4 mr-3" />
                Block Contact
              </Button>
              
              <Button variant="ghost" className="w-full justify-start text-sm text-red-600">
                <Trash2 className="w-4 h-4 mr-3" />
                Delete Chat
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Media Picker */}
      <MediaPicker
        open={showMediaPicker}
        onOpenChange={setShowMediaPicker}
        onSendMedia={(media) => {
          const message: Message = {
            id: Date.now().toString(),
            text: media.caption,
            type: media.type,
            sender: "me",
            timestamp: new Date(),
            status: "sending",
            mediaUrl: media.url,
            duration: media.duration,
            fileName: media.file?.name
          };
          setMessages([...messages, message]);
          
          // Simulate status updates
          setTimeout(() => {
            setMessages(msgs => msgs.map(m => 
              m.id === message.id ? { ...m, status: "sent" } : m
            ));
          }, 500);
        }}
      />
    </div>
  );
}