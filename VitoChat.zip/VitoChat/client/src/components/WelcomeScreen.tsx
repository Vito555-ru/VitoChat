import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import vitoLogoPath from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754892627598.png";

interface WelcomeScreenProps {
  onContinue: () => void;
}

export function WelcomeScreen({ onContinue }: WelcomeScreenProps) {
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center pt-8">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 flex items-center justify-center">
              <img 
                src={vitoLogoPath} 
                alt="VITO Logo" 
                className="w-18 h-18 object-contain drop-shadow-md"
              />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Welcome to VITO</h1>
          <p className="text-gray-600 text-center leading-relaxed">
            Read our Privacy Policy. Tap "Agree and continue" to accept the Terms of Service.
          </p>
        </CardHeader>
        
        <CardContent className="px-6 pb-8">
          <div className="space-y-6">
            <div className="bg-gray-100 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 mb-2">Terms of Service</h3>
              <p className="text-sm text-gray-600 leading-relaxed mb-3">
                By using VITO, you agree to our Terms of Service and Privacy Policy. 
                Your messages are encrypted and secure.
              </p>
              <p className="text-sm text-gray-600 leading-relaxed">
                We collect minimal data to provide you with the best messaging experience. 
                Your privacy is our priority.
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox 
                id="agree-terms" 
                checked={agreedToTerms}
                onCheckedChange={(checked) => setAgreedToTerms(checked === true)}
              />
              <label 
                htmlFor="agree-terms" 
                className="text-sm text-gray-600 leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I agree to the Terms of Service and Privacy Policy
              </label>
            </div>

            <Button 
              onClick={onContinue}
              disabled={!agreedToTerms}
              className="w-full bg-vito-blue hover:bg-vito-dark text-white py-3 text-base"
            >
              Agree and Continue
            </Button>

            <div className="text-center text-xs text-gray-500">
              By Blackhole Networks
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}