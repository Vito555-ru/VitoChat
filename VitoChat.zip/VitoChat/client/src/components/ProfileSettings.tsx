import { useState } from 'react';
import { Camera, Edit3, Eye, EyeOff, Users, Shield, Smartphone, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import type { User } from '@shared/schema';

interface ProfileSettingsProps {
  user: User;
  onUpdateProfile: (updates: Partial<User>) => Promise<void>;
  onChangeNumber: (newNumber: string) => Promise<void>;
  onDeleteAccount: () => Promise<void>;
}

export function ProfileSettings({ user, onUpdateProfile, onChangeNumber, onDeleteAccount }: ProfileSettingsProps) {
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isChangingNumber, setIsChangingNumber] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);
  
  const [profileForm, setProfileForm] = useState({
    firstName: user.firstName || '',
    lastName: user.lastName || '',
    about: user.about || '',
    profileImageUrl: user.profileImageUrl || ''
  });
  
  const [privacySettings, setPrivacySettings] = useState({
    lastSeenPrivacy: user.lastSeenPrivacy || 'everyone',
    profilePhotoPrivacy: user.profilePhotoPrivacy || 'everyone',
    aboutPrivacy: user.aboutPrivacy || 'everyone'
  });
  
  const [newPhoneNumber, setNewPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);

  const handleUpdateProfile = async () => {
    setLoading(true);
    try {
      await onUpdateProfile(profileForm);
      setIsEditingProfile(false);
    } catch (error) {
      console.error('Failed to update profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdatePrivacy = async (setting: string, value: string) => {
    setLoading(true);
    try {
      const updates = { [setting]: value };
      await onUpdateProfile(updates);
      setPrivacySettings(prev => ({ ...prev, [setting]: value }));
    } catch (error) {
      console.error('Failed to update privacy settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChangeNumber = async () => {
    if (!newPhoneNumber.trim()) return;
    
    setLoading(true);
    try {
      await onChangeNumber(newPhoneNumber);
      setIsChangingNumber(false);
      setNewPhoneNumber('');
    } catch (error) {
      console.error('Failed to change number:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    setLoading(true);
    try {
      await onDeleteAccount();
    } catch (error) {
      console.error('Failed to delete account:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-6">
      
      {/* Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Edit3 size={20} />
            Profile
          </CardTitle>
          <CardDescription>
            Update your profile information and photo
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {/* Profile Photo */}
          <div className="flex items-center space-x-4">
            <Avatar className="w-20 h-20">
              <AvatarImage src={user.profileImageUrl || undefined} />
              <AvatarFallback className="text-2xl bg-blue-500 text-white">
                {user.firstName?.[0]}{user.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <Button variant="outline" className="flex items-center gap-2">
              <Camera size={16} />
              Change Photo
            </Button>
          </div>

          {/* Profile Info */}
          {!isEditingProfile ? (
            <div className="space-y-2">
              <div>
                <Label className="text-sm text-gray-500">Name</Label>
                <p className="font-medium">{user.firstName} {user.lastName}</p>
              </div>
              <div>
                <Label className="text-sm text-gray-500">About</Label>
                <p className="text-gray-700 dark:text-gray-300">{user.about || 'No status set'}</p>
              </div>
              <div>
                <Label className="text-sm text-gray-500">Phone</Label>
                <p className="font-mono">{user.phoneNumber}</p>
              </div>
              <Button onClick={() => setIsEditingProfile(true)} className="mt-2">
                Edit Profile
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={profileForm.firstName}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, firstName: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={profileForm.lastName}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, lastName: e.target.value }))}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="about">About</Label>
                <Textarea
                  id="about"
                  value={profileForm.about}
                  onChange={(e) => setProfileForm(prev => ({ ...prev, about: e.target.value }))}
                  placeholder="Tell people about yourself..."
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleUpdateProfile} disabled={loading}>
                  {loading ? 'Saving...' : 'Save Changes'}
                </Button>
                <Button variant="outline" onClick={() => setIsEditingProfile(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Privacy Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield size={20} />
            Privacy
          </CardTitle>
          <CardDescription>
            Control who can see your information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {/* Last Seen Privacy */}
          <div className="flex items-center justify-between">
            <div>
              <Label>Last Seen</Label>
              <p className="text-sm text-gray-500">Control who can see when you were last online</p>
            </div>
            <Select
              value={privacySettings.lastSeenPrivacy}
              onValueChange={(value) => handleUpdatePrivacy('lastSeenPrivacy', value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="everyone">Everyone</SelectItem>
                <SelectItem value="contacts">My Contacts</SelectItem>
                <SelectItem value="nobody">Nobody</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Profile Photo Privacy */}
          <div className="flex items-center justify-between">
            <div>
              <Label>Profile Photo</Label>
              <p className="text-sm text-gray-500">Control who can see your profile photo</p>
            </div>
            <Select
              value={privacySettings.profilePhotoPrivacy}
              onValueChange={(value) => handleUpdatePrivacy('profilePhotoPrivacy', value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="everyone">Everyone</SelectItem>
                <SelectItem value="contacts">My Contacts</SelectItem>
                <SelectItem value="nobody">Nobody</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* About Privacy */}
          <div className="flex items-center justify-between">
            <div>
              <Label>About</Label>
              <p className="text-sm text-gray-500">Control who can see your about information</p>
            </div>
            <Select
              value={privacySettings.aboutPrivacy}
              onValueChange={(value) => handleUpdatePrivacy('aboutPrivacy', value)}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="everyone">Everyone</SelectItem>
                <SelectItem value="contacts">My Contacts</SelectItem>
                <SelectItem value="nobody">Nobody</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Account Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone size={20} />
            Account
          </CardTitle>
          <CardDescription>
            Manage your account settings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {/* Change Number */}
          <div className="flex items-center justify-between">
            <div>
              <Label>Phone Number</Label>
              <p className="text-sm text-gray-500">Change your phone number</p>
            </div>
            <Button variant="outline" onClick={() => setIsChangingNumber(true)}>
              Change Number
            </Button>
          </div>

          <Separator />

          {/* Delete Account */}
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-red-600 dark:text-red-400">Delete Account</Label>
              <p className="text-sm text-gray-500">Permanently delete your account and all data</p>
            </div>
            <Button variant="destructive" onClick={() => setIsDeletingAccount(true)}>
              <Trash2 size={16} className="mr-2" />
              Delete
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Change Number Dialog */}
      <Dialog open={isChangingNumber} onOpenChange={setIsChangingNumber}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Phone Number</DialogTitle>
            <DialogDescription>
              Enter your new phone number. You'll receive an OTP for verification.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="newPhone">New Phone Number</Label>
              <Input
                id="newPhone"
                type="tel"
                value={newPhoneNumber}
                onChange={(e) => setNewPhoneNumber(e.target.value)}
                placeholder="+1 (555) 123-4567"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsChangingNumber(false)}>
              Cancel
            </Button>
            <Button onClick={handleChangeNumber} disabled={loading || !newPhoneNumber.trim()}>
              {loading ? 'Sending OTP...' : 'Verify Number'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={isDeletingAccount} onOpenChange={setIsDeletingAccount}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-600">Delete Account</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete your account and remove all your data from our servers.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeletingAccount(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={loading}>
              {loading ? 'Deleting...' : 'Delete Account'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}