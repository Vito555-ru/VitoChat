import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, Users, UserPlus, Phone, MessageCircle, Video } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface User {
  id: string;
  firstName: string;
  lastName?: string;
  phoneNumber: string;
  profileImage?: string;
  isOnline: boolean;
  lastSeen?: Date;
  isContact: boolean;
}

interface NewChatDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStartChat: (user: User) => void;
}

export function NewChatDialog({ open, onOpenChange, onStartChat }: NewChatDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"contacts" | "users">("contacts");

  // Fetch contacts (users in phone contacts who use the app)
  const { data: contacts = [], isLoading: contactsLoading } = useQuery({
    queryKey: ["/api/contacts"],
    enabled: open && activeTab === "contacts",
  });

  // Search all app users
  const { data: searchResults = [], isLoading: searchLoading } = useQuery({
    queryKey: ["/api/users/search", { q: searchQuery }],
    enabled: open && activeTab === "users" && searchQuery.length >= 2,
  });

  const handleUserSelect = (user: User) => {
    onStartChat(user);
    onOpenChange(false);
    setSearchQuery("");
  };

  const formatLastSeen = (lastSeen?: Date) => {
    if (!lastSeen) return "Unknown";
    
    const now = new Date();
    const diff = now.getTime() - lastSeen.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return lastSeen.toLocaleDateString();
  };

  const renderUserList = (users: User[]) => {
    if (users.length === 0) {
      return (
        <div className="text-center py-8">
          <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">
            {activeTab === "contacts" 
              ? "No contacts found using VIOT" 
              : searchQuery.length < 2 
                ? "Type at least 2 characters to search"
                : "No users found"
            }
          </p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {users.map((user) => (
          <div
            key={user.id}
            className="flex items-center space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer group"
            onClick={() => handleUserSelect(user)}
          >
            <div className="relative">
              <Avatar className="w-12 h-12">
                <AvatarImage src={user.profileImage} />
                <AvatarFallback className="bg-vito-blue text-white">
                  {user.firstName[0]}{user.lastName?.[0] || ""}
                </AvatarFallback>
              </Avatar>
              {user.isOnline && (
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <h3 className="font-medium text-gray-900 truncate">
                  {user.firstName} {user.lastName}
                </h3>
                {user.isContact && (
                  <Badge variant="secondary" className="text-xs">Contact</Badge>
                )}
              </div>
              <p className="text-sm text-gray-600 truncate">{user.phoneNumber}</p>
              <p className="text-xs text-gray-500">
                {user.isOnline ? "Online" : `Last seen ${formatLastSeen(user.lastSeen)}`}
              </p>
            </div>

            <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button size="sm" variant="ghost" className="p-2">
                <MessageCircle className="w-4 h-4 text-green-500" />
              </Button>
              <Button size="sm" variant="ghost" className="p-2">
                <Phone className="w-4 h-4 text-blue-500" />
              </Button>
              <Button size="sm" variant="ghost" className="p-2">
                <Video className="w-4 h-4 text-purple-500" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[80vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>New Chat</DialogTitle>
        </DialogHeader>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-200 px-6">
          <button
            className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "contacts"
                ? "border-vito-blue text-vito-blue"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("contacts")}
          >
            <div className="flex items-center justify-center space-x-2">
              <Users className="w-4 h-4" />
              <span>Contacts</span>
            </div>
          </button>
          <button
            className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "users"
                ? "border-vito-blue text-vito-blue"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
            onClick={() => setActiveTab("users")}
          >
            <div className="flex items-center justify-center space-x-2">
              <UserPlus className="w-4 h-4" />
              <span>Find Users</span>
            </div>
          </button>
        </div>

        <div className="p-6 pt-4">
          {/* Search Input */}
          {activeTab === "users" && (
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by name, phone, or username..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          )}

          {/* User List */}
          <div className="max-h-96 overflow-y-auto">
            {activeTab === "contacts" ? (
              contactsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-vito-blue"></div>
                </div>
              ) : (
                renderUserList(contacts)
              )
            ) : (
              searchLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-vito-blue"></div>
                </div>
              ) : (
                renderUserList(searchResults)
              )
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 pt-0 border-t">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Users className="w-4 h-4" />
            <span>
              {activeTab === "contacts" 
                ? `${contacts.length} contacts using VIOT`
                : "Discover people on VIOT"
              }
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}