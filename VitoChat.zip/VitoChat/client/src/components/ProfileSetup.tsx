import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Camera, ChevronLeft, User } from "lucide-react";

interface ProfileSetupProps {
  onComplete: (firstName: string, lastName?: string, profileImage?: string) => void;
  onBack: () => void;
}

export function ProfileSetup({ onComplete, onBack }: ProfileSetupProps) {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [profileImage, setProfileImage] = useState("");

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setProfileImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleComplete = () => {
    if (firstName.trim()) {
      onComplete(firstName.trim(), lastName.trim() || undefined, profileImage || undefined);
    }
  };

  const getInitials = () => {
    const first = firstName.charAt(0).toUpperCase();
    const last = lastName.charAt(0).toUpperCase();
    return first + last;
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center mb-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="p-2">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <CardTitle className="flex-1 text-center">Profile Info</CardTitle>
          </div>
          <p className="text-center text-gray-600">
            Please provide your name and an optional profile photo.
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Avatar className="w-24 h-24">
                <AvatarImage src={profileImage} alt="Profile" />
                <AvatarFallback className="bg-gray-200 text-gray-600 text-xl">
                  {getInitials() || <User className="w-8 h-8" />}
                </AvatarFallback>
              </Avatar>
              <label 
                htmlFor="profile-image" 
                className="absolute -bottom-2 -right-2 w-8 h-8 bg-vito-blue rounded-full flex items-center justify-center cursor-pointer hover:bg-vito-dark transition-colors"
              >
                <Camera className="w-4 h-4 text-white" />
                <input
                  id="profile-image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>
            <p className="text-sm text-gray-500 text-center">
              Tap to add a profile photo
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                First Name *
              </label>
              <Input
                type="text"
                placeholder="Enter your first name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                className="w-full"
                maxLength={50}
              />
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Last Name (Optional)
              </label>
              <Input
                type="text"
                placeholder="Enter your last name"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                className="w-full"
                maxLength={50}
              />
            </div>
          </div>

          <Button 
            onClick={handleComplete}
            disabled={!firstName.trim()}
            className="w-full bg-vito-blue hover:bg-vito-dark text-white py-3"
          >
            Continue
          </Button>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <p className="text-sm text-blue-800 leading-relaxed">
              This is not your username or PIN. This name will be visible to your VITO contacts.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}