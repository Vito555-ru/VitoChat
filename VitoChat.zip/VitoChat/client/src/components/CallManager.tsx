import { useCallManager } from '@/hooks/useCallManager';
import { CallInterface } from './CallInterface';
import { IncomingCall } from './IncomingCall';

interface CallManagerProps {
  userId: string;
}

export function CallManager({ userId }: CallManagerProps) {
  const { 
    activeCall, 
    incomingCall, 
    callState,
    actions 
  } = useCallManager(userId);

  return (
    <>
      {/* Incoming Call Overlay */}
      {incomingCall && (
        <IncomingCall
          call={incomingCall}
          onAnswer={actions.answerCall}
          onDecline={actions.declineCall}
        />
      )}

      {/* Active Call Interface */}
      {activeCall && (
        <CallInterface
          call={activeCall}
          onEndCall={actions.endCall}
          onToggleMute={actions.toggleMute}
          onToggleVideo={actions.toggleVideo}
          onToggleSpeaker={actions.toggleSpeaker}
          isMuted={callState.isMuted}
          isVideoEnabled={callState.isVideoEnabled}
          isSpeakerOn={callState.isSpeakerOn}
        />
      )}
    </>
  );
}