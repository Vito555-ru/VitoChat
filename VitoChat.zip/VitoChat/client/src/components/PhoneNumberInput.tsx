import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ChevronLeft, Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface PhoneNumberInputProps {
  onContinue: (phoneNumber: string, countryCode: string) => void;
  onBack: () => void;
}

const countryCodes = [
  // North America
  { code: "+1", country: "United States", flag: "🇺🇸" },
  
  // Europe
  { code: "+44", country: "United Kingdom", flag: "🇬🇧" },
  { code: "+49", country: "Germany", flag: "🇩🇪" },
  { code: "+33", country: "France", flag: "🇫🇷" },
  { code: "+39", country: "Italy", flag: "🇮🇹" },
  { code: "+34", country: "Spain", flag: "🇪🇸" },
  { code: "+31", country: "Netherlands", flag: "🇳🇱" },
  { code: "+41", country: "Switzerland", flag: "🇨🇭" },
  { code: "+46", country: "Sweden", flag: "🇸🇪" },
  { code: "+47", country: "Norway", flag: "🇳🇴" },
  { code: "+45", country: "Denmark", flag: "🇩🇰" },
  
  // Asia
  { code: "+86", country: "China", flag: "🇨🇳" },
  { code: "+91", country: "India", flag: "🇮🇳" },
  { code: "+81", country: "Japan", flag: "🇯🇵" },
  { code: "+82", country: "South Korea", flag: "🇰🇷" },
  { code: "+65", country: "Singapore", flag: "🇸🇬" },
  { code: "+852", country: "Hong Kong", flag: "🇭🇰" },
  { code: "+853", country: "Macau", flag: "🇲🇴" },
  { code: "+886", country: "Taiwan", flag: "🇹🇼" },
  { code: "+60", country: "Malaysia", flag: "🇲🇾" },
  { code: "+66", country: "Thailand", flag: "🇹🇭" },
  { code: "+84", country: "Vietnam", flag: "🇻🇳" },
  { code: "+62", country: "Indonesia", flag: "🇮🇩" },
  { code: "+63", country: "Philippines", flag: "🇵🇭" },
  { code: "+95", country: "Myanmar", flag: "🇲🇲" },
  { code: "+855", country: "Cambodia", flag: "🇰🇭" },
  { code: "+856", country: "Laos", flag: "🇱🇦" },
  { code: "+673", country: "Brunei", flag: "🇧🇳" },
  { code: "+92", country: "Pakistan", flag: "🇵🇰" },
  { code: "+880", country: "Bangladesh", flag: "🇧🇩" },
  { code: "+94", country: "Sri Lanka", flag: "🇱🇰" },
  { code: "+977", country: "Nepal", flag: "🇳🇵" },
  { code: "+975", country: "Bhutan", flag: "🇧🇹" },
  { code: "+960", country: "Maldives", flag: "🇲🇻" },
  { code: "+98", country: "Iran", flag: "🇮🇷" },
  { code: "+93", country: "Afghanistan", flag: "🇦🇫" },
  { code: "+996", country: "Kyrgyzstan", flag: "🇰🇬" },
  { code: "+992", country: "Tajikistan", flag: "🇹🇯" },
  { code: "+993", country: "Turkmenistan", flag: "🇹🇲" },
  { code: "+998", country: "Uzbekistan", flag: "🇺🇿" },
  { code: "+7", country: "Kazakhstan", flag: "🇰🇿" },
  
  // Middle East
  { code: "+971", country: "UAE", flag: "🇦🇪" },
  { code: "+966", country: "Saudi Arabia", flag: "🇸🇦" },
  { code: "+974", country: "Qatar", flag: "🇶🇦" },
  { code: "+965", country: "Kuwait", flag: "🇰🇼" },
  { code: "+973", country: "Bahrain", flag: "🇧🇭" },
  { code: "+968", country: "Oman", flag: "🇴🇲" },
  { code: "+967", country: "Yemen", flag: "🇾🇪" },
  { code: "+964", country: "Iraq", flag: "🇮🇶" },
  { code: "+962", country: "Jordan", flag: "🇯🇴" },
  { code: "+961", country: "Lebanon", flag: "🇱🇧" },
  { code: "+963", country: "Syria", flag: "🇸🇾" },
  { code: "+972", country: "Israel", flag: "🇮🇱" },
  { code: "+970", country: "Palestine", flag: "🇵🇸" },
  { code: "+90", country: "Turkey", flag: "🇹🇷" },
  
  // Oceania
  { code: "+61", country: "Australia", flag: "🇦🇺" },
  { code: "+64", country: "New Zealand", flag: "🇳🇿" },
  { code: "+679", country: "Fiji", flag: "🇫🇯" },
  
  // Africa
  { code: "+27", country: "South Africa", flag: "🇿🇦" },
  { code: "+234", country: "Nigeria", flag: "🇳🇬" },
  { code: "+20", country: "Egypt", flag: "🇪🇬" },
  { code: "+212", country: "Morocco", flag: "🇲🇦" },
  { code: "+216", country: "Tunisia", flag: "🇹🇳" },
  { code: "+213", country: "Algeria", flag: "🇩🇿" },
  { code: "+218", country: "Libya", flag: "🇱🇾" },
  { code: "+251", country: "Ethiopia", flag: "🇪🇹" },
  { code: "+254", country: "Kenya", flag: "🇰🇪" },
  { code: "+256", country: "Uganda", flag: "🇺🇬" },
  { code: "+255", country: "Tanzania", flag: "🇹🇿" },
  
  // South America
  { code: "+55", country: "Brazil", flag: "🇧🇷" },
  { code: "+54", country: "Argentina", flag: "🇦🇷" },
  { code: "+56", country: "Chile", flag: "🇨🇱" },
  { code: "+57", country: "Colombia", flag: "🇨🇴" },
  { code: "+51", country: "Peru", flag: "🇵🇪" },
  { code: "+58", country: "Venezuela", flag: "🇻🇪" },
  { code: "+593", country: "Ecuador", flag: "🇪🇨" },
  { code: "+595", country: "Paraguay", flag: "🇵🇾" },
  { code: "+598", country: "Uruguay", flag: "🇺🇾" },
  { code: "+591", country: "Bolivia", flag: "🇧🇴" },
  { code: "+592", country: "Guyana", flag: "🇬🇾" },
  { code: "+597", country: "Suriname", flag: "🇸🇷" },
  
  // Russia & CIS
  { code: "+7", country: "Russia", flag: "🇷🇺" },
  { code: "+375", country: "Belarus", flag: "🇧🇾" },
  { code: "+380", country: "Ukraine", flag: "🇺🇦" },
  { code: "+374", country: "Armenia", flag: "🇦🇲" },
  { code: "+995", country: "Georgia", flag: "🇬🇪" },
  { code: "+994", country: "Azerbaijan", flag: "🇦🇿" },
  { code: "+373", country: "Moldova", flag: "🇲🇩" },
];

export function PhoneNumberInput({ onContinue, onBack }: PhoneNumberInputProps) {
  const [countryCode, setCountryCode] = useState("+1");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);
  const [open, setOpen] = useState(false);

  const handleContinue = () => {
    if (phoneNumber.length >= 10) {
      setShowConfirm(true);
    }
  };

  const handleConfirm = () => {
    onContinue(phoneNumber, countryCode);
  };

  if (showConfirm) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center">Confirm Your Number</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <p className="text-gray-600 mb-4">
                We will send an SMS with a verification code to:
              </p>
              <p className="text-lg font-semibold text-gray-900">
                {countryCode} {phoneNumber}
              </p>
            </div>
            
            <div className="flex space-x-3">
              <Button 
                variant="outline" 
                onClick={() => setShowConfirm(false)}
                className="flex-1"
              >
                Edit
              </Button>
              <Button 
                onClick={handleConfirm}
                className="flex-1 bg-vito-blue hover:bg-vito-dark text-white"
              >
                Yes, it's correct
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center mb-4">
            <Button variant="ghost" size="sm" onClick={onBack} className="p-2">
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <CardTitle className="flex-1 text-center">Enter Your Phone Number</CardTitle>
          </div>
          <p className="text-center text-gray-600">
            VITO will need to verify your phone number. What's your number?
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Country
              </label>
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={open}
                    className="w-full justify-between h-10"
                  >
                    {countryCode ? (
                      <div className="flex items-center space-x-2">
                        <span>{countryCodes.find(c => c.code === countryCode)?.flag}</span>
                        <span className="truncate">
                          {countryCodes.find(c => c.code === countryCode)?.country}
                        </span>
                        <span className="text-gray-500 text-sm">({countryCode})</span>
                      </div>
                    ) : (
                      "Select country..."
                    )}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Search countries (e.g., type 'P' for Pakistan)..." />
                    <CommandEmpty>No country found.</CommandEmpty>
                    <CommandList className="max-h-60">
                      <CommandGroup>
                        {countryCodes.map((country, index) => (
                          <CommandItem
                            key={`${country.code}-${index}`}
                            value={`${country.country} ${country.code}`}
                            onSelect={() => {
                              setCountryCode(country.code);
                              setOpen(false);
                            }}
                          >
                            <div className="flex items-center space-x-2 w-full">
                              <span className="text-lg">{country.flag}</span>
                              <span className="flex-1 truncate">{country.country}</span>
                              <span className="text-gray-500 text-sm">{country.code}</span>
                              <Check
                                className={cn(
                                  "ml-auto h-4 w-4",
                                  countryCode === country.code ? "opacity-100" : "opacity-0"
                                )}
                              />
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                Phone Number
              </label>
              <div className="flex space-x-2">
                <div className="w-20">
                  <Input 
                    value={countryCode} 
                    readOnly 
                    className="bg-gray-100 text-center"
                  />
                </div>
                <Input
                  type="tel"
                  placeholder="Phone number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  className="flex-1"
                  maxLength={15}
                />
              </div>
            </div>
          </div>

          <Button 
            onClick={handleContinue}
            disabled={phoneNumber.length < 10}
            className="w-full bg-vito-blue hover:bg-vito-dark text-white py-3"
          >
            Continue
          </Button>

          <p className="text-xs text-gray-500 text-center leading-relaxed">
            You may receive SMS notifications from us for security and login purposes.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}