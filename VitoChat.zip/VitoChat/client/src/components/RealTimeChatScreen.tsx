import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical,
  Send,
  Mic,
  Camera,
  Paperclip,
  Smile,
  Check,
  CheckCheck
} from 'lucide-react';
import { useMessages } from '@/hooks/useMessages';
import { useWebSocket } from '@/hooks/useWebSocket';
import type { ChatWithUsers, MessageWithSender, User } from '@shared/schema';
import { formatDistanceToNow } from 'date-fns';

interface RealTimeChatScreenProps {
  chat: ChatWithUsers;
  currentUser: User;
  onBack: () => void;
  onVoiceCall: () => void;
  onVideoCall: () => void;
}

export function RealTimeChatScreen({ 
  chat, 
  currentUser, 
  onBack, 
  onVoiceCall, 
  onVideoCall 
}: RealTimeChatScreenProps) {
  const [messageText, setMessageText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    messages,
    isLoading,
    isConnected,
    isAuthenticated,
    typingUsers,
    sendMessage,
    isSendingMessage,
    startTyping,
    stopTyping,
  } = useMessages({
    chatId: chat.id,
    userId: currentUser.id,
  });

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    inputRef.current?.focus();
  }, [chat.id]);

  const handleSendMessage = () => {
    if (!messageText.trim() || isSendingMessage) return;

    sendMessage({
      chatId: chat.id,
      content: messageText.trim(),
      type: 'text',
    });

    setMessageText('');
    stopTyping();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageText(e.target.value);
    
    // Send typing indicator
    if (e.target.value.trim()) {
      startTyping();
    } else {
      stopTyping();
    }
  };

  const getMessageStatus = (message: MessageWithSender) => {
    if (message.senderId !== currentUser.id) return null;
    
    switch (message.status) {
      case 'sent':
        return <Check className="w-4 h-4 text-gray-400" />;
      case 'delivered':
        return <CheckCheck className="w-4 h-4 text-gray-400" />;
      case 'read':
        return <CheckCheck className="w-4 h-4 text-blue-500" />;
      default:
        return null;
    }
  };

  const formatMessageTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b flex items-center justify-between p-4">
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          
          <Avatar className="w-10 h-10">
            <AvatarImage src={chat.otherUser.profileImageUrl || ''} />
            <AvatarFallback>
              {chat.otherUser.firstName?.[0] || '?'}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900">
              {chat.otherUser.firstName} {chat.otherUser.lastName}
            </h3>
            <div className="flex items-center space-x-2">
              {isConnected ? (
                <>
                  {chat.isOnline ? (
                    <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                      Online
                    </Badge>
                  ) : (
                    <span className="text-xs text-gray-500">
                      Last seen {formatDistanceToNow(new Date(chat.otherUser.lastSeen || Date.now()))} ago
                    </span>
                  )}
                  {typingUsers.length > 0 && (
                    <span className="text-xs text-blue-500 animate-pulse">
                      typing...
                    </span>
                  )}
                </>
              ) : (
                <Badge variant="destructive" className="text-xs">
                  Connecting...
                </Badge>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={onVoiceCall}>
            <Phone className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="sm" onClick={onVideoCall}>
            <Video className="w-5 h-5" />
          </Button>
          <Button variant="ghost" size="sm">
            <MoreVertical className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Connection Status */}
      {!isConnected && (
        <div className="bg-yellow-50 border-b px-4 py-2">
          <p className="text-xs text-yellow-700 text-center">
            Connecting to real-time server...
          </p>
        </div>
      )}

      {!isAuthenticated && isConnected && (
        <div className="bg-orange-50 border-b px-4 py-2">
          <p className="text-xs text-orange-700 text-center">
            Authenticating...
          </p>
        </div>
      )}

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-gray-500">Loading messages...</div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    message.senderId === currentUser.id
                      ? 'bg-blue-500 text-white'
                      : 'bg-white text-gray-900 border'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <div className="flex items-center justify-end mt-1 space-x-1">
                    <span className="text-xs opacity-75">
                      {formatMessageTime(message.createdAt)}
                    </span>
                    {getMessageStatus(message)}
                  </div>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </ScrollArea>

      {/* Message Input */}
      <div className="bg-white border-t p-4">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm">
            <Paperclip className="w-5 h-5" />
          </Button>

          <div className="flex-1 flex items-center space-x-2">
            <Input
              ref={inputRef}
              value={messageText}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="flex-1"
              disabled={!isAuthenticated}
            />
            
            <Button variant="ghost" size="sm">
              <Smile className="w-5 h-5" />
            </Button>
          </div>

          {messageText.trim() ? (
            <Button 
              onClick={handleSendMessage}
              disabled={isSendingMessage || !isAuthenticated}
              className="bg-blue-500 hover:bg-blue-600 text-white"
              size="sm"
            >
              <Send className="w-4 h-4" />
            </Button>
          ) : (
            <Button 
              variant="ghost" 
              size="sm"
              onMouseDown={() => setIsRecording(true)}
              onMouseUp={() => setIsRecording(false)}
              className={isRecording ? 'bg-red-100' : ''}
            >
              <Mic className={`w-5 h-5 ${isRecording ? 'text-red-500' : ''}`} />
            </Button>
          )}

          <Button variant="ghost" size="sm">
            <Camera className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}