import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  X, 
  ArrowLeft, 
  ArrowRight, 
  Download, 
  Share, 
  MoreVertical,
  Play,
  Pause,
  Volume2,
  VolumeX,
  RotateCcw,
  ZoomIn,
  ZoomOut
} from "lucide-react";

interface MediaItem {
  id: string;
  type: "image" | "video";
  url: string;
  caption?: string;
  sender: {
    name: string;
    avatar?: string;
  };
  timestamp: Date;
}

interface MediaViewerProps {
  mediaItems: MediaItem[];
  currentIndex: number;
  onClose: () => void;
  onIndexChange: (index: number) => void;
}

export function MediaViewer({ mediaItems, currentIndex, onClose, onIndexChange }: MediaViewerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [showControls, setShowControls] = useState(true);

  const currentMedia = mediaItems[currentIndex];

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (showControls) {
      timeout = setTimeout(() => setShowControls(false), 3000);
    }
    return () => clearTimeout(timeout);
  }, [showControls]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case "Escape":
          onClose();
          break;
        case "ArrowLeft":
          handlePrevious();
          break;
        case "ArrowRight":
          handleNext();
          break;
        case " ":
          e.preventDefault();
          if (currentMedia.type === "video") {
            setIsPlaying(!isPlaying);
          }
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentIndex, isPlaying]);

  const handlePrevious = () => {
    if (currentIndex > 0) {
      onIndexChange(currentIndex - 1);
      setZoom(1);
      setRotation(0);
    }
  };

  const handleNext = () => {
    if (currentIndex < mediaItems.length - 1) {
      onIndexChange(currentIndex + 1);
      setZoom(1);
      setRotation(0);
    }
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.25, 3));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.25, 0.5));
  };

  const handleRotate = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleDateString([], { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Header */}
      <div 
        className={`absolute top-0 left-0 right-0 z-10 bg-black/50 text-white p-4 transition-opacity duration-300 ${
          showControls ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClose}
              className="text-white hover:bg-white/20"
            >
              <X className="w-5 h-5" />
            </Button>
            
            <Avatar className="w-8 h-8">
              <AvatarImage src={currentMedia.sender.avatar} />
              <AvatarFallback className="bg-white text-black text-sm">
                {currentMedia.sender.name[0]}
              </AvatarFallback>
            </Avatar>
            
            <div>
              <p className="font-medium">{currentMedia.sender.name}</p>
              <p className="text-sm text-white/80">{formatTime(currentMedia.timestamp)}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
              <Share className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
              <Download className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Media Content */}
      <div 
        className="flex-1 flex items-center justify-center relative"
        onClick={() => setShowControls(!showControls)}
      >
        {currentMedia.type === "image" ? (
          <img
            src={currentMedia.url}
            alt="Media content"
            className="max-w-full max-h-full object-contain transition-transform duration-200"
            style={{
              transform: `scale(${zoom}) rotate(${rotation}deg)`,
              cursor: zoom > 1 ? "grab" : "zoom-in"
            }}
          />
        ) : (
          <video
            src={currentMedia.url}
            className="max-w-full max-h-full object-contain"
            controls={false}
            autoPlay={isPlaying}
            muted={isMuted}
            onClick={(e) => {
              e.stopPropagation();
              setIsPlaying(!isPlaying);
            }}
          />
        )}

        {/* Navigation Arrows */}
        {mediaItems.length > 1 && (
          <>
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handlePrevious();
              }}
              disabled={currentIndex === 0}
              className={`absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:bg-white/20 transition-opacity duration-300 ${
                showControls ? "opacity-100" : "opacity-0"
              }`}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleNext();
              }}
              disabled={currentIndex === mediaItems.length - 1}
              className={`absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:bg-white/20 transition-opacity duration-300 ${
                showControls ? "opacity-100" : "opacity-0"
              }`}
            >
              <ArrowRight className="w-6 h-6" />
            </Button>
          </>
        )}

        {/* Video Controls */}
        {currentMedia.type === "video" && (
          <div 
            className={`absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/70 rounded-lg p-2 flex items-center space-x-2 transition-opacity duration-300 ${
              showControls ? "opacity-100" : "opacity-0"
            }`}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                setIsPlaying(!isPlaying);
              }}
              className="text-white hover:bg-white/20"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                setIsMuted(!isMuted);
              }}
              className="text-white hover:bg-white/20"
            >
              {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </Button>
          </div>
        )}

        {/* Image Controls */}
        {currentMedia.type === "image" && (
          <div 
            className={`absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/70 rounded-lg p-2 flex items-center space-x-2 transition-opacity duration-300 ${
              showControls ? "opacity-100" : "opacity-0"
            }`}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleZoomOut();
              }}
              disabled={zoom <= 0.5}
              className="text-white hover:bg-white/20"
            >
              <ZoomOut className="w-5 h-5" />
            </Button>
            
            <span className="text-white text-sm px-2">{Math.round(zoom * 100)}%</span>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleZoomIn();
              }}
              disabled={zoom >= 3}
              className="text-white hover:bg-white/20"
            >
              <ZoomIn className="w-5 h-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                handleRotate();
              }}
              className="text-white hover:bg-white/20"
            >
              <RotateCcw className="w-5 h-5" />
            </Button>
          </div>
        )}
      </div>

      {/* Bottom Info */}
      {currentMedia.caption && (
        <div 
          className={`absolute bottom-0 left-0 right-0 bg-black/50 text-white p-4 transition-opacity duration-300 ${
            showControls ? "opacity-100" : "opacity-0"
          }`}
        >
          <p className="text-center">{currentMedia.caption}</p>
        </div>
      )}

      {/* Media Counter */}
      {mediaItems.length > 1 && (
        <div 
          className={`absolute top-20 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm transition-opacity duration-300 ${
            showControls ? "opacity-100" : "opacity-0"
          }`}
        >
          {currentIndex + 1} of {mediaItems.length}
        </div>
      )}

      {/* Thumbnail Strip */}
      {mediaItems.length > 1 && mediaItems.length <= 10 && (
        <div 
          className={`absolute bottom-20 left-1/2 transform -translate-x-1/2 flex space-x-2 transition-opacity duration-300 ${
            showControls ? "opacity-100" : "opacity-0"
          }`}
        >
          {mediaItems.map((item, index) => (
            <button
              key={item.id}
              onClick={(e) => {
                e.stopPropagation();
                onIndexChange(index);
              }}
              className={`w-12 h-12 rounded overflow-hidden border-2 transition-all duration-200 ${
                index === currentIndex 
                  ? "border-white scale-110" 
                  : "border-transparent opacity-70 hover:opacity-100"
              }`}
            >
              {item.type === "image" ? (
                <img
                  src={item.url}
                  alt={`Thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                  <Play className="w-4 h-4 text-white" />
                </div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}