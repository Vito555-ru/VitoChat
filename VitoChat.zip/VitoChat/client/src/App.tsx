import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { MainTabs } from "@/components/MainTabs";
import NotFound from "@/pages/not-found";
import OnboardingFlow from "@/components/OnboardingFlowFixed";
import { SplashScreen } from "@/components/SplashScreen";
import vitoLogoUrl from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754902665155.png";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: async ({ queryKey }) => {
        const response = await fetch(queryKey[0] as string);
        if (!response.ok) {
          throw new Error(`${response.status}: ${response.statusText}`);
        }
        return response.json();
      },
    },
  },
});

function AuthenticatedApp() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSplash, setShowSplash] = useState(true);
  const [onboardingStep, setOnboardingStep] = useState<'welcome' | 'terms' | 'phone' | 'otp' | 'permissions' | 'profile' | 'complete'>('welcome');

  useEffect(() => {
    // Always show splash screen first for 2 seconds
    const splashTimer = setTimeout(() => {
      setShowSplash(false);
      checkAuthStatus();
    }, 2000);

    // Listen for storage changes to handle logout from other tabs
    const handleStorageChange = (e: StorageEvent) => {
      if ((e.key === 'auth_token' && !e.newValue) || (e.key === 'hasCompletedOnboarding' && !e.newValue)) {
        setUser(null);
        setOnboardingStep('welcome');
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => {
      clearTimeout(splashTimer);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const checkAuthStatus = async () => {
    try {
      // Use consistent token key 'auth_token' 
      const authToken = localStorage.getItem('auth_token');
      const hasCompletedOnboarding = localStorage.getItem('hasCompletedOnboarding');
      
      if (!authToken) {
        // No auth token - check if user has completed onboarding before
        if (hasCompletedOnboarding) {
          // User logged out but has account - go to login screen (skip onboarding)
          setOnboardingStep('phone');
        } else {
          // New user or account deleted - start from beginning
          setOnboardingStep('welcome');
        }
        setIsLoading(false);
        return;
      }

      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        setOnboardingStep('complete');
      } else {
        // Invalid token - clear it but preserve onboarding status for logout vs deletion
        localStorage.removeItem('auth_token');
        setUser(null);
        
        if (hasCompletedOnboarding) {
          // User was logged out - go to login screen
          setOnboardingStep('phone');
        } else {
          // Account may have been deleted - start from beginning  
          setOnboardingStep('welcome');
        }
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      // Clear auth token on error
      localStorage.removeItem('auth_token');
      setUser(null);
      
      // Check if user had completed onboarding to determine next step
      const hasCompletedOnboarding = localStorage.getItem('hasCompletedOnboarding');
      setOnboardingStep(hasCompletedOnboarding ? 'phone' : 'welcome');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      // Clear all local state and restart with splash screen
      localStorage.removeItem('auth_token');
      localStorage.removeItem('hasCompletedOnboarding');
      setUser(null);
      setOnboardingStep('welcome');
      setShowSplash(true);
      
      // Restart the full flow after logout
      setTimeout(() => {
        setShowSplash(false);
      }, 2000);
      
      // Call logout endpoint to clean up server-side if needed
      await fetch('/api/auth/logout', {
        method: 'POST'
      });
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const handleOnboardingNext = (nextStep: typeof onboardingStep) => {
    setOnboardingStep(nextStep);
  };

  const handleAuthSuccess = (userData: any) => {
    // Mark onboarding as completed
    localStorage.setItem('hasCompletedOnboarding', 'true');
    setUser(userData);
    setOnboardingStep('complete');
  };

  // Always show splash screen first
  if (showSplash) {
    return <SplashScreen />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-8 h-8 mx-auto mb-2 border-4 border-green-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <Switch>
        {onboardingStep === 'complete' && user ? (
          <Route path="/">
            {() => <MainTabs user={user} onLogout={handleLogout} />}
          </Route>
        ) : (
          <Route path="/">
            {() => (
              <OnboardingFlow 
                currentStep={onboardingStep}
                onNext={handleOnboardingNext}
                onAuthSuccess={handleAuthSuccess}
              />
            )}
          </Route>
        )}
        <Route component={NotFound} />
      </Switch>
      <Toaster />
    </TooltipProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthenticatedApp />
    </QueryClientProvider>
  );
}

export default App;
