import { useState, useEffect, useCallback, useRef } from 'react';
import type { WebSocketEvent, MessageWithSender, CallWithUsers } from '@shared/schema';

interface UseWebSocketOptions {
  userId?: string;
  onMessage?: (message: MessageWithSender) => void;
  onCallIncoming?: (call: CallWithUsers) => void;
  onUserOnline?: (userId: string) => void;
  onUserOffline?: (userId: string) => void;
  onTypingStart?: (chatId: string, userId: string) => void;
  onTypingStop?: (chatId: string, userId: string) => void;
  onMessageRead?: (messageId: string, userId: string) => void;
  onCallAnswered?: (callId: string) => void;
  onCallDeclined?: (callId: string) => void;
  onCallEnded?: (callId: string) => void;
  onAccountDeleted?: (userId: string) => void;
}

interface WebSocketState {
  isConnected: boolean;
  isAuthenticated: boolean;
  isReconnecting: boolean;
  lastError?: string;
}

export function useWebSocket(options: UseWebSocketOptions) {
  const [state, setState] = useState<WebSocketState>({
    isConnected: false,
    isAuthenticated: false,
    isReconnecting: false,
  });

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;
  const reconnectDelay = 3000;

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      console.log('Connecting to WebSocket:', wsUrl);
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('WebSocket connected');
        setState(prev => ({ 
          ...prev, 
          isConnected: true, 
          isReconnecting: false, 
          lastError: undefined 
        }));
        
        reconnectAttempts.current = 0;

        // Authenticate if user ID is provided
        if (options.userId) {
          ws.send(JSON.stringify({
            type: 'authenticate',
            userId: options.userId
          }));
        }

        // Start heartbeat
        startHeartbeat();
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setState(prev => ({ 
          ...prev, 
          isConnected: false, 
          isAuthenticated: false 
        }));
        
        stopHeartbeat();
        
        // Attempt to reconnect
        if (reconnectAttempts.current < maxReconnectAttempts) {
          setState(prev => ({ ...prev, isReconnecting: true }));
          
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++;
            connect();
          }, reconnectDelay * Math.pow(2, reconnectAttempts.current));
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setState(prev => ({ 
          ...prev, 
          lastError: 'Connection error' 
        }));
      };

    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
      setState(prev => ({ 
        ...prev, 
        lastError: 'Failed to connect' 
      }));
    }
  }, [options.userId]);

  const handleWebSocketMessage = useCallback((data: any) => {
    const event = data as WebSocketEvent;

    switch (event.type) {
      case 'connection_established':
        console.log('WebSocket connection established');
        break;

      case 'authenticated':
        setState(prev => ({ ...prev, isAuthenticated: true }));
        console.log('WebSocket authenticated');
        break;

      case 'authentication_failed':
        setState(prev => ({ 
          ...prev, 
          lastError: 'Authentication failed' 
        }));
        break;

      case 'message_sent':
        options.onMessage?.(event.message);
        break;

      case 'call_incoming':
        options.onCallIncoming?.(event.call);
        break;

      case 'user_online':
        options.onUserOnline?.(event.userId);
        break;

      case 'user_offline':
        options.onUserOffline?.(event.userId);
        break;

      case 'user_logged_out':
        // Another user logged out - refresh chat data
        options.onUserOffline?.(event.userId);
        break;

      case 'user_account_deleted':
        // Another user deleted their account - handle in callback
        options.onAccountDeleted?.(event.userId);
        break;

      case 'force_logout':
        // This user was forcefully logged out
        console.log('Force logout received:', event.reason);
        localStorage.removeItem('auth_token');
        localStorage.removeItem('hasCompletedOnboarding');
        window.location.reload();
        return;

      case 'typing_start':
        options.onTypingStart?.(event.chatId, event.userId);
        break;

      case 'typing_stop':
        options.onTypingStop?.(event.chatId, event.userId);
        break;

      case 'message_read':
        options.onMessageRead?.(event.messageId, event.userId);
        break;

      case 'call_answered':
        options.onCallAnswered?.(event.callId);
        break;

      case 'call_declined':
        options.onCallDeclined?.(event.callId);
        break;

      case 'call_ended':
        options.onCallEnded?.(event.callId);
        break;

      case 'pong':
        // Heartbeat response
        break;

      default:
        console.log('Unknown WebSocket event:', event);
    }
  }, [
    options.onMessage,
    options.onCallIncoming,
    options.onUserOnline,
    options.onUserOffline,
    options.onTypingStart,
    options.onTypingStop,
    options.onMessageRead,
    options.onCallAnswered,
    options.onCallDeclined,
    options.onCallEnded,
    options.onAccountDeleted,
  ]);

  const startHeartbeat = useCallback(() => {
    heartbeatIntervalRef.current = setInterval(() => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000); // Send ping every 30 seconds
  }, []);

  const stopHeartbeat = useCallback(() => {
    if (heartbeatIntervalRef.current) {
      clearInterval(heartbeatIntervalRef.current);
      heartbeatIntervalRef.current = null;
    }
  }, []);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    stopHeartbeat();
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    
    setState({
      isConnected: false,
      isAuthenticated: false,
      isReconnecting: false,
    });
  }, [stopHeartbeat]);

  // WebSocket actions
  const sendMessage = useCallback((messageData: any) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'message_sent',
        messageData
      }));
    }
  }, []);

  const sendTypingStart = useCallback((chatId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'typing_start',
        chatId
      }));
    }
  }, []);

  const sendTypingStop = useCallback((chatId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'typing_stop',
        chatId
      }));
    }
  }, []);

  const markMessageAsRead = useCallback((messageId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'message_read',
        messageId
      }));
    }
  }, []);

  const initiateCall = useCallback((receiverId: string, callType: 'voice' | 'video') => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'call_initiate',
        receiverId,
        callType
      }));
    }
  }, []);

  const answerCall = useCallback((callId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'call_answer',
        callId
      }));
    }
  }, []);

  const declineCall = useCallback((callId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'call_decline',
        callId
      }));
    }
  }, []);

  const endCall = useCallback((callId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'call_end',
        callId
      }));
    }
  }, []);

  // Connect when component mounts and user ID is available
  useEffect(() => {
    if (options.userId) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [options.userId, connect, disconnect]);

  // Reconnect when userId changes
  useEffect(() => {
    if (options.userId && wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'authenticate',
        userId: options.userId
      }));
    }
  }, [options.userId]);

  return {
    ...state,
    connect,
    disconnect,
    sendMessage,
    sendTypingStart,
    sendTypingStop,
    markMessageAsRead,
    initiateCall,
    answerCall,
    declineCall,
    endCall,
  };
}