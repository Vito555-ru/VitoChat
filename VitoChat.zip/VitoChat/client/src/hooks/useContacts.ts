import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { User } from '@shared/schema';

export function useContacts() {
  return useQuery<User[]>({
    queryKey: ['/api/contacts'],
    refetchInterval: 10000, // Refetch every 10 seconds to check online status
  });
}

export function useSearchUsers(query: string) {
  return useQuery<User[]>({
    queryKey: ['/api/users/search', query],
    enabled: query.length >= 2,
    staleTime: 30000, // Cache search results for 30 seconds
  });
}

export function useAddContact() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (contactId: string) => {
      const response = await apiRequest('POST', '/api/contacts', { contactId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contacts'] });
    },
  });
}

export function useBlockContact() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (contactId: string) => {
      const response = await apiRequest('POST', '/api/contacts/block', { contactId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contacts'] });
    },
  });
}