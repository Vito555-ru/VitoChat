import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { CallWithUsers } from '@shared/schema';

export function useCalls() {
  return useQuery<CallWithUsers[]>({
    queryKey: ['/api/calls'],
    refetchInterval: 5000, // Refetch every 5 seconds for call history updates
  });
}

export function useCreateCall() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ receiverId, callType }: {
      receiverId: string;
      callType: 'voice' | 'video';
    }) => {
      const response = await apiRequest('POST', '/api/calls', {
        receiverId,
        callType,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calls'] });
    },
  });
}

export function useAnswerCall() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (callId: string) => {
      const response = await apiRequest('PUT', `/api/calls/${callId}/answer`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calls'] });
    },
  });
}

export function useDeclineCall() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (callId: string) => {
      const response = await apiRequest('PUT', `/api/calls/${callId}/decline`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calls'] });
    },
  });
}

export function useEndCall() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (callId: string) => {
      const response = await apiRequest('PUT', `/api/calls/${callId}/end`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/calls'] });
    },
  });
}