import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { ChatWithUsers } from '@shared/schema';

export function useChats() {
  return useQuery<ChatWithUsers[]>({
    queryKey: ['/api/chats'],
    refetchInterval: 5000, // Refetch every 5 seconds for real-time updates
  });
}

export function useCreateChat() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (otherUserId: string) => {
      const response = await apiRequest('POST', '/api/chats', { otherUserId });
      return response.json();
    },
    onSuccess: () => {
      // Invalidate chats to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
    },
  });
}

export function useChatMessages(chatId: string | null) {
  return useQuery({
    queryKey: ['/api/chats', chatId, 'messages'],
    enabled: !!chatId,
    refetchInterval: 2000, // Refetch every 2 seconds for real-time messages
  });
}

export function useSendMessage() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ chatId, content, type = 'text' }: {
      chatId: string;
      content: string;
      type?: 'text' | 'image' | 'voice' | 'video' | 'document';
    }) => {
      const response = await apiRequest('POST', `/api/chats/${chatId}/messages`, {
        content,
        type,
      });
      return response.json();
    },
    onSuccess: (_, variables) => {
      // Invalidate both messages and chats to update last message
      queryClient.invalidateQueries({ 
        queryKey: ['/api/chats', variables.chatId, 'messages'] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ['/api/chats'] 
      });
    },
  });
}