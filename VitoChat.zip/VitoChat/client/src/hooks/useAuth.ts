import { useState, useEffect } from "react";

interface User {
  id: string;
  phoneNumber: string;
  countryCode?: string;
  firstName?: string;
  lastName?: string;
  bio?: string;
  email?: string;
  profileImageUrl?: string;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const authToken = localStorage.getItem('auth_token');
      if (!authToken) {
        setIsLoading(false);
        return;
      }

      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
      } else {
        localStorage.removeItem('auth_token');
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('auth_token');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      const authToken = localStorage.getItem('auth_token');
      
      console.log('🚪 User logging out - account data will remain on server');
      
      // Call logout API with proper authentication
      if (authToken) {
        await fetch('/api/auth/logout', { 
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${authToken}`
          }
        });
      }
      
      // LOGOUT: Only clear session data, keep hasCompletedOnboarding to skip onboarding
      localStorage.removeItem('auth_token');
      setUser(null);
      
      console.log('✅ User logged out - account data preserved, redirecting to login screen');
      
      // Reload page to reset all state and show login screen
      window.location.reload();
    } catch (error) {
      console.error('Logout error:', error);
      // Force clear session even if API fails
      localStorage.removeItem('auth_token');
      setUser(null);
      window.location.reload();
    }
  };

  const deleteAccount = async () => {
    try {
      const authToken = localStorage.getItem('auth_token');
      if (!authToken) {
        console.error('No auth token found for account deletion');
        return false;
      }

      console.log('🗑️ Initiating account deletion...');

      const response = await fetch('/api/auth/delete-account', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();
        
        console.log('✅ Account permanently deleted - all data erased from database');
        
        // ACCOUNT DELETION: Clear ALL local data to return to initial registration state
        localStorage.clear();
        setUser(null);
        
        console.log('🔄 Redirecting to initial registration screen');
        
        // Force reload to return to splash screen/initial onboarding
        window.location.reload();
        return true;
      } else {
        const error = await response.json();
        console.error('Account deletion failed:', error.error);
        throw new Error(error.error || 'Failed to delete account');
      }
    } catch (error) {
      console.error('Delete account error:', error);
      throw error; // Re-throw so UI can show error message
    }
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    checkAuth,
    logout,
    deleteAccount
  };
}