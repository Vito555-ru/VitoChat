import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { StatusWithUser, InsertStatus } from '@shared/schema';

export function useMyStatuses() {
  return useQuery<StatusWithUser[]>({
    queryKey: ['/api/statuses'],
    refetchInterval: 30000, // Refetch every 30 seconds
  });
}

export function useContactStatuses() {
  return useQuery<StatusWithUser[]>({
    queryKey: ['/api/statuses/contacts'],
    refetchInterval: 30000, // Refetch every 30 seconds for new statuses
  });
}

export function useCreateStatus() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (statusData: Omit<InsertStatus, 'userId' | 'expiresAt'>) => {
      const response = await apiRequest('POST', '/api/statuses', statusData);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate both user statuses and contact statuses
      queryClient.invalidateQueries({ queryKey: ['/api/statuses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/statuses/contacts'] });
    },
  });
}

export function useViewStatus() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (statusId: string) => {
      const response = await apiRequest('POST', `/api/statuses/${statusId}/view`);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate contact statuses to update view counts
      queryClient.invalidateQueries({ queryKey: ['/api/statuses/contacts'] });
    },
  });
}

export function useDeleteStatus() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (statusId: string) => {
      const response = await apiRequest('DELETE', `/api/statuses/${statusId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/statuses'] });
    },
  });
}