import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import type { User } from '@shared/schema';

export function useProfileSettings(userId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateProfileMutation = useMutation({
    mutationFn: async (updates: Partial<User>) => {
      const response = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update profile');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      toast({
        title: 'Profile Updated',
        description: 'Your profile has been updated successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Update Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const changeNumberMutation = useMutation({
    mutationFn: async (newPhoneNumber: string) => {
      const response = await fetch('/api/users/change-number', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ newPhoneNumber }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to change number');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'OTP Sent',
        description: 'Verification code sent to your new number.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Change Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/users/account', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to delete account');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Clear local storage and redirect to welcome screen
      localStorage.removeItem('auth_token');
      window.location.href = '/';
    },
    onError: (error: Error) => {
      toast({
        title: 'Deletion Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    updateProfile: updateProfileMutation.mutateAsync,
    changeNumber: changeNumberMutation.mutateAsync,
    deleteAccount: deleteAccountMutation.mutateAsync,
    isUpdating: updateProfileMutation.isPending,
    isChangingNumber: changeNumberMutation.isPending,
    isDeletingAccount: deleteAccountMutation.isPending,
  };
}