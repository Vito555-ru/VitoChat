import { useQueryClient } from '@tanstack/react-query';
import { useWebSocket } from './useWebSocket';
import { useAuth } from './useAuth';
import { useCallback, useEffect } from 'react';
import type { MessageWithSender } from '@shared/schema';

export function useMessages() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  
  const handleMessage = useCallback((message: MessageWithSender) => {
    // Update the messages for the specific chat
    queryClient.setQueryData(
      ['/api/chats', message.chatId, 'messages'],
      (oldData: MessageWithSender[] | undefined) => {
        if (!oldData) return [message];
        
        // Check if message already exists to avoid duplicates
        const exists = oldData.some(m => m.id === message.id);
        if (exists) return oldData;
        
        return [...oldData, message].sort((a, b) => 
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
      }
    );
    
    // Update the chat list to show new last message
    queryClient.invalidateQueries({ queryKey: ['/api/chats'] });
  }, [queryClient]);

  const handleUserOnline = useCallback((userId: string) => {
    // Update user online status in contacts
    queryClient.setQueryData(['/api/contacts'], (oldData: any[] | undefined) => {
      if (!oldData) return oldData;
      return oldData.map(contact => 
        contact.id === userId 
          ? { ...contact, isOnline: true }
          : contact
      );
    });
    
    // Update online status in chats
    queryClient.setQueryData(['/api/chats'], (oldData: any[] | undefined) => {
      if (!oldData) return oldData;
      return oldData.map(chat => 
        chat.otherUser.id === userId 
          ? { ...chat, otherUser: { ...chat.otherUser, isOnline: true } }
          : chat
      );
    });
  }, [queryClient]);

  const handleUserOffline = useCallback((userId: string) => {
    // Update user online status in contacts
    queryClient.setQueryData(['/api/contacts'], (oldData: any[] | undefined) => {
      if (!oldData) return oldData;
      return oldData.map(contact => 
        contact.id === userId 
          ? { ...contact, isOnline: false, lastSeen: new Date() }
          : contact
      );
    });
    
    // Update online status in chats
    queryClient.setQueryData(['/api/chats'], (oldData: any[] | undefined) => {
      if (!oldData) return oldData;
      return oldData.map(chat => 
        chat.otherUser.id === userId 
          ? { ...chat, otherUser: { ...chat.otherUser, isOnline: false, lastSeen: new Date() } }
          : chat
      );
    });
  }, [queryClient]);

  const {
    isConnected,
    isAuthenticated,
    sendMessage,
    sendTypingStart,
    sendTypingStop,
    markMessageAsRead,
  } = useWebSocket({
    userId: user?.id,
    onMessage: handleMessage,
    onUserOnline: handleUserOnline,
    onUserOffline: handleUserOffline,
  });

  return {
    isConnected,
    isAuthenticated,
    sendMessage,
    sendTypingStart,
    sendTypingStop,
    markMessageAsRead,
  };
}