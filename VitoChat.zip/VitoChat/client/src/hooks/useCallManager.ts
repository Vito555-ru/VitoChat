import { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useToast } from '@/hooks/use-toast';
import type { CallWithUsers, WebSocketEvent } from '@shared/schema';

export function useCallManager(userId: string) {
  const [activeCall, setActiveCall] = useState<CallWithUsers | null>(null);
  const [incomingCall, setIncomingCall] = useState<CallWithUsers | null>(null);
  const [callState, setCallState] = useState({
    isMuted: false,
    isVideoEnabled: true,
    isSpeakerOn: false,
  });

  const { toast } = useToast();
  const webSocket = useWebSocket();

  // Handle WebSocket call events
  const handleWebSocketEvent = useCallback((event: WebSocketEvent) => {
    switch (event.type) {
      case 'call_incoming':
        setIncomingCall(event.call);
        playNotificationSound();
        break;
        
      case 'call_answered':
        if (activeCall?.id === event.callId) {
          setActiveCall(prev => prev ? { ...prev, status: 'active' } : null);
        }
        break;
        
      case 'call_ended':
      case 'call_declined':
        if (activeCall?.id === event.callId || incomingCall?.id === event.callId) {
          setActiveCall(null);
          setIncomingCall(null);
          playCallEndSound();
        }
        break;
    }
  }, [activeCall, incomingCall]);

  // Subscribe to WebSocket events
  useEffect(() => {
    // Note: This would need integration with the WebSocket hook
    // For now, we'll simulate the event handling
  }, [handleWebSocketEvent]);

  const playNotificationSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(1000, audioContext.currentTime + 0.5);
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 2);
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 2);
    } catch (error) {
      console.log('Audio notification unavailable');
    }
  };

  const playCallEndSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(400, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(200, audioContext.currentTime + 0.5);
      
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 1);
    } catch (error) {
      console.log('Audio notification unavailable');
    }
  };

  const initiateCall = async (receiverId: string, callType: 'voice' | 'video') => {
    try {
      const response = await fetch('/api/calls/initiate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          receiverId,
          type: callType
        })
      });

      if (response.ok) {
        const call = await response.json();
        setActiveCall(call);
        setCallState(prev => ({ ...prev, isVideoEnabled: callType === 'video' }));
        return call;
      } else {
        throw new Error('Failed to initiate call');
      }
    } catch (error) {
      console.error('Failed to initiate call:', error);
      toast({
        title: 'Call Failed',
        description: 'Unable to start the call. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const answerCall = async () => {
    if (!incomingCall) return;

    try {
      const response = await fetch(`/api/calls/${incomingCall.id}/answer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.ok) {
        setActiveCall({ ...incomingCall, status: 'active' });
        setIncomingCall(null);
        setCallState(prev => ({ ...prev, isVideoEnabled: incomingCall.type === 'video' }));
      } else {
        throw new Error('Failed to answer call');
      }
    } catch (error) {
      console.error('Failed to answer call:', error);
      toast({
        title: 'Call Error',
        description: 'Unable to answer the call.',
        variant: 'destructive'
      });
    }
  };

  const declineCall = async () => {
    if (!incomingCall) return;

    try {
      const response = await fetch(`/api/calls/${incomingCall.id}/decline`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.ok) {
        setIncomingCall(null);
      }
    } catch (error) {
      console.error('Failed to decline call:', error);
    }
  };

  const endCall = async () => {
    if (!activeCall) return;

    try {
      const response = await fetch(`/api/calls/${activeCall.id}/end`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.ok) {
        setActiveCall(null);
        playCallEndSound();
      }
    } catch (error) {
      console.error('Failed to end call:', error);
    }
  };

  const toggleMute = () => {
    setCallState(prev => ({ ...prev, isMuted: !prev.isMuted }));
    // TODO: Implement actual audio muting logic
  };

  const toggleVideo = () => {
    setCallState(prev => ({ ...prev, isVideoEnabled: !prev.isVideoEnabled }));
    // TODO: Implement actual video toggling logic
  };

  const toggleSpeaker = () => {
    setCallState(prev => ({ ...prev, isSpeakerOn: !prev.isSpeakerOn }));
    // TODO: Implement actual speaker toggling logic
  };

  return {
    activeCall,
    incomingCall,
    callState,
    actions: {
      initiateCall,
      answerCall,
      declineCall,
      endCall,
      toggleMute,
      toggleVideo,
      toggleSpeaker,
    }
  };
}