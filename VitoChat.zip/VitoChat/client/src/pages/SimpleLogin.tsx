import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Phone, ArrowLeft, Shield, User, CheckCircle } from "lucide-react";
import vitoLogoUrl from "@assets/ChatGPT Image Jul 19, 2025, 04_43_39 PM_1754902665155.png";

type LoginStep = 'phone' | 'otp' | 'profile' | 'complete';

interface LoginData {
  phoneNumber: string;
  countryCode: string;
  otp: string;
  firstName: string;
  lastName: string;
}

interface CountryCode {
  code: string;
  name: string;
  flag: string;
}

const COUNTRY_CODES: CountryCode[] = [
  { code: "+1", name: "United States", flag: "🇺🇸" },
  { code: "+1", name: "Canada", flag: "🇨🇦" },
  { code: "+92", name: "Pakistan", flag: "🇵🇰" },
  { code: "+91", name: "India", flag: "🇮🇳" },
  { code: "+44", name: "United Kingdom", flag: "🇬🇧" },
  { code: "+49", name: "Germany", flag: "🇩🇪" },
  { code: "+33", name: "France", flag: "🇫🇷" },
  { code: "+39", name: "Italy", flag: "🇮🇹" },
  { code: "+34", name: "Spain", flag: "🇪🇸" },
  { code: "+86", name: "China", flag: "🇨🇳" },
  { code: "+81", name: "Japan", flag: "🇯🇵" },
  { code: "+82", name: "South Korea", flag: "🇰🇷" },
  { code: "+61", name: "Australia", flag: "🇦🇺" },
  { code: "+55", name: "Brazil", flag: "🇧🇷" },
  { code: "+52", name: "Mexico", flag: "🇲🇽" },
  { code: "+7", name: "Russia", flag: "🇷🇺" },
  { code: "+90", name: "Turkey", flag: "🇹🇷" },
  { code: "+966", name: "Saudi Arabia", flag: "🇸🇦" },
  { code: "+971", name: "UAE", flag: "🇦🇪" },
  { code: "+20", name: "Egypt", flag: "🇪🇬" },
  { code: "+27", name: "South Africa", flag: "🇿🇦" },
  { code: "+234", name: "Nigeria", flag: "🇳🇬" },
  { code: "+62", name: "Indonesia", flag: "🇮🇩" },
  { code: "+60", name: "Malaysia", flag: "🇲🇾" },
  { code: "+65", name: "Singapore", flag: "🇸🇬" },
  { code: "+66", name: "Thailand", flag: "🇹🇭" },
  { code: "+84", name: "Vietnam", flag: "🇻🇳" },
  { code: "+63", name: "Philippines", flag: "🇵🇭" },
  { code: "+880", name: "Bangladesh", flag: "🇧🇩" },
  { code: "+94", name: "Sri Lanka", flag: "🇱🇰" },
  { code: "+977", name: "Nepal", flag: "🇳🇵" },
  { code: "+98", name: "Iran", flag: "🇮🇷" },
  { code: "+964", name: "Iraq", flag: "🇮🇶" },
  { code: "+962", name: "Jordan", flag: "🇯🇴" },
  { code: "+961", name: "Lebanon", flag: "🇱🇧" },
  { code: "+972", name: "Israel", flag: "🇮🇱" },
  { code: "+970", name: "Palestine", flag: "🇵🇸" },
  { code: "+93", name: "Afghanistan", flag: "🇦🇫" },
  { code: "+213", name: "Algeria", flag: "🇩🇿" },
  { code: "+212", name: "Morocco", flag: "🇲🇦" },
  { code: "+216", name: "Tunisia", flag: "🇹🇳" },
  { code: "+218", name: "Libya", flag: "🇱🇾" },
  { code: "+251", name: "Ethiopia", flag: "🇪🇹" },
  { code: "+254", name: "Kenya", flag: "🇰🇪" },
  { code: "+256", name: "Uganda", flag: "🇺🇬" },
  { code: "+255", name: "Tanzania", flag: "🇹🇿" },
];

interface SimpleLoginProps {
  onLoginSuccess?: () => void;
}

export default function SimpleLogin({ onLoginSuccess }: SimpleLoginProps) {
  const [step, setStep] = useState<LoginStep>('phone');
  const [data, setData] = useState<Partial<LoginData>>({
    countryCode: '+92' // Default to Pakistan
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          phoneNumber: data.phoneNumber,
          countryCode: data.countryCode
        })
      });

      if (response.ok) {
        const result = await response.json();
        
        // Show OTP in development mode
        if (result.devOtp) {
          toast({
            title: "OTP Sent (Development)",
            description: `Your verification code is: ${result.devOtp}`,
            duration: 10000, // Show for 10 seconds
          });
        } else {
          toast({
            title: "OTP Sent",
            description: `Verification code sent to ${data.countryCode}${data.phoneNumber}`,
          });
        }
        setStep('otp');
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Failed to send OTP');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send verification code. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOTPSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      console.log('Cookies before OTP verification:', document.cookie);
      
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          phoneNumber: data.phoneNumber,
          countryCode: data.countryCode,
          otp: data.otp
        })
      });

      console.log('OTP verification response status:', response.status);
      console.log('Response headers:', [...response.headers.entries()]);
      console.log('Set-Cookie header:', response.headers.get('set-cookie'));
      console.log('Cookies after OTP verification:', document.cookie);
      
      if (response.ok) {
        const result = await response.json();
        
        // Store auth token in localStorage
        if (result.authToken) {
          localStorage.setItem('authToken', result.authToken);
          console.log('Auth token stored:', result.authToken);
        }
        
        toast({
          title: "Phone Verified",
          description: "Your phone number has been verified successfully.",
        });
        setStep('profile');
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Invalid verification code');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Invalid verification code. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      console.log('Cookies before profile completion:', document.cookie);
      
      // Get auth token from localStorage
      const authToken = localStorage.getItem('authToken');
      console.log('Using auth token for profile completion:', authToken);
      
      const response = await fetch('/api/auth/complete-profile', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
          firstName: data.firstName,
          lastName: data.lastName
        })
      });

      console.log('Profile completion response status:', response.status);
      
      if (response.ok) {
        toast({
          title: "Welcome to VITO!",
          description: "Your account has been created successfully.",
        });
        
        // Trigger auth check to load the main app
        if (onLoginSuccess) {
          setTimeout(() => {
            onLoginSuccess();
          }, 1000);
        }
      } else {
        const error = await response.json();
        throw new Error(error.error || 'Failed to complete profile');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete registration. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (step === 'phone') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <div className="w-20 h-20 mx-auto mb-4">
              <img 
                src={vitoLogoUrl} 
                alt="VITO Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-800">Welcome to VITO</CardTitle>
            <CardDescription className="text-gray-600">
              Enter your phone number to get started
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handlePhoneSubmit} className="space-y-4">
              <div className="flex space-x-2">
                <select
                  value={data.countryCode}
                  onChange={(e) => setData(prev => ({ ...prev, countryCode: e.target.value }))}
                  className="w-32 px-3 py-2 border rounded-md text-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  {COUNTRY_CODES.map((country) => (
                    <option key={`${country.code}-${country.name}`} value={country.code}>
                      {country.flag} {country.code}
                    </option>
                  ))}
                </select>
                <Input
                  type="tel"
                  placeholder="Phone number"
                  value={data.phoneNumber || ''}
                  onChange={(e) => setData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                  required
                  className="flex-1 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={isLoading}>
                <Phone className="w-4 h-4 mr-2" />
                {isLoading ? 'Sending...' : 'Send Code'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'otp') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <Shield className="w-16 h-16 mx-auto mb-4 text-blue-600" />
            <CardTitle className="text-2xl font-bold text-gray-800">Verify Your Phone</CardTitle>
            <CardDescription className="text-gray-600">
              Enter the 6-digit code sent to {data.countryCode} {data.phoneNumber}
            </CardDescription>
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                📱 In development mode, the OTP was shown in the previous notification
              </p>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleOTPSubmit} className="space-y-4">
              <Input
                type="text"
                placeholder="000000"
                maxLength={6}
                value={data.otp || ''}
                onChange={(e) => setData(prev => ({ ...prev, otp: e.target.value }))}
                required
                className="text-center text-lg tracking-widest focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <div className="flex space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep('phone')}
                  className="flex-1 border-blue-200 text-blue-600 hover:bg-blue-50"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white" disabled={isLoading}>
                  {isLoading ? 'Verifying...' : 'Verify'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'profile') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <User className="w-16 h-16 mx-auto mb-4 text-blue-600" />
            <CardTitle className="text-2xl font-bold text-gray-800">Complete Your Profile</CardTitle>
            <CardDescription className="text-gray-600">
              Tell us your name to finish setting up your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <Input
                type="text"
                placeholder="First Name"
                value={data.firstName || ''}
                onChange={(e) => setData(prev => ({ ...prev, firstName: e.target.value }))}
                required
                className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <Input
                type="text"
                placeholder="Last Name (Optional)"
                value={data.lastName || ''}
                onChange={(e) => setData(prev => ({ ...prev, lastName: e.target.value }))}
                className="focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={isLoading}>
                <CheckCircle className="w-4 h-4 mr-2" />
                {isLoading ? 'Creating Account...' : 'Complete Registration'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}