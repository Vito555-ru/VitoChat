import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  MessageCircle, 
  Phone, 
  Video, 
  Settings,
  Search,
  Plus,
  Wifi,
  WifiOff
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useWebSocket } from '@/hooks/useWebSocket';
import { RealTimeChatScreen } from '@/components/RealTimeChatScreen';
import type { ChatWithUsers, User } from '@shared/schema';
import { formatDistanceToNow } from 'date-fns';

import { useAuth } from '@/hooks/useAuth';

export default function Home() {
  const { user: currentUser } = useAuth();
  const [selectedChat, setSelectedChat] = useState<ChatWithUsers | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch user's chats
  const { 
    data: chats = [], 
    isLoading: chatsLoading,
    refetch: refetchChats 
  } = useQuery<ChatWithUsers[]>({
    queryKey: ['/api/chats'],
    refetchInterval: 5000, // Fallback polling for chat list
  });

  // WebSocket connection for real-time updates
  const {
    isConnected,
    isAuthenticated
  } = useWebSocket({
    userId: currentUser?.id || '',
    onMessage: () => {
      // Refetch chats when new messages arrive
      refetchChats();
    },
  });

  const handleChatSelect = (chat: ChatWithUsers) => {
    setSelectedChat(chat);
  };

  const handleBackToChats = () => {
    setSelectedChat(null);
  };

  const handleVoiceCall = () => {
    console.log('Starting voice call with', selectedChat?.otherUser.firstName);
  };

  const handleVideoCall = () => {
    console.log('Starting video call with', selectedChat?.otherUser.firstName);
  };

  const filteredChats = chats.filter((chat: ChatWithUsers) =>
    chat.otherUser.firstName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.otherUser.lastName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.lastMessage?.content?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (selectedChat) {
    return (
      <RealTimeChatScreen
        chat={selectedChat}
        currentUser={currentUser!}
        onBack={handleBackToChats}
        onVoiceCall={handleVoiceCall}
        onVideoCall={handleVideoCall}
      />
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <h1 className="text-xl font-bold text-gray-900">VITO</h1>
            {isConnected ? (
              <Badge variant="secondary" className="bg-green-100 text-green-800 flex items-center space-x-1">
                <Wifi className="w-3 h-3" />
                <span className="text-xs">Connected</span>
              </Badge>
            ) : (
              <Badge variant="destructive" className="flex items-center space-x-1">
                <WifiOff className="w-3 h-3" />
                <span className="text-xs">Connecting...</span>
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Search className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm">
              <Plus className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm">
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Connection Status */}
      {!isAuthenticated && isConnected && (
        <div className="bg-orange-50 border-b px-4 py-2">
          <p className="text-xs text-orange-700 text-center">
            Authenticating with real-time server...
          </p>
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white border-b px-4 py-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search chats..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Chats List */}
      <ScrollArea className="flex-1">
        {chatsLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-gray-500">Loading chats...</div>
          </div>
        ) : filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <MessageCircle className="w-16 h-16 text-gray-400 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {searchQuery ? 'No chats found' : 'No chats yet'}
            </h3>
            <p className="text-gray-500 mb-6">
              {searchQuery 
                ? 'Try a different search term' 
                : 'Start a conversation to see your chats here'
              }
            </p>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white">
              <Plus className="w-4 h-4 mr-2" />
              New Chat
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredChats.map((chat: ChatWithUsers) => (
              <div
                key={chat.id}
                onClick={() => handleChatSelect(chat)}
                className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={chat.otherUser.profileImageUrl || ''} />
                      <AvatarFallback>
                        {chat.otherUser.firstName?.[0] || '?'}
                      </AvatarFallback>
                    </Avatar>
                    {chat.isOnline && (
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900 truncate">
                        {chat.otherUser.firstName} {chat.otherUser.lastName}
                      </h3>
                      <div className="flex items-center space-x-2">
                        {chat.lastMessage && (
                          <span className="text-xs text-gray-500">
                            {formatDistanceToNow(new Date(chat.lastMessage.createdAt), { addSuffix: true })}
                          </span>
                        )}
                        {chat.unreadCount > 0 && (
                          <Badge className="bg-blue-500 text-white text-xs px-2 py-1">
                            {chat.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-1">
                      <p className="text-sm text-gray-600 truncate">
                        {chat.lastMessage?.content || 'No messages yet'}
                      </p>
                      
                      <div className="flex items-center space-x-1">
                        {chat.lastMessage?.senderId === currentUser?.id && (
                          <div className="text-blue-500">
                            {chat.lastMessage.status === 'read' ? '✓✓' : '✓'}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Bottom Navigation */}
      <div className="bg-white border-t px-4 py-2">
        <div className="flex justify-around">
          <Button variant="ghost" size="sm" className="flex flex-col items-center space-y-1">
            <MessageCircle className="w-5 h-5" />
            <span className="text-xs">Chats</span>
          </Button>
          <Button variant="ghost" size="sm" className="flex flex-col items-center space-y-1">
            <Phone className="w-5 h-5" />
            <span className="text-xs">Calls</span>
          </Button>
          <Button variant="ghost" size="sm" className="flex flex-col items-center space-y-1">
            <Video className="w-5 h-5" />
            <span className="text-xs">Status</span>
          </Button>
          <Button variant="ghost" size="sm" className="flex flex-col items-center space-y-1">
            <Settings className="w-5 h-5" />
            <span className="text-xs">Settings</span>
          </Button>
        </div>
      </div>
    </div>
  );
}