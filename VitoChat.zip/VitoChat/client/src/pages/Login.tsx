import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Phone, 
  Shield, 
  MessageSquare, 
  ArrowLeft,
  Loader2
} from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import logoSquare from '@assets/Logo Square_1754892316443.jpg';

interface Country {
  code: string;
  name: string;
  flag: string;
}

const countries: Country[] = [
  { code: '+1', name: 'United States', flag: '🇺🇸' },
  { code: '+1', name: 'Canada', flag: '🇨🇦' },
  { code: '+44', name: 'United Kingdom', flag: '🇬🇧' },
  { code: '+49', name: 'Germany', flag: '🇩🇪' },
  { code: '+33', name: 'France', flag: '🇫🇷' },
  { code: '+39', name: 'Italy', flag: '🇮🇹' },
  { code: '+34', name: 'Spain', flag: '🇪🇸' },
  { code: '+91', name: 'India', flag: '🇮🇳' },
  { code: '+86', name: 'China', flag: '🇨🇳' },
  { code: '+81', name: 'Japan', flag: '🇯🇵' },
  { code: '+82', name: 'South Korea', flag: '🇰🇷' },
  { code: '+61', name: 'Australia', flag: '🇦🇺' },
  { code: '+55', name: 'Brazil', flag: '🇧🇷' },
  { code: '+52', name: 'Mexico', flag: '🇲🇽' },
  { code: '+7', name: 'Russia', flag: '🇷🇺' },
];

type AuthStep = 'phone' | 'otp' | 'profile';

interface PhoneData {
  countryCode: string;
  phoneNumber: string;
}

interface OTPData {
  otp: string;
  tempToken: string;
}

export default function Login() {
  const [authStep, setAuthStep] = useState<AuthStep>('phone');
  const [phoneData, setPhoneData] = useState<PhoneData>({
    countryCode: '+1',
    phoneNumber: ''
  });
  const [otpData, setOTPData] = useState<OTPData>({
    otp: '',
    tempToken: ''
  });
  const [profileData, setProfileData] = useState({
    firstName: '',
    lastName: '',
    bio: ''
  });

  const { toast } = useToast();

  // Send OTP mutation
  const sendOTPMutation = useMutation({
    mutationFn: async (data: PhoneData) => {
      const response = await apiRequest('POST', '/api/auth/send-otp', data);
      return response.json();
    },
    onSuccess: (data) => {
      setOTPData(prev => ({ ...prev, tempToken: data.tempToken }));
      setAuthStep('otp');
      toast({
        title: 'OTP Sent',
        description: `Verification code sent to ${phoneData.countryCode} ${phoneData.phoneNumber}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to send OTP',
        variant: 'destructive',
      });
    },
  });

  // Verify OTP mutation
  const verifyOTPMutation = useMutation({
    mutationFn: async (data: { otp: string; tempToken: string; phoneNumber: string; countryCode: string }) => {
      const response = await apiRequest('POST', '/api/auth/verify-otp', data);
      return response.json();
    },
    onSuccess: (data) => {
      // Store the auth token for API calls
      localStorage.setItem('auth_token', data.token);
      
      if (data.user.hasCompletedProfile) {
        // Existing user logging back in - redirect to app
        console.log('✅ Existing user logged in successfully');
        localStorage.setItem('hasCompletedOnboarding', 'true');
        toast({
          title: 'Welcome Back!',
          description: 'You have successfully logged into your VITO account',
        });
        window.location.href = '/';
      } else {
        // New user needs to complete profile
        console.log('🆕 New user - profile setup required');
        setAuthStep('profile');
        toast({
          title: 'Phone Verified',
          description: 'Complete your profile to start using VITO',
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: 'Invalid OTP',
        description: error.message || 'Please check your verification code',
        variant: 'destructive',
      });
    },
  });

  // Complete profile mutation
  const completeProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      const response = await apiRequest('POST', '/api/auth/complete-profile', data);
      return response.json();
    },
    onSuccess: (data) => {
      // Profile completed - store onboarding completion and redirect
      localStorage.setItem('hasCompletedOnboarding', 'true');
      console.log('✅ Profile setup completed for new user');
      
      toast({
        title: 'Welcome to VITO',
        description: 'Your profile has been created successfully',
      });
      
      // Redirect to main app
      window.location.href = '/';
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create profile',
        variant: 'destructive',
      });
    },
  });

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneData.phoneNumber.trim()) {
      toast({
        title: 'Phone Required',
        description: 'Please enter your phone number',
        variant: 'destructive',
      });
      return;
    }
    sendOTPMutation.mutate(phoneData);
  };

  const handleOTPSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpData.otp.length !== 6) {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter the 6-digit verification code',
        variant: 'destructive',
      });
      return;
    }
    verifyOTPMutation.mutate({
      otp: otpData.otp,
      tempToken: otpData.tempToken,
      phoneNumber: phoneData.phoneNumber,
      countryCode: phoneData.countryCode,
    });
  };

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileData.firstName.trim()) {
      toast({
        title: 'Name Required',
        description: 'Please enter your first name',
        variant: 'destructive',
      });
      return;
    }
    completeProfileMutation.mutate(profileData);
  };

  const formatPhoneNumber = (value: string) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, '');
    
    // Format based on country (simple US formatting for demo)
    if (phoneData.countryCode === '+1' && digits.length >= 6) {
      if (digits.length === 10) {
        return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
      } else if (digits.length > 6) {
        return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6, 10)}`;
      } else {
        return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
      }
    }
    
    return digits;
  };

  const handlePhoneChange = (value: string) => {
    const digits = value.replace(/\D/g, '');
    setPhoneData(prev => ({ ...prev, phoneNumber: digits }));
  };

  const handleBackToPhone = () => {
    setAuthStep('phone');
    setOTPData({ otp: '', tempToken: '' });
  };

  const renderPhoneStep = () => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center space-y-4">
        <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
          <img src={logoSquare} alt="VITO" className="w-12 h-12 rounded-lg" />
        </div>
        <div>
          <CardTitle className="text-2xl font-bold text-gray-900">Welcome to VITO</CardTitle>
          <p className="text-gray-600 mt-2">
            Enter your phone number to get started with secure messaging
          </p>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handlePhoneSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="country">Country</Label>
              <Select value={phoneData.countryCode} onValueChange={(value) => 
                setPhoneData(prev => ({ ...prev, countryCode: value }))
              }>
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  {countries.map((country) => (
                    <SelectItem key={`${country.code}-${country.name}`} value={country.code}>
                      <div className="flex items-center space-x-2">
                        <span>{country.flag}</span>
                        <span>{country.name}</span>
                        <span className="text-gray-500">{country.code}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <div className="flex space-x-2">
                <div className="w-20 px-3 py-2 border border-gray-300 rounded-md bg-gray-50 flex items-center justify-center text-sm font-medium">
                  {phoneData.countryCode}
                </div>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter phone number"
                  value={formatPhoneNumber(phoneData.phoneNumber)}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  className="flex-1"
                  maxLength={phoneData.countryCode === '+1' ? 14 : 15}
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <Button 
              type="submit" 
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
              disabled={sendOTPMutation.isPending || !phoneData.phoneNumber}
            >
              {sendOTPMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending Code...
                </>
              ) : (
                <>
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Send Verification Code
                </>
              )}
            </Button>

            <div className="text-center text-xs text-gray-500 space-y-1">
              <p>We'll send you a 6-digit verification code via SMS</p>
              <p>Standard message rates may apply</p>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );

  const renderOTPStep = () => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center space-y-4">
        <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
          <Shield className="w-8 h-8 text-green-600" />
        </div>
        <div>
          <CardTitle className="text-2xl font-bold text-gray-900">Enter Verification Code</CardTitle>
          <p className="text-gray-600 mt-2">
            We sent a 6-digit code to<br />
            <span className="font-medium">{phoneData.countryCode} {formatPhoneNumber(phoneData.phoneNumber)}</span>
          </p>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleOTPSubmit} className="space-y-6">
          <div>
            <Label htmlFor="otp">Verification Code</Label>
            <Input
              id="otp"
              type="text"
              placeholder="000000"
              value={otpData.otp}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                setOTPData(prev => ({ ...prev, otp: value }));
              }}
              className="text-center text-2xl tracking-widest font-mono"
              maxLength={6}
              autoComplete="one-time-code"
            />
          </div>

          <div className="space-y-3">
            <Button 
              type="submit" 
              className="w-full bg-green-500 hover:bg-green-600 text-white"
              disabled={verifyOTPMutation.isPending || otpData.otp.length !== 6}
            >
              {verifyOTPMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Verifying...
                </>
              ) : (
                'Verify Code'
              )}
            </Button>

            <Button 
              type="button" 
              variant="ghost" 
              className="w-full"
              onClick={handleBackToPhone}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Change Phone Number
            </Button>

            <Button 
              type="button" 
              variant="ghost" 
              className="w-full text-blue-500"
              onClick={() => sendOTPMutation.mutate(phoneData)}
              disabled={sendOTPMutation.isPending}
            >
              {sendOTPMutation.isPending ? 'Sending...' : 'Resend Code'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );

  const renderProfileStep = () => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center space-y-4">
        <div className="mx-auto w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
          <img src={logoSquare} alt="VITO" className="w-12 h-12 rounded-lg" />
        </div>
        <div>
          <CardTitle className="text-2xl font-bold text-gray-900">Complete Your Profile</CardTitle>
          <p className="text-gray-600 mt-2">
            Help your contacts recognize you
          </p>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleProfileSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="firstName">First Name *</Label>
              <Input
                id="firstName"
                type="text"
                placeholder="Enter your first name"
                value={profileData.firstName}
                onChange={(e) => setProfileData(prev => ({ ...prev, firstName: e.target.value }))}
                maxLength={50}
              />
            </div>

            <div>
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                type="text"
                placeholder="Enter your last name"
                value={profileData.lastName}
                onChange={(e) => setProfileData(prev => ({ ...prev, lastName: e.target.value }))}
                maxLength={50}
              />
            </div>

            <div>
              <Label htmlFor="bio">About (Optional)</Label>
              <Input
                id="bio"
                type="text"
                placeholder="Hey there! I am using VITO."
                value={profileData.bio}
                onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                maxLength={139}
              />
              <p className="text-xs text-gray-500 mt-1">
                {profileData.bio.length}/139 characters
              </p>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full bg-purple-500 hover:bg-purple-600 text-white"
            disabled={completeProfileMutation.isPending || !profileData.firstName.trim()}
          >
            {completeProfileMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating Profile...
              </>
            ) : (
              'Complete Setup'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {authStep === 'phone' && renderPhoneStep()}
        {authStep === 'otp' && renderOTPStep()}
        {authStep === 'profile' && renderProfileStep()}
        
        <div className="text-center mt-8 space-y-2">
          <Badge variant="outline" className="text-xs">
            Secure • End-to-End Encrypted
          </Badge>
          <p className="text-xs text-gray-500">
            Powered by Blackhole Networks
          </p>
        </div>
      </div>
    </div>
  );
}