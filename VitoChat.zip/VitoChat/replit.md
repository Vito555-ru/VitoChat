# Overview

VITO is a secure messaging application that provides real-time communication between users. Built with modern web technologies, it features user authentication, chat creation, and message sending capabilities. The application is designed with a clean, responsive interface using the VITO brand identity and is powered by Blackhole Networks.

# User Preferences

Preferred communication style: Simple, everyday language.
Brand design preferences: Blue color scheme for VITO app with custom logo, comprehensive international country code support including Pakistan as default.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent, accessible design
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Framework**: Express.js with TypeScript for the REST API server
- **Session Management**: Express sessions with configurable storage for user authentication
- **API Structure**: RESTful endpoints organized by feature (auth, chats, messages)
- **Storage Layer**: Abstract storage interface with in-memory implementation for development
- **Validation**: Zod schemas for request/response validation and type safety

## Database Design
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: PostgreSQL with three main entities:
  - Users (authentication, profiles, online status)
  - Chats (one-to-one conversations between users)
  - Messages (chat content with read status tracking)
- **Migrations**: Drizzle Kit for database schema management

## Authentication System
- **Session-based**: Express sessions with configurable secrets
- **User Management**: Registration, login, logout with email/password
- **Authorization**: Middleware-based route protection
- **Security**: HTTP-only cookies, configurable for HTTPS in production

## Real-time Features
- **Polling Strategy**: Client-side intervals for chat and message updates (5s for chats, 2s for messages)
- **Live Updates**: Query invalidation and refetching for reactive UI updates
- **Online Status**: User presence tracking with last seen timestamps

## Development Features
- **Hot Reload**: Vite middleware integration for development
- **Error Handling**: Runtime error overlays and structured error responses
- **Logging**: Request/response logging with performance metrics
- **Type Safety**: Shared TypeScript schemas between client and server

# External Dependencies

## Database Services
- **PostgreSQL**: Primary database (configured via DATABASE_URL environment variable)
- **Neon Database**: Serverless PostgreSQL provider (@neondatabase/serverless)

## UI and Styling
- **Radix UI**: Comprehensive set of accessible React components
- **Tailwind CSS**: Utility-first CSS framework for styling
- **shadcn/ui**: Pre-built component library based on Radix UI
- **Lucide React**: Icon library for consistent iconography

## Development Tools
- **Vite**: Build tool and development server
- **Replit Integration**: Development environment plugins for Replit platform
- **ESBuild**: Fast JavaScript bundler for production builds

## Fonts and Assets
- **Google Fonts**: Inter font family for modern typography
- **Custom Assets**: VITO and Blackhole Networks branding assets

# Recent Updates (August 2025)

## Comprehensive Real-time Messaging System with Media Support - FULLY IMPLEMENTED (Latest - August 11, 2025)
- **INSTANT Message Delivery**: Real-time WebSocket messaging with zero perceptible delay, instant send confirmations
- **Advanced Message Status Tracking**: Complete delivery receipts, read receipts, and typing indicators with PostgreSQL storage
- **Enhanced WebSocket Features**: Message confirmations, delivery status, read status, and error handling
- **Media Support Infrastructure**: Object storage routes for images, voice messages, documents, and videos in chats
- **Real-time Typing Indicators**: Live typing start/stop notifications with precise user identification
- **Message State Management**: Comprehensive read/unread, delivered/pending status tracking with database persistence
- **Enhanced Chat Sorting**: Real-time message activity updates chat list order with latest message previews
- **WebSocket Event Types**: Expanded event system supporting all real-time messaging features
- **Database Integration**: Complete message receipt tracking with PostgreSQL for reliable status persistence
- **Media Upload API**: Secure object storage upload endpoints for multimedia message attachments

## Real-Time Voice & Video Calling System - FULLY IMPLEMENTED (August 11, 2025)
- **Instant Call Notifications**: Real-time incoming call alerts with background support and call sounds
- **Complete Call Interface**: Professional video/voice call UI with timers, user info, and call controls
- **Advanced Call Features**: Mute, video toggle, speaker control, and seamless call management
- **Call State Management**: Proper call status tracking (ringing, active, ended, declined) with database persistence
- **Background Call Support**: Calls work even when app is in background with instant notifications
- **Real-time Call Events**: WebSocket-powered call signaling for instant connection and status updates
- **Call History Integration**: Complete call logging with real-time sorting and comprehensive call data
- **Multi-device Call Sync**: Call state synchronized across all user devices in real-time

## Enhanced Profile & Privacy System - FULLY IMPLEMENTED (August 11, 2025)
- **Comprehensive Profile Management**: Real-time profile editing with photo, name, about, and status updates
- **Advanced Privacy Controls**: Granular privacy settings for last seen, profile photo, and about visibility
- **Security Features**: End-to-end encryption indicators, two-step verification setup, and security management
- **Account Management**: Complete phone number change with OTP verification and account deletion
- **Privacy Enforcement**: Server-side privacy validation ensuring settings are respected across all interactions
- **Real-time Privacy Updates**: Instant privacy setting changes with live database synchronization

## Complete Mobile Number Registration & Authentication System - FULLY IMPLEMENTED (August 11, 2025)
- **Real-time OTP Verification**: Live SMS verification with 6-digit codes sent instantly and verified in real-time
- **Smart Phone Number Handling**: One number = one account, but existing users can log back in with OTP verification
- **Persistent Database Storage**: All account data stored securely in PostgreSQL database (no mock data)
- **Profile Data Integration**: Real names, phone numbers, profile pictures stored and retrieved from database
- **Automatic Account Management**: System cleans up incomplete registrations and handles existing user login
- **Live Database Operations**: Real-time account creation, profile completion, and data persistence
- **Development OTP Display**: OTP codes shown in console and API responses for testing (development only)

## Complete Account Lifecycle Management System - FULLY IMPLEMENTED (August 11, 2025)
- **Enhanced Logout Behavior**: Proper logout with server-side session cleanup and automatic redirect to login screen
- **Real-time Account State Updates**: WebSocket notifications for logout and account deletion across all connected devices
- **Comprehensive Account Deletion**: Permanent erasure of ALL user data, messages, contacts, calls, and profile photos
- **Phone Number Liberation**: Account deletion immediately frees phone number for re-registration by same or different user
- **Force Logout Mechanism**: Server can force logout all user sessions for security or account state changes
- **Robust Error Handling**: Comprehensive error handling with user-friendly confirmation dialogs
- **Database Integrity**: Complete data cleanup with referential integrity across all related tables
- **Real-time Propagation**: All contacts receive instant notifications when users logout or delete accounts

## Complete Real-time Messaging System & Phone Uniqueness - FULLY IMPLEMENTED (August 11, 2025)
- **Strict Phone Number Uniqueness**: Each phone number can only register one account with comprehensive validation
- **Account Deletion with Phone Number Release**: Complete data cleanup that frees phone number for re-registration
- **Real-time Message Delivery**: Instant send/receive with WebSocket integration and no perceptible delay
- **Live Chat Sorting**: Chats automatically sort by most recent activity with real-time updates
- **Call History Real-time Sorting**: Calls sort by most recent activity (completed, missed, etc.)
- **Circular Photo Cropping**: Canvas-based circular crop during registration prevents image distortion
- **Press & Hold Context Menu**: Group chat reply/react system with 500ms touch detection
- **Authentication Token Standardization**: Consistent 'auth_token' usage across all components
- **WebSocket Persistence**: Persistent connections for live data sync with offline queue handling
- **Comprehensive Data Cleanup**: Account deletion removes all related data securely
- **Registration-to-Settings Photo Flow**: Profile photos from registration properly flow to settings with update support

## Registration Profile Integration & Universal Image Upload - FULLY WORKING (August 11, 2025)
- **Profile Integration Fix**: Registration profile data (name, phone, image) now properly flows to app settings
- **Universal Image Support**: Accepts any image size with automatic compression (300x300 max, 60% quality)
- **Complete Data Flow**: Registration becomes permanent VITO profile throughout the app
- **Onboarding Flow Fix**: Forced fresh onboarding sequence to ensure proper flow completion
- **Real User Integration**: Removed mock user data, now uses actual authenticated user data

## Complete WhatsApp-Style Onboarding Flow - FULLY WORKING (August 11, 2025)
- **Proper Sequential Flow**: Complete onboarding sequence matching WhatsApp UX - TESTED & VERIFIED
- **Splash Screen**: 2-second VITO branded loading screen with smooth transitions
- **Welcome Screen**: Beautiful branded interface with "Get Started" call-to-action
- **Terms & Privacy**: Legal compliance screen with checkbox acceptance requirement
- **Phone Input**: Country selection with Pakistan (+92) default + 20+ international countries
- **OTP Verification**: Clean 6-digit code verification with development OTP display
- **Permission Requests**: Native-style permission requests for contacts, camera, microphone, notifications
- **Profile Setup**: First/last name collection with photo placeholder
- **Seamless Integration**: Smooth transition from onboarding to main VITO messaging interface
- **Token-Based Auth**: Reliable localStorage authentication with Bearer token system
- **State Management**: Complete onboarding completion tracking with proper logout/login flows
- **Development Features**: OTP display in both toast notifications and verification screen

## Brand Identity Correction
- **Corrected Brand Spelling**: Fixed "Blackho0le Networks" to "Blackhole Networks" throughout application
- **Updated Settings**: Application settings now correctly display "VIOT by Blackhole Networks"
- **Consistent Branding**: All references in Terms & Conditions, index.html, and settings now use correct spelling
- **Brand Integrity**: Maintained consistent brand identity across all user-facing text

# Previous Updates

## Comprehensive Settings & Profile System
- **Complete Profile Management**: Name, photo, about text editing with real-time updates
- **Privacy & Security Controls**: Last seen, profile photo, about visibility settings with granular permissions
- **Two-Step Verification**: PIN-based security with email recovery and hint system
- **Account Management**: Change number, request account info, delete account functionality
- **Theme & Display Settings**: Light/dark/auto themes, wallpaper customization, adjustable font size
- **Chat Management**: Export chats, backup to Google Drive with customizable frequency, clear all chats
- **Notification Controls**: Message, call, and group notification settings with custom tones
- **Comprehensive Settings Navigation**: Hierarchical settings structure with intuitive navigation

## Enhanced Messaging Features
- **Complete Chat Interface**: All WhatsApp-like messaging features implemented
- **Voice & Video Calls**: Full calling system with mute, camera switch, speaker toggle, participant management
- **Message Controls**: Reply, forward, delete, star, react with emoji reactions
- **Media Sharing**: Camera, gallery, documents, contacts, location sharing capabilities
- **Voice Messages**: Recording and playback functionality with waveform display

## AI-Powered Smart Search (Latest)
- **Natural Language Search**: Semantic understanding beyond keyword matching
- **Press & Hold Message Actions**: Touch and hold or right-click messages for quick actions
- **Context Menu**: Reply, forward, star, copy, react, and delete options
- **Smart Search Dialog**: Multiple tabs for Messages, Media, and AI Insights
- **Anthropic Integration**: Backend ready for Claude AI-powered search analysis
- **Reduced Splash Screen**: Now displays for 2 seconds instead of 2.5 seconds

## Message Interaction Improvements
- **Press & Hold Functionality**: 500ms press duration triggers context menu
- **Touch & Mouse Support**: Works on both mobile touch and desktop mouse interactions
- **Quick Emoji Reactions**: Direct emoji selection from context menu
- **Enhanced UX**: Improved message selection and interaction feedback