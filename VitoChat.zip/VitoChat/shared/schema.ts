import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, pgEnum, uuid } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums for better type safety
export const messageTypeEnum = pgEnum('message_type', ['text', 'image', 'video', 'audio', 'document', 'location', 'contact']);
export const messageStatusEnum = pgEnum('message_status', ['sent', 'delivered', 'read']);
export const callTypeEnum = pgEnum('call_type', ['voice', 'video']);
export const callStatusEnum = pgEnum('call_status', ['ringing', 'active', 'answered', 'missed', 'declined', 'ended']);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: text("phone_number").notNull(),
  countryCode: text("country_code").notNull().default("+1"),
  username: text("username"),
  email: text("email"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  bio: text("bio").default("Hey there! I am using VITO."),
  about: text("about"),
  profileImageUrl: text("profile_image_url"),
  isOnline: boolean("is_online").default(false),
  lastSeen: timestamp("last_seen").defaultNow(),
  hasAcceptedTerms: boolean("has_accepted_terms").default(false),
  isPhoneVerified: boolean("is_phone_verified").default(false),
  hasCompletedProfile: boolean("has_completed_profile").default(false),
  hasGrantedPermissions: boolean("has_granted_permissions").default(false),
  // Privacy settings
  lastSeenPrivacy: text("last_seen_privacy").default("everyone"),
  profilePhotoPrivacy: text("profile_photo_privacy").default("everyone"),
  aboutPrivacy: text("about_privacy").default("everyone"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const chats = pgTable("chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  user1Id: varchar("user1_id").notNull().references(() => users.id),
  user2Id: varchar("user2_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").notNull(),
  senderId: varchar("sender_id").notNull(),
  type: messageTypeEnum("type").notNull().default('text'),
  content: text("content"),
  mediaUrl: text("media_url"),
  mediaType: text("media_type"), // mime type
  mediaSize: integer("media_size"), // file size in bytes
  mediaDuration: integer("media_duration"), // for audio/video in seconds
  thumbnailUrl: text("thumbnail_url"), // for video/image
  fileName: text("file_name"), // for documents
  location: jsonb("location"), // {lat, lng, address}
  contactData: jsonb("contact_data"), // {name, phone, email}
  replyToId: varchar("reply_to_id"),
  forwardedFromId: varchar("forwarded_from_id"),
  status: messageStatusEnum("status").notNull().default('sent'),
  isStarred: boolean("is_starred").default(false),
  isDeleted: boolean("is_deleted").default(false),
  reactions: jsonb("reactions"), // {emoji: string, users: string[]}[]
  isEdited: boolean("is_edited").default(false),
  editedAt: timestamp("edited_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const statuses = pgTable("statuses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: varchar("type").notNull(), // text, image, video
  content: text("content"), // text content for text statuses
  mediaUrl: varchar("media_url"), // URL for image/video statuses
  backgroundColor: varchar("background_color"), // for text statuses
  privacy: varchar("privacy").notNull().default("contacts"), // everyone, contacts, selected
  selectedContacts: text("selected_contacts").array(), // for selected privacy
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const otpVerifications = pgTable("otp_verifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  phoneNumber: text("phone_number").notNull(),
  countryCode: text("country_code").notNull(),
  otp: text("otp").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const statusViews = pgTable("status_views", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  statusId: varchar("status_id").notNull().references(() => statuses.id),
  viewerId: varchar("viewer_id").notNull().references(() => users.id),
  viewedAt: timestamp("viewed_at").defaultNow(),
});

// Calls table for voice/video calls
export const calls = pgTable("calls", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callerId: varchar("caller_id").notNull().references(() => users.id),
  receiverId: varchar("receiver_id").notNull().references(() => users.id),
  chatId: varchar("chat_id").references(() => chats.id),
  type: callTypeEnum("type").notNull(),
  status: callStatusEnum("status").notNull().default('ringing'),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  duration: integer("duration"), // in seconds
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Message read receipts for detailed tracking
export const messageReadReceipts = pgTable("message_read_receipts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageId: varchar("message_id").notNull().references(() => messages.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  readAt: timestamp("read_at").defaultNow(),
});

// Contacts/Friends table
export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  contactId: varchar("contact_id").notNull().references(() => users.id),
  displayName: text("display_name"), // custom name for contact
  isBlocked: boolean("is_blocked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Device tokens for push notifications
export const deviceTokens = pgTable("device_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  token: text("token").notNull(),
  platform: text("platform").notNull(), // ios, android, web
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat participants for group chats (future)
export const chatParticipants = pgTable("chat_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").notNull().references(() => chats.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: text("role").notNull().default('member'), // admin, member
  joinedAt: timestamp("joined_at").defaultNow(),
  leftAt: timestamp("left_at"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  sentMessages: many(messages, { relationName: "sender" }),
  chatsAsUser1: many(chats, { relationName: "user1" }),
  chatsAsUser2: many(chats, { relationName: "user2" }),
  statuses: many(statuses),
  calls: many(calls, { relationName: "caller" }),
  receivedCalls: many(calls, { relationName: "receiver" }),
  contacts: many(contacts, { relationName: "user" }),
  contactOf: many(contacts, { relationName: "contact" }),
  deviceTokens: many(deviceTokens),
}));

export const chatsRelations = relations(chats, ({ one, many }) => ({
  user1: one(users, { fields: [chats.user1Id], references: [users.id], relationName: "user1" }),
  user2: one(users, { fields: [chats.user2Id], references: [users.id], relationName: "user2" }),
  messages: many(messages),
  calls: many(calls),
}));

export const messagesRelations = relations(messages, ({ one, many }) => ({
  chat: one(chats, { fields: [messages.chatId], references: [chats.id] }),
  sender: one(users, { fields: [messages.senderId], references: [users.id], relationName: "sender" }),
  replyTo: one(messages, { fields: [messages.replyToId], references: [messages.id], relationName: "replyTo" }),
  forwardedFrom: one(messages, { fields: [messages.forwardedFromId], references: [messages.id], relationName: "forwardedFrom" }),
  readReceipts: many(messageReadReceipts),
}));

export const callsRelations = relations(calls, ({ one }) => ({
  caller: one(users, { fields: [calls.callerId], references: [users.id], relationName: "caller" }),
  receiver: one(users, { fields: [calls.receiverId], references: [users.id], relationName: "receiver" }),
  chat: one(chats, { fields: [calls.chatId], references: [chats.id] }),
}));

export const contactsRelations = relations(contacts, ({ one }) => ({
  user: one(users, { fields: [contacts.userId], references: [users.id], relationName: "user" }),
  contact: one(users, { fields: [contacts.contactId], references: [users.id], relationName: "contact" }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertChatSchema = createInsertSchema(chats).omit({
  id: true,
  createdAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
});

export const insertCallSchema = createInsertSchema(calls).omit({
  id: true,
  createdAt: true,
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
  createdAt: true,
});

export const insertDeviceTokenSchema = createInsertSchema(deviceTokens).omit({
  id: true,
  createdAt: true,
});

export const insertStatusSchema = createInsertSchema(statuses).omit({
  id: true,
  createdAt: true,
});

export const insertStatusViewSchema = createInsertSchema(statusViews).omit({
  id: true,
  viewedAt: true,
});

export const insertOtpVerificationSchema = createInsertSchema(otpVerifications).omit({
  id: true,
  createdAt: true,
});

// Phone verification schemas
export const phoneVerificationSchema = z.object({
  phoneNumber: z.string().min(10, "Phone number must be at least 10 digits"),
  countryCode: z.string().default("+1"),
});

export const otpVerificationSchema = z.object({
  phoneNumber: z.string(),
  otp: z.string().length(6, "OTP must be 6 digits"),
});

export const profileSetupSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().optional(),
  profileImageUrl: z.string().url().optional(),
});

export const loginSchema = z.object({
  phoneNumber: z.string().min(10, "Invalid phone number"),
  countryCode: z.string().default("+1"),
});

export const registerSchema = phoneVerificationSchema;

// Base types
export type User = typeof users.$inferSelect;
export type Chat = typeof chats.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Call = typeof calls.$inferSelect;
export type Contact = typeof contacts.$inferSelect;
export type DeviceToken = typeof deviceTokens.$inferSelect;
export type Status = typeof statuses.$inferSelect;
export type StatusView = typeof statusViews.$inferSelect;
export type MessageReadReceipt = typeof messageReadReceipts.$inferSelect;
export type OtpVerification = typeof otpVerifications.$inferSelect;

// Insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertChat = z.infer<typeof insertChatSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertCall = z.infer<typeof insertCallSchema>;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type InsertDeviceToken = z.infer<typeof insertDeviceTokenSchema>;
export type InsertStatus = z.infer<typeof insertStatusSchema>;
export type InsertStatusView = z.infer<typeof insertStatusViewSchema>;
export type InsertOtpVerification = z.infer<typeof insertOtpVerificationSchema>;

// Form validation types
export type LoginData = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;
export type PhoneVerificationData = z.infer<typeof phoneVerificationSchema>;
export type OTPVerificationData = z.infer<typeof otpVerificationSchema>;
export type ProfileSetupData = z.infer<typeof profileSetupSchema>;

// Composite types for enhanced data
export type ChatWithUsers = Chat & {
  otherUser: User;
  lastMessage?: MessageWithSender;
  unreadCount: number;
  isOnline: boolean;
};

export type MessageWithSender = Message & {
  sender: User;
  replyTo?: Message;
};

export type CallWithUsers = Call & {
  caller: User;
  receiver: User;
};

export type ContactWithUser = Contact & {
  contact: User;
};

export type StatusWithUser = Status & {
  user: User;
  views: StatusView[];
  viewCount: number;
  isViewed: boolean;
};

// WebSocket event types
export type WebSocketEvent = 
  | { type: 'connection_established'; message: string }
  | { type: 'authenticated'; user: User }
  | { type: 'authentication_failed'; message: string }
  | { type: 'user_online'; userId: string }
  | { type: 'user_offline'; userId: string }
  | { type: 'user_logged_out'; userId: string }
  | { type: 'user_account_deleted'; userId: string }
  | { type: 'force_logout'; reason: string }
  | { type: 'message_sent'; message: MessageWithSender }
  | { type: 'message_sent_confirmation'; message: MessageWithSender }
  | { type: 'message_error'; error: string }
  | { type: 'message_read'; messageId: string; userId: string }
  | { type: 'message_delivered'; messageId: string; userId: string; receiverId?: string }
  | { type: 'typing_start'; chatId: string; userId: string }
  | { type: 'typing_stop'; chatId: string; userId: string }
  | { type: 'call_incoming'; call: CallWithUsers }
  | { type: 'call_answered'; callId: string }
  | { type: 'call_ended'; callId: string }
  | { type: 'call_declined'; callId: string }
  | { type: 'ping' }
  | { type: 'pong' }
  | { type: 'error'; message: string };
